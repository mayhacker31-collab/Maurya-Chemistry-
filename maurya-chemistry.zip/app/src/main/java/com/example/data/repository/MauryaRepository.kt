package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.AdminAuditLog
import com.example.data.model.AppSettings
import com.example.data.model.Coupon
import com.example.data.model.Course
import com.example.data.model.Doubt
import com.example.data.model.Enrollment
import com.example.data.model.PaymentRecord
import com.example.data.model.PromoBanner
import com.example.data.model.SupportTicket
import com.example.data.model.TestAttempt
import com.example.data.model.UserProfile
import com.example.data.seed.ChemistryContentCatalog
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MauryaRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private fun requireUserId(): String =
    auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in with Google.")

  private fun unwrapAndLogFirestoreError(
    error: Throwable,
    operationType: OperationType,
    path: String,
    expectedUid: String? = null,
  ): Nothing {
    val firestoreError = generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()
    if (firestoreError == null && error is CancellationException) throw error
    val toLog = firestoreError ?: (error as? Exception)
    if (toLog != null && (expectedUid == null || auth.currentUser?.uid == expectedUid)) {
      handleFirestoreError(toLog, operationType, path)
    }
    throw error
  }

  // --- User Profile ---
  fun observeUserProfile(userId: String): Flow<UserProfile?> =
    db.collection("users").document(userId)
      .snapshots()
      .map { snap -> snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.GET, "users/$userId", userId) }

  suspend fun ensureUserProfile(
    fullName: String,
    email: String,
    phone: String = "+91 98765 43210",
    studentClass: String = "Class 12",
    board: String = "CBSE",
    examTarget: String = "JEE",
    preferredLanguage: String = "English",
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docPath = "users/$uid"
    return try {
      val docRef = db.collection("users").document(uid)
      val existing = docRef.get().await()
      if (!existing.exists()) {
        val safeName = fullName.trim().ifBlank { "Aarav Sharma" }.take(80)
        val payload = mapOf(
          "userId" to uid,
          "fullName" to safeName,
          "email" to email.take(150),
          "phone" to phone.take(20),
          "studentClass" to studentClass,
          "board" to board,
          "examTarget" to examTarget,
          "preferredLanguage" to preferredLanguage,
          "role" to "student",
          "darkMode" to false,
          "streakDays" to 7L,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        ).filterValues { it != null }
        docRef.set(payload).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun updateUserProfile(
    fullName: String,
    phone: String,
    studentClass: String,
    board: String,
    examTarget: String,
    preferredLanguage: String,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docPath = "users/$uid"
    return try {
      require(fullName.trim().length in 1..80) { "Name must be 1-80 characters" }
      db.collection("users").document(uid).update(
        mapOf(
          "fullName" to fullName.trim(),
          "phone" to phone.trim().take(20),
          "studentClass" to studentClass,
          "board" to board,
          "examTarget" to examTarget,
          "preferredLanguage" to preferredLanguage,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun toggleDarkMode(enabled: Boolean): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docPath = "users/$uid"
    return try {
      db.collection("users").document(uid).update(
        mapOf(
          "darkMode" to enabled,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docPath)
      Result.failure(e)
    }
  }

  // --- Courses & Banners & Coupons (Active queries match firestore.rules!) ---
  fun observeActiveCourses(): Flow<List<Course>> =
    db.collection("courses")
      .whereEqualTo("status", "active")
      .snapshots()
      .map { snap ->
        val list = snap.toObjects(Course::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        if (list.isEmpty()) ChemistryContentCatalog.defaultCourses else list
      }
      .catch { e ->
        Log.w("MauryaRepo", "Using catalog fallback after course stream error: ${e.message}")
        if (e is CancellationException && generateSequence<Throwable>(e) { it.cause }.none { it is FirebaseFirestoreException }) throw e
        emit(ChemistryContentCatalog.defaultCourses)
      }

  fun observeActiveBanners(): Flow<List<PromoBanner>> =
    db.collection("banners")
      .whereEqualTo("status", "active")
      .snapshots()
      .map { snap ->
        val list = snap.toObjects(PromoBanner::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedBy { it.orderIndex }
        if (list.isEmpty()) ChemistryContentCatalog.defaultBanners else list
      }
      .catch { e ->
        if (e is CancellationException && generateSequence<Throwable>(e) { it.cause }.none { it is FirebaseFirestoreException }) throw e
        emit(ChemistryContentCatalog.defaultBanners)
      }

  fun observeActiveCoupons(): Flow<List<Coupon>> =
    db.collection("coupons")
      .whereEqualTo("status", "active")
      .snapshots()
      .map { snap ->
        val list = snap.toObjects(Coupon::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        if (list.isEmpty()) {
          listOf(
            Coupon(
              id = "MAURYA500",
              code = "MAURYA500",
              discountType = "flat",
              discountValue = 500L,
              maxUsage = 500L,
              usedCount = 124L,
              expiryText = "31 Dec 2026",
              status = "active",
            ),
            Coupon(
              id = "CHEM20",
              code = "CHEM20",
              discountType = "percentage",
              discountValue = 20L,
              maxUsage = 200L,
              usedCount = 48L,
              expiryText = "15 Jan 2027",
              status = "active",
            ),
          )
        } else list
      }
      .catch { e ->
        if (e is CancellationException && generateSequence<Throwable>(e) { it.cause }.none { it is FirebaseFirestoreException }) throw e
        emit(emptyList())
      }

  fun observeAppSettings(): Flow<AppSettings> =
    db.collection("appSettings")
      .whereEqualTo("scope", "public")
      .snapshots()
      .map { snap ->
        snap.toObjects(AppSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE).firstOrNull()
          ?: AppSettings(id = "global")
      }
      .catch { e ->
        if (e is CancellationException && generateSequence<Throwable>(e) { it.cause }.none { it is FirebaseFirestoreException }) throw e
        emit(AppSettings(id = "global"))
      }

  // --- User-Scoped Subcollections ---
  fun observeEnrollments(userId: String): Flow<List<Enrollment>> =
    db.collection("users").document(userId).collection("enrollments")
      .snapshots()
      .map { snap -> snap.toObjects(Enrollment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.LIST, "users/$userId/enrollments", userId) }

  fun observePayments(userId: String): Flow<List<PaymentRecord>> =
    db.collection("users").document(userId).collection("payments")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .snapshots()
      .map { snap -> snap.toObjects(PaymentRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.LIST, "users/$userId/payments", userId) }

  fun observeTestAttempts(userId: String): Flow<List<TestAttempt>> =
    db.collection("users").document(userId).collection("testAttempts")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .snapshots()
      .map { snap -> snap.toObjects(TestAttempt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.LIST, "users/$userId/testAttempts", userId) }

  fun observeDoubts(userId: String): Flow<List<Doubt>> =
    db.collection("users").document(userId).collection("doubts")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .snapshots()
      .map { snap -> snap.toObjects(Doubt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.LIST, "users/$userId/doubts", userId) }

  fun observeTickets(userId: String): Flow<List<SupportTicket>> =
    db.collection("users").document(userId).collection("tickets")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .snapshots()
      .map { snap -> snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e -> unwrapAndLogFirestoreError(e, OperationType.LIST, "users/$userId/tickets", userId) }

  // --- Mutations ---
  suspend fun enrollInCourse(course: Course): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docPath = "users/$uid/enrollments/${course.id}"
    return try {
      val docRef = db.collection("users").document(uid).collection("enrollments").document(course.id)
      val payload = mapOf(
        "userId" to uid,
        "courseId" to course.id,
        "courseTitle" to course.title.take(120),
        "mentorName" to course.mentorName.take(80),
        "progressPercent" to 12L,
        "completedLectures" to 4L,
        "totalLectures" to course.lectureCount.coerceAtLeast(1L),
        "status" to "active",
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun recordPaymentAndEnroll(
    course: Course,
    orderId: String,
    amountPaid: Long,
    discountAmount: Long,
    couponCode: String,
    paymentMethod: String,
    success: Boolean,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val payRef = db.collection("users").document(uid).collection("payments").document()
    return try {
      val paymentPayload = mapOf(
        "userId" to uid,
        "orderId" to orderId,
        "courseId" to course.id,
        "courseTitle" to course.title.take(120),
        "amount" to amountPaid.coerceAtLeast(0L),
        "originalAmount" to course.mrp.coerceAtLeast(amountPaid),
        "discountAmount" to discountAmount.coerceAtLeast(0L),
        "couponCode" to couponCode.take(40).ifBlank { null },
        "paymentMethod" to paymentMethod.take(60),
        "status" to if (success) "successful" else "failed",
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      ).filterValues { it != null }
      payRef.set(paymentPayload).await()
      if (success) {
        enrollInCourse(course)
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, payRef.path)
      Result.failure(e)
    }
  }

  suspend fun requestRefund(paymentId: String, reason: String): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docRef = db.collection("users").document(uid).collection("payments").document(paymentId)
    return try {
      docRef.update(
        mapOf(
          "status" to "refund_in_progress",
          "refundReason" to reason.trim().ifBlank { "Course cancelled by student" }.take(300),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateEnrollmentProgress(enrollment: Enrollment, deltaLectures: Long): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docRef = db.collection("users").document(uid).collection("enrollments").document(enrollment.id)
    return try {
      val nextCompleted = (enrollment.completedLectures + deltaLectures).coerceIn(0L, enrollment.totalLectures)
      val nextPercent = ((nextCompleted * 100L) / enrollment.totalLectures.coerceAtLeast(1L)).coerceIn(0L, 100L)
      val nextStatus = if (nextPercent >= 100L) "completed" else "active"
      docRef.update(
        mapOf(
          "completedLectures" to nextCompleted,
          "progressPercent" to nextPercent,
          "status" to nextStatus,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun saveTestAttempt(attempt: TestAttempt): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docRef = db.collection("users").document(uid).collection("testAttempts").document()
    return try {
      val payload = mapOf(
        "userId" to uid,
        "testId" to attempt.testId,
        "testTitle" to attempt.testTitle.take(120),
        "subject" to attempt.subject.take(80),
        "score" to attempt.score,
        "maxMarks" to attempt.maxMarks.coerceAtLeast(1L),
        "correctCount" to attempt.correctCount,
        "wrongCount" to attempt.wrongCount,
        "unattemptedCount" to attempt.unattemptedCount,
        "accuracyPercent" to attempt.accuracyPercent.coerceIn(0L, 100L),
        "durationSeconds" to attempt.durationSeconds.coerceAtLeast(0L),
        "physicalScore" to attempt.physicalScore.coerceIn(0L, 100L),
        "organicScore" to attempt.organicScore.coerceIn(0L, 100L),
        "inorganicScore" to attempt.inorganicScore.coerceIn(0L, 100L),
        "createdAt" to FieldValue.serverTimestamp(),
      )
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun submitDoubt(
    subject: String,
    chapter: String,
    difficulty: String,
    questionText: String,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docRef = db.collection("users").document(uid).collection("doubts").document()
    return try {
      val trimmed = questionText.trim()
      require(trimmed.length in 3..600) { "Doubt must be 3-600 characters" }
      val payload = mapOf(
        "userId" to uid,
        "subject" to subject.take(80),
        "chapter" to chapter.take(100),
        "difficulty" to difficulty,
        "questionText" to trimmed,
        "status" to "pending",
        "mentorName" to "Dr. R. Verma",
        "replyCount" to 0L,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun createSupportTicket(
    category: String,
    orderId: String,
    subject: String,
    message: String,
    contactMethod: String,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val docRef = db.collection("users").document(uid).collection("tickets").document()
    return try {
      require(subject.trim().length >= 3 && message.trim().length >= 5) { "Subject and message required" }
      val code = "TKT-${(1000..9999).random()}"
      val payload = mapOf(
        "userId" to uid,
        "ticketCode" to code,
        "category" to category.take(60),
        "orderId" to orderId.trim().take(64).ifBlank { null },
        "subject" to subject.trim().take(120),
        "message" to message.trim().take(600),
        "contactMethod" to contactMethod,
        "status" to "open",
        "lastReply" to "We received your request. Typical response time: 2-4 hours.",
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      ).filterValues { it != null }
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Admin Operations ---
  fun observeAdminLogs(): Flow<List<AdminAuditLog>> = flow {
    val currentEmail = auth.currentUser?.email
    if (currentEmail != "gentoincfacts@gmail.com") {
      emit(emptyList())
      return@flow
    }
    db.collection("adminLogs")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .limit(25)
      .snapshots()
      .map { it.toObjects(AdminAuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e ->
        if (e is CancellationException && generateSequence<Throwable>(e) { it.cause }.none { it is FirebaseFirestoreException }) throw e
        emit(emptyList())
      }
      .collect { emit(it) }
  }

  suspend fun createAdminBanner(title: String, subtitle: String, ctaText: String): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val email = auth.currentUser?.email ?: "admin@mauryachemistry.in"
    val bannerRef = db.collection("banners").document()
    return try {
      bannerRef.set(
        mapOf(
          "title" to title.trim().take(100),
          "subtitle" to subtitle.trim().take(160),
          "ctaText" to ctaText.trim().take(40),
          "orderIndex" to 0L,
          "status" to "active",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      logAdminAction(uid, email, "CREATE_BANNER", "banners/${bannerRef.id}", "Added banner: $title")
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, bannerRef.path)
      Result.failure(e)
    }
  }

  suspend fun createAdminCoupon(code: String, discountType: String, value: Long, maxUsage: Long): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val email = auth.currentUser?.email ?: "admin@mauryachemistry.in"
    val cleanCode = code.trim().uppercase().replace(" ", "")
    val couponRef = db.collection("coupons").document(cleanCode)
    return try {
      couponRef.set(
        mapOf(
          "code" to cleanCode.take(32),
          "discountType" to discountType,
          "discountValue" to value.coerceIn(1L, 50000L),
          "maxUsage" to maxUsage.coerceIn(1L, 100000L),
          "usedCount" to 0L,
          "expiryText" to "31 Dec 2026",
          "status" to "active",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      logAdminAction(uid, email, "CREATE_COUPON", "coupons/$cleanCode", "Created $discountType coupon ($value)")
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, couponRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateGlobalSettings(settings: AppSettings, actionDetail: String): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val email = auth.currentUser?.email ?: "admin@mauryachemistry.in"
    val ref = db.collection("appSettings").document("global")
    return try {
      ref.set(
        mapOf(
          "scope" to "public",
          "maintenanceMode" to settings.maintenanceMode,
          "maintenanceEta" to settings.maintenanceEta.take(32),
          "minSupportedVersion" to settings.minSupportedVersion.take(24),
          "latestVersion" to settings.latestVersion.take(24),
          "termsText" to settings.termsText.take(2000),
          "lastBackupAt" to settings.lastBackupAt.take(60),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      logAdminAction(uid, email, "UPDATE_SETTINGS", "appSettings/global", actionDetail)
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, ref.path)
      Result.failure(e)
    }
  }

  suspend fun processRefundAsAdmin(studentUid: String, paymentId: String, approve: Boolean): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
    val email = auth.currentUser?.email ?: "admin@mauryachemistry.in"
    val ref = db.collection("users").document(studentUid).collection("payments").document(paymentId)
    return try {
      val nextStatus = if (approve) "refunded" else "successful"
      ref.update(
        mapOf(
          "status" to nextStatus,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      logAdminAction(uid, email, if (approve) "APPROVE_REFUND" else "REJECT_REFUND", ref.path, "Set status to $nextStatus")
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, ref.path)
      Result.failure(e)
    }
  }

  private suspend fun logAdminAction(
    adminUid: String,
    adminEmail: String,
    action: String,
    targetEntity: String,
    details: String,
  ) {
    val logRef = db.collection("adminLogs").document()
    logRef.set(
      mapOf(
        "adminUid" to adminUid,
        "adminEmail" to adminEmail,
        "action" to action,
        "targetEntity" to targetEntity,
        "details" to details.take(400),
        "createdAt" to FieldValue.serverTimestamp(),
      )
    ).await()
  }
}

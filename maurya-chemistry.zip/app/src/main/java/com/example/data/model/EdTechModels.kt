package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val studentClass: String = "Class 12",
  val board: String = "CBSE",
  val examTarget: String = "JEE",
  val preferredLanguage: String = "English",
  val role: String = "student",
  val darkMode: Boolean = false,
  val streakDays: Long = 7L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Course(
  @DocumentId val id: String = "",
  val title: String = "",
  val subtitle: String = "",
  val category: String = "JEE",
  val mentorName: String = "Dr. R. Verma",
  val mentorQualification: String = "M.Sc. Chemistry • 12+ yrs",
  val price: Long = 3499L,
  val mrp: Long = 6999L,
  val discountPercent: Long = 50L,
  val freeCourse: Boolean = false,
  val rating: Double = 4.9,
  val lectureCount: Long = 120L,
  val validityText: String = "Valid till Mar 2027",
  val language: String = "Hindi + English",
  val description: String = "",
  val status: String = "active",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Enrollment(
  @DocumentId val id: String = "",
  val userId: String = "",
  val courseId: String = "",
  val courseTitle: String = "",
  val mentorName: String = "",
  val progressPercent: Long = 0L,
  val completedLectures: Long = 0L,
  val totalLectures: Long = 120L,
  val status: String = "active",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PaymentRecord(
  @DocumentId val id: String = "",
  val userId: String = "",
  val orderId: String = "",
  val courseId: String = "",
  val courseTitle: String = "",
  val amount: Long = 0L,
  val originalAmount: Long = 0L,
  val discountAmount: Long = 0L,
  val couponCode: String = "",
  val paymentMethod: String = "UPI • PhonePe",
  val status: String = "successful",
  val refundReason: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class TestAttempt(
  @DocumentId val id: String = "",
  val userId: String = "",
  val testId: String = "",
  val testTitle: String = "",
  val subject: String = "Full Syllabus",
  val score: Long = 0L,
  val maxMarks: Long = 180L,
  val correctCount: Long = 0L,
  val wrongCount: Long = 0L,
  val unattemptedCount: Long = 0L,
  val accuracyPercent: Long = 0L,
  val durationSeconds: Long = 0L,
  val physicalScore: Long = 0L,
  val organicScore: Long = 0L,
  val inorganicScore: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Doubt(
  @DocumentId val id: String = "",
  val userId: String = "",
  val subject: String = "Physical Chemistry",
  val chapter: String = "Chemical Bonding",
  val difficulty: String = "Medium",
  val questionText: String = "",
  val status: String = "pending",
  val replyText: String = "",
  val mentorName: String = "Dr. R. Verma",
  val replyCount: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class SupportTicket(
  @DocumentId val id: String = "",
  val userId: String = "",
  val ticketCode: String = "",
  val category: String = "Payments",
  val orderId: String = "",
  val subject: String = "",
  val message: String = "",
  val contactMethod: String = "Email",
  val status: String = "open",
  val lastReply: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PromoBanner(
  @DocumentId val id: String = "",
  val title: String = "",
  val subtitle: String = "",
  val ctaText: String = "Enroll Now",
  val orderIndex: Long = 0L,
  val status: String = "active",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Coupon(
  @DocumentId val id: String = "",
  val code: String = "",
  val discountType: String = "flat",
  val discountValue: Long = 500L,
  val maxUsage: Long = 100L,
  val usedCount: Long = 0L,
  val expiryText: String = "31 Dec 2026",
  val status: String = "active",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AppSettings(
  @DocumentId val id: String = "",
  val scope: String = "public",
  val maintenanceMode: Boolean = false,
  val maintenanceEta: String = "00:45:20",
  val minSupportedVersion: String = "2.0.0",
  val latestVersion: String = "2.1.0",
  val termsText: String = "By using Maurya Chemistry Classes 2.0, you agree to our academic integrity and digital content policy.",
  val lastBackupAt: String = "Today, 04:00 AM IST",
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AdminAuditLog(
  @DocumentId val id: String = "",
  val adminUid: String = "",
  val adminEmail: String = "",
  val action: String = "",
  val targetEntity: String = "",
  val details: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AdminRole(
  @DocumentId val id: String = "",
  val uid: String = "",
  val email: String = "",
  val displayName: String = "",
  val role: String = "manager",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

// Curriculum, Testing, Learning & Reference Domain Models
data class LectureItem(
  val id: String,
  val chapterId: String,
  val chapterTitle: String,
  val subject: String,
  val numberLabel: String,
  val title: String,
  val mentorName: String,
  val duration: String,
  val completed: Boolean,
  val locked: Boolean,
  val bookmarked: Boolean,
  val summary: String,
  val takeaways: List<String>,
  val pdfTitle: String,
)

data class LiveClassSession(
  val id: String,
  val title: String,
  val subject: String,
  val mentorName: String,
  val batchName: String,
  val timeLabel: String,
  val dateLabel: String,
  val status: String, // "live", "upcoming", "completed"
  val viewerCount: String,
  val description: String,
  val reminderSet: Boolean = false,
)

data class LiveChatMessage(
  val id: String,
  val senderName: String,
  val text: String,
  val timeLabel: String,
  val fromMentor: Boolean,
  val pinned: Boolean = false,
)

data class NoteDocument(
  val id: String,
  val title: String,
  val subject: String,
  val chapter: String,
  val pages: Int,
  val sizeLabel: String,
  val downloaded: Boolean = false,
  val sampleFormulas: List<String> = emptyList(),
)

data class PyqPaper(
  val id: String,
  val exam: String,
  val year: String,
  val title: String,
  val solutionsAvailable: Boolean = true,
  val downloaded: Boolean = false,
)

data class DownloadTaskItem(
  val id: String,
  val title: String,
  val fileType: String, // "video", "pdf"
  val sizeLabel: String,
  val progressPercent: Int,
  val speedLabel: String,
  val state: String, // "active", "paused", "completed", "failed"
  val timestampLabel: String,
)

data class ChemistryQuestion(
  val id: String,
  val number: Int,
  val subject: String, // Physical, Organic, Inorganic
  val question: String,
  val options: List<String>,
  val correctIndex: Int,
  val explanation: List<String>,
  val conceptTag: String,
)

data class TestDefinition(
  val id: String,
  val title: String,
  val pattern: String,
  val category: String, // Daily Practice, Chapter Test, Mock Test, Full Syllabus
  val durationMinutes: Int,
  val questionCount: Int,
  val maxMarks: Int,
  val syllabus: List<String>,
)

data class NotificationItem(
  val id: String,
  val title: String,
  val body: String,
  val timeLabel: String,
  val section: String, // Today, Yesterday, Earlier
  val kind: String, // class, test, offer
  val unread: Boolean,
)

data class MentorProfile(
  val id: String,
  val name: String,
  val subject: String,
  val qualification: String,
  val experience: String,
  val lecturesCount: String,
  val studentsCount: String,
  val rating: String,
  val bio: String,
)

data class LeaderboardEntry(
  val rank: Int,
  val name: String,
  val subjectTag: String,
  val score: Int,
  val trendUp: Boolean,
  val currentUser: Boolean = false,
)

data class AchievementBadge(
  val id: String,
  val title: String,
  val subtitle: String,
  val unlocked: Boolean,
)

data class CertificateItem(
  val id: String,
  val title: String,
  val studentName: String,
  val issuedOn: String,
  val scoreSummary: String,
)

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.HelpCenter
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.QuestionAnswer
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettings
import com.example.data.model.SupportTicket
import com.example.data.model.UserProfile
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.GoldMedal
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.PrimaryNavyDeep
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun ProfileScreen(
  profile: UserProfile?,
  userEmail: String,
  enrolledCount: Int,
  testsTakenCount: Int,
  isAdminUser: Boolean,
  onEditProfile: () -> Unit,
  onOpenMyBatches: () -> Unit,
  onOpenPayments: () -> Unit,
  onOpenDoubts: () -> Unit,
  onOpenAchievements: () -> Unit,
  onOpenCertificates: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenHelp: () -> Unit,
  onOpenAdminPortal: () -> Unit,
  onSignOut: () -> Unit,
) {
  val fullName = profile?.fullName?.ifBlank { "Aarav Sharma" } ?: "Aarav Sharma"
  val initials = fullName.split(" ").mapNotNull { it.firstOrNull()?.uppercaseChar() }.take(2).joinToString("").ifBlank { "AS" }
  val classAndTarget = "${profile?.studentClass ?: "Class 12"} • ${profile?.examTarget ?: "JEE"} 2027"

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(Brush.verticalGradient(listOf(PrimaryNavy, PrimaryNavyDeep)))
          .windowInsetsPadding(WindowInsets.statusBars)
          .padding(horizontal = 20.dp, vertical = 20.dp),
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "My Profile",
              style = MaterialTheme.typography.titleLarge,
              color = Color.White,
              fontWeight = FontWeight.Bold,
            )
            IconButton(
              onClick = onOpenSettings,
              modifier = Modifier.testTag("profile_settings_button"),
            ) {
              Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Color.White)
            }
          }
          Spacer(Modifier.height(10.dp))

          Surface(
            shape = CircleShape,
            color = RoyalBlue,
            border = BorderStroke(3.dp, AccentBlue),
            modifier = Modifier.size(82.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                text = initials,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
              )
            }
          }
          Spacer(Modifier.height(10.dp))
          Text(
            text = fullName,
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = userEmail.ifBlank { profile?.email ?: "" },
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.78f),
          )
          Spacer(Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(classAndTarget, Color.White.copy(alpha = 0.16f), Color.White)
            if (isAdminUser) {
              StatusPill("SUPER ADMIN", GoldMedal, PrimaryNavy)
            }
          }
          Spacer(Modifier.height(12.dp))
          OutlinedButton(
            onClick = onEditProfile,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(50),
            modifier = Modifier.testTag("edit_profile_button"),
          ) {
            Icon(Icons.Rounded.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Edit Profile", color = Color.White)
          }
        }
      }
    }

    // Quick stats card
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
          ProfileStatCol("${profile?.streakDays ?: 7} Days", "Streak")
          ProfileStatCol("${enrolledCount.coerceAtLeast(2)}", "Batches")
          ProfileStatCol("${testsTakenCount.coerceAtLeast(4)}", "Tests")
        }
      }
    }

    // Admin Management Portal Card
    item {
      MauryaCard(
        onClick = onOpenAdminPortal,
        containerColor = if (MauryaTheme.colors.isDark) MauryaTheme.colors.softBlue else PrimaryNavy,
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp)
          .testTag("open_admin_portal_card"),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(shape = RoundedCornerShape(14.dp), color = AccentBlue.copy(alpha = 0.25f), modifier = Modifier.size(46.dp)) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Rounded.AdminPanelSettings, contentDescription = "Admin Portal", tint = Color.White)
            }
          }
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Admin Management Portal",
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "Revenue, Payments, Banners, Coupons, Refunds & Cloud Backups",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f),
            )
          }
          Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = Color.White)
        }
      }
    }

    item {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        SectionHeader("Academic & Account")
        ProfileMenuTile(Icons.Rounded.MenuBook, "Purchased Batches", "View active & completed courses", SoftBlue, RoyalBlue, onOpenMyBatches)
        ProfileMenuTile(Icons.Rounded.ReceiptLong, "Payment History & Receipts", "Invoices, UPI orders & refund status", SoftGreenTint, SuccessGreen, onOpenPayments)
        ProfileMenuTile(Icons.Rounded.QuestionAnswer, "My Doubts", "Chemistry mentor Q&A & solutions", SoftPurpleTint, PrimaryNavy, onOpenDoubts)
        ProfileMenuTile(Icons.Rounded.EmojiEvents, "Achievements & Badges", "Unlock milestones & study streaks", SoftOrangeTint, WarningAmber, onOpenAchievements)
        ProfileMenuTile(Icons.Rounded.WorkspacePremium, "Certificates", "Download verified Chemistry certificates", SoftBlue, RoyalBlue, onOpenCertificates)
        ProfileMenuTile(Icons.Rounded.HelpCenter, "Help Center & Support", "FAQs, live tickets & contact support", SoftGreenTint, SuccessGreen, onOpenHelp)
      }
    }

    item {
      Box(modifier = Modifier.padding(horizontal = 16.dp)) {
        OutlinedButton(
          onClick = onSignOut,
          border = BorderStroke(1.dp, ErrorRed),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sign_out_button"),
        ) {
          Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = ErrorRed)
          Spacer(Modifier.width(8.dp))
          Text("Sign Out", color = ErrorRed, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun ProfileStatCol(value: String, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MauryaTheme.colors.textPrimary)
    Text(label, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
  }
}

@Composable
private fun ProfileMenuTile(
  icon: ImageVector,
  title: String,
  subtitle: String,
  iconBg: Color,
  iconTint: Color,
  onClick: () -> Unit,
) {
  MauryaCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Surface(shape = RoundedCornerShape(12.dp), color = iconBg, modifier = Modifier.size(42.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = title, tint = iconTint)
        }
      }
      Spacer(Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
      }
      Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = MauryaTheme.colors.textSecondary)
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditProfileScreen(
  profile: UserProfile?,
  onBack: () -> Unit,
  onSave: (String, String, String, String, String, String) -> Unit,
) {
  var name by remember(profile) { mutableStateOf(profile?.fullName ?: "Aarav Sharma") }
  var phone by remember(profile) { mutableStateOf(profile?.phone ?: "+91 98765 43210") }
  var studentClass by remember(profile) { mutableStateOf(profile?.studentClass ?: "Class 12") }
  var board by remember(profile) { mutableStateOf(profile?.board ?: "CBSE") }
  var target by remember(profile) { mutableStateOf(profile?.examTarget ?: "JEE") }
  var lang by remember(profile) { mutableStateOf(profile?.preferredLanguage ?: "English") }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "Edit Profile", onBack = onBack)
    Column(
      modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("Full Name") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )
      OutlinedTextField(
        value = phone,
        onValueChange = { phone = it },
        label = { Text("Phone Number") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )

      Text("Class", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Class 11", "Class 12", "Dropper").forEach { item ->
          FilterChip(
            selected = studentClass == item,
            onClick = { studentClass = item },
            label = { Text(item) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      Text("Board", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("CBSE", "ICSE", "State").forEach { item ->
          FilterChip(
            selected = board == item,
            onClick = { board = item },
            label = { Text(item) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      Text("Exam Target", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("JEE", "NEET", "CBSE", "Foundation").forEach { item ->
          FilterChip(
            selected = target == item,
            onClick = { target = item },
            label = { Text(item) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      Text("Preferred Language", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("English", "Hindi").forEach { item ->
          FilterChip(
            selected = lang == item,
            onClick = { lang = item },
            label = { Text(item) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = { onSave(name, phone, studentClass, board, target, lang) },
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_profile_button"),
        ) {
          Text("Save Changes", color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
      }
    }
  }
}

@Composable
fun AchievementsScreen(onBack: () -> Unit) {
  val badges = ChemistryContentCatalog.badges
  val unlockedCount = badges.count { it.unlocked }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "Achievements", onBack = onBack)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      item {
        MauryaCard(containerColor = PrimaryNavy, modifier = Modifier.fillMaxWidth()) {
          Text("Level 4 • Chemistry Scholar", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
          Spacer(Modifier.height(6.dp))
          Text("$unlockedCount of ${badges.size} badges unlocked • 1,240 XP", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
          Spacer(Modifier.height(10.dp))
          LinearProgressIndicator(
            progress = { unlockedCount.toFloat() / badges.size.coerceAtLeast(1) },
            color = GoldMedal,
            trackColor = Color.White.copy(alpha = 0.25f),
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
          )
        }
      }

      items(badges, key = { it.id }) { badge ->
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = if (badge.unlocked) SoftOrangeTint else MauryaTheme.colors.border,
              modifier = Modifier.size(48.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Rounded.EmojiEvents,
                  contentDescription = badge.title,
                  tint = if (badge.unlocked) GoldMedal else MauryaTheme.colors.textSecondary,
                )
              }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(badge.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text(badge.subtitle, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
            }
            StatusPill(
              text = if (badge.unlocked) "Unlocked" else "Locked",
              containerColor = if (badge.unlocked) SoftGreenTint else MauryaTheme.colors.border,
              contentColor = if (badge.unlocked) SuccessGreen else MauryaTheme.colors.textSecondary,
            )
          }
        }
      }
    }
  }
}

@Composable
fun CertificatesScreen(
  studentName: String,
  onBack: () -> Unit,
  onDownloadCertificate: (String) -> Unit,
) {
  val certificates = ChemistryContentCatalog.certificates
  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "My Certificates", onBack = onBack)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      items(certificates, key = { it.id }) { cert ->
        Surface(
          shape = RoundedCornerShape(22.dp),
          color = MauryaTheme.colors.cardBackground,
          border = BorderStroke(2.dp, GoldMedal),
          shadowElevation = 3.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.WorkspacePremium, contentDescription = null, tint = GoldMedal, modifier = Modifier.size(32.dp))
              Spacer(Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text("MAURYA CHEMISTRY CLASSES 2.0", style = MaterialTheme.typography.labelSmall, color = RoyalBlue, fontWeight = FontWeight.Bold)
                Text("Certificate of Excellence", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              }
            }
            Spacer(Modifier.height(12.dp))
            Text("Awarded to ${studentName.ifBlank { cert.studentName }}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(cert.title, style = MaterialTheme.typography.titleSmall, color = PrimaryNavy, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Issued: ${cert.issuedOn}", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
              StatusPill(cert.scoreSummary, SoftGreenTint, SuccessGreen)
            }
            Spacer(Modifier.height(12.dp))
            Button(
              onClick = { onDownloadCertificate(cert.title) },
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text("Download Verified PDF", color = Color.White)
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAndSecurityScreen(
  darkMode: Boolean,
  appSettings: AppSettings,
  onToggleDarkMode: (Boolean) -> Unit,
  onPreviewMaintenance: () -> Unit,
  onBack: () -> Unit,
) {
  var pushNotifications by remember { mutableStateOf(true) }
  var biometricLock by remember { mutableStateOf(false) }
  var wifiOnlyDownloads by remember { mutableStateOf(true) }
  var showUpdateSheet by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "Settings & Security", onBack = onBack)
    Column(
      modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      SectionHeader("Appearance & Preferences")
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        SettingsToggleRow(Icons.Rounded.DarkMode, "Dark Mode", "Use midnight chemistry palette", darkMode, onToggleDarkMode)
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        SettingsToggleRow(Icons.Rounded.Notifications, "Class & Test Alerts", "Live reminders and result alerts", pushNotifications) { pushNotifications = it }
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        SettingsToggleRow(Icons.Rounded.Settings, "Wi-Fi Only Downloads", "Save mobile data on HD lectures", wifiOnlyDownloads) { wifiOnlyDownloads = it }
      }

      SectionHeader("Security & Devices")
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        SettingsToggleRow(Icons.Rounded.Security, "App Lock Protection", "Require device lock on launch", biometricLock) { biometricLock = it }
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.PhoneAndroid, contentDescription = null, tint = RoyalBlue)
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("Current Android Device", style = MaterialTheme.typography.titleSmall)
            Text("Active session • Verified via Google Identity", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          StatusPill("Active", SoftGreenTint, SuccessGreen)
        }
      }

      SectionHeader("App Info & System States")
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Column {
            Text("Version ${appSettings.latestVersion}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("Min supported: ${appSettings.minSupportedVersion}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          TextButton(onClick = { showUpdateSheet = true }) {
            Icon(Icons.Rounded.SystemUpdate, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("Check Update")
          }
        }
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        OutlinedButton(onClick = onPreviewMaintenance, modifier = Modifier.fillMaxWidth()) {
          Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text("Preview Maintenance Screen")
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Lock, contentDescription = null, tint = PrimaryNavy)
          Spacer(Modifier.width(8.dp))
          Text("Terms & Privacy Policy", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text(appSettings.termsText, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
      }
    }
  }

  if (showUpdateSheet) {
    ModalBottomSheet(onDismissRequest = { showUpdateSheet = false }) {
      Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusPill("v${appSettings.latestVersion} Ready", SoftBlue, RoyalBlue)
        Text("Update Available!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("What's new in Maurya Chemistry 2.0:", style = MaterialTheme.typography.titleSmall)
        listOf(
          "Faster 1080p Chemistry video buffering",
          "Updated 2027 JEE/NEET PYQ archive with solutions",
          "Improved Test Question Palette & dark mode contrast",
        ).forEach { line ->
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(line, style = MaterialTheme.typography.bodyMedium)
          }
        }
        Spacer(Modifier.height(8.dp))
        Button(
          onClick = { showUpdateSheet = false },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { Text("Update Now", color = Color.White) }
        TextButton(onClick = { showUpdateSheet = false }, modifier = Modifier.fillMaxWidth()) {
          Text("Later")
        }
      }
    }
  }
}

@Composable
private fun SettingsToggleRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(icon, contentDescription = title, tint = RoyalBlue)
    Spacer(Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
    }
    Switch(checked = checked, onCheckedChange = onCheckedChange)
  }
}

@Composable
fun HelpAndSupportScreen(
  tickets: List<SupportTicket>,
  onBack: () -> Unit,
  onRaiseTicket: () -> Unit,
) {
  var expandedFaq by remember { mutableStateOf(0) }
  val faqs = listOf(
    "How do I download lectures for offline viewing?" to "Open any lecture in your Batch and tap 'Notes PDF' or use the Downloads tab to save lectures and formula sheets offline.",
    "How does the coupon discount work?" to "Enter valid codes like MAURYA500 at Checkout before selecting UPI, Card, or Net Banking.",
    "When are mock test ranks published?" to "Your score, accuracy, and topic breakdown appear immediately after submission, and All-India leaderboard updates live.",
    "What if a payment fails after money is deducted?" to "Failed transactions auto-refund within 3-5 business days, or you can raise an Order ticket below.",
  )

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "Help & Support", onBack = onBack)
    LazyColumn(
      modifier = Modifier.weight(1f),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item { SectionHeader("Frequently Asked Questions") }
      items(faqs.indices.toList()) { i ->
        val (q, a) = faqs[i]
        val open = expandedFaq == i
        MauryaCard(onClick = { expandedFaq = if (open) -1 else i }, modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(q, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, contentDescription = null)
          }
          if (open) {
            Spacer(Modifier.height(8.dp))
            Text(a, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      }

      item { SectionHeader("My Support Tickets (${tickets.size})") }
      if (tickets.isEmpty()) {
        item {
          MauryaCard(modifier = Modifier.fillMaxWidth()) {
            Text("No open tickets. Need help with an order or class? Raise a ticket below.", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      } else {
        items(tickets, key = { it.id }) { t ->
          MauryaCard(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(t.ticketCode, style = MaterialTheme.typography.labelMedium, color = RoyalBlue, fontWeight = FontWeight.Bold)
              StatusPill(t.status.uppercase(), SoftGreenTint, SuccessGreen)
            }
            Spacer(Modifier.height(4.dp))
            Text(t.subject, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(t.lastReply.ifBlank { t.message }, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = onRaiseTicket,
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("raise_ticket_button"),
        ) {
          Text("Raise Support Ticket", color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ContactSupportScreen(
  onBack: () -> Unit,
  onSubmitTicket: (category: String, orderId: String, subject: String, message: String, contact: String) -> Unit,
) {
  var category by remember { mutableStateOf("Payments") }
  var orderId by remember { mutableStateOf("") }
  var subject by remember { mutableStateOf("") }
  var message by remember { mutableStateOf("") }
  var contact by remember { mutableStateOf("Email") }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    MauryaTopBar(title = "Contact Support", onBack = onBack)
    Column(
      modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text("Issue Category", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Payments", "Video Playback", "Batch Access", "Tests").forEach { c ->
          FilterChip(
            selected = category == c,
            onClick = { category = c },
            label = { Text(c) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      OutlinedTextField(
        value = orderId,
        onValueChange = { orderId = it },
        label = { Text("Order ID (Optional)") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )
      OutlinedTextField(
        value = subject,
        onValueChange = { subject = it },
        label = { Text("Subject") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("ticket_subject_input"),
      )
      OutlinedTextField(
        value = message,
        onValueChange = { message = it },
        label = { Text("Describe your issue") },
        minLines = 4,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("ticket_message_input"),
      )

      Text("Preferred Contact", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Email", "Phone", "WhatsApp").forEach { m ->
          FilterChip(
            selected = contact == m,
            onClick = { contact = m },
            label = { Text(m) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = { onSubmitTicket(category, orderId, subject, message, contact) },
          enabled = subject.isNotBlank() && message.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("submit_ticket_button"),
        ) {
          Text("Submit Ticket", color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
      }
    }
  }
}

@Composable
fun MaintenanceModeScreen(
  etaText: String,
  isAdminUser: Boolean,
  onRetryOrClose: () -> Unit,
  onOpenAdminPortal: () -> Unit,
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Brush.verticalGradient(listOf(PrimaryNavy, PrimaryNavyDeep)))
      .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.14f), modifier = Modifier.size(96.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Rounded.Build, contentDescription = "Maintenance", tint = Color(0xFFFFD84D), modifier = Modifier.size(48.dp))
        }
      }
      Spacer(Modifier.height(20.dp))
      Text("We're Upgrading Maurya Chemistry", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
      Spacer(Modifier.height(8.dp))
      Text("Scheduled server maintenance is underway to improve live streaming stability.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.78f), textAlign = TextAlign.Center)
      Spacer(Modifier.height(18.dp))
      Surface(shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = 0.12f)) {
        Text("Estimated time remaining: $etaText", color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
      }
      Spacer(Modifier.height(24.dp))
      Button(
        onClick = onRetryOrClose,
        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(50.dp),
      ) {
        Text("Retry / Dismiss Preview", color = Color.White)
      }
      if (isAdminUser) {
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = onOpenAdminPortal) {
          Text("Open Admin Settings to Disable Maintenance Mode", color = Color(0xFFFFD84D))
        }
      }
    }
  }
}

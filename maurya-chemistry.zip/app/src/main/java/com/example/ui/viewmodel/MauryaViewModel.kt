package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminAuditLog
import com.example.data.model.AppSettings
import com.example.data.model.Coupon
import com.example.data.model.Course
import com.example.data.model.Doubt
import com.example.data.model.DownloadTaskItem
import com.example.data.model.Enrollment
import com.example.data.model.LiveChatMessage
import com.example.data.model.NotificationItem
import com.example.data.model.PaymentRecord
import com.example.data.model.PromoBanner
import com.example.data.model.SupportTicket
import com.example.data.model.TestAttempt
import com.example.data.model.TestDefinition
import com.example.data.model.UserProfile
import com.example.data.repository.MauryaRepository
import com.example.data.seed.ChemistryContentCatalog
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

data class ActiveTestSession(
  val test: TestDefinition,
  val currentQuestionIndex: Int = 0,
  val selectedAnswers: Map<Int, Int> = emptyMap(),
  val markedForReview: Set<Int> = emptySet(),
  val visitedQuestions: Set<Int> = setOf(0),
  val remainingSeconds: Int = 0,
  val isSubmitted: Boolean = false,
  val lastAttempt: TestAttempt? = null,
)

data class PlayerUiState(
  val lectureId: String = "lec_4",
  val isPlaying: Boolean = true,
  val progressFraction: Float = 0.52f,
  val speed: String = "1.25x",
  val quality: String = "720p",
  val fullscreen: Boolean = false,
  val bookmarkedIds: Set<String> = setOf("lec_2", "lec_4", "lec_6"),
  val completedIds: Set<String> = setOf("lec_1", "lec_2", "lec_3"),
)

class MauryaViewModel(
  private val repository: MauryaRepository,
  val currentUserId: String,
  val userEmail: String,
  val userDisplayName: String,
) : ViewModel() {

  private fun unwrapFirestoreMessage(error: Throwable, fallback: String): String {
    val firestoreError = generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()
    if (firestoreError == null && error is CancellationException) throw error
    val root = firestoreError ?: error
    Log.w("MauryaVM", fallback, root)
    return root.message ?: fallback
  }

  init {
    viewModelScope.launch {
      repository.ensureUserProfile(
        fullName = userDisplayName.ifBlank { "Aarav Sharma" },
        email = userEmail,
      )
    }
  }

  val userProfileState: StateFlow<UiState<UserProfile?>> =
    repository.observeUserProfile(currentUserId)
      .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
      .catch { e -> emit(UiState.Error(unwrapFirestoreMessage(e, "Failed to load profile"))) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val coursesState: StateFlow<List<Course>> =
    repository.observeActiveCourses()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), ChemistryContentCatalog.defaultCourses)

  val bannersState: StateFlow<List<PromoBanner>> =
    repository.observeActiveBanners()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), ChemistryContentCatalog.defaultBanners)

  val couponsState: StateFlow<List<Coupon>> =
    repository.observeActiveCoupons()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val appSettingsState: StateFlow<AppSettings> =
    repository.observeAppSettings()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppSettings(id = "global"))

  val enrollmentsState: StateFlow<List<Enrollment>> =
    repository.observeEnrollments(currentUserId)
      .catch { e -> unwrapFirestoreMessage(e, "Failed enrollments"); emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val paymentsState: StateFlow<List<PaymentRecord>> =
    repository.observePayments(currentUserId)
      .catch { e -> unwrapFirestoreMessage(e, "Failed payments"); emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val testAttemptsState: StateFlow<List<TestAttempt>> =
    repository.observeTestAttempts(currentUserId)
      .catch { e -> unwrapFirestoreMessage(e, "Failed test attempts"); emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val doubtsState: StateFlow<List<Doubt>> =
    repository.observeDoubts(currentUserId)
      .catch { e -> unwrapFirestoreMessage(e, "Failed doubts"); emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val ticketsState: StateFlow<List<SupportTicket>> =
    repository.observeTickets(currentUserId)
      .catch { e -> unwrapFirestoreMessage(e, "Failed tickets"); emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val adminLogsState: StateFlow<List<AdminAuditLog>> =
    repository.observeAdminLogs()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // Local interactive states
  private val _notifications = MutableStateFlow(ChemistryContentCatalog.notifications)
  val notifications = _notifications.asStateFlow()

  private val _downloads = MutableStateFlow(ChemistryContentCatalog.initialDownloads)
  val downloads = _downloads.asStateFlow()

  private val _liveChat = MutableStateFlow(ChemistryContentCatalog.initialLiveChat)
  val liveChat = _liveChat.asStateFlow()

  private val _playerState = MutableStateFlow(PlayerUiState())
  val playerState = _playerState.asStateFlow()

  private val _wishlistCourseIds = MutableStateFlow(setOf("batch_2027_jee"))
  val wishlistCourseIds = _wishlistCourseIds.asStateFlow()

  private val _activeTestSession = MutableStateFlow<ActiveTestSession?>(null)
  val activeTestSession = _activeTestSession.asStateFlow()

  private val _bannerMessage = MutableStateFlow<String?>(null)
  val bannerMessage = _bannerMessage.asStateFlow()

  private val _showProfileSetup = MutableStateFlow(false)
  val showProfileSetup = _showProfileSetup.asStateFlow()

  private var timerJob: Job? = null

  fun dismissBannerMessage() {
    _bannerMessage.value = null
  }

  fun openProfileSetup() {
    _showProfileSetup.value = true
  }

  fun saveStudentProfile(
    fullName: String,
    phone: String,
    studentClass: String,
    board: String,
    examTarget: String,
    language: String,
  ) {
    viewModelScope.launch {
      val result = repository.updateUserProfile(fullName, phone, studentClass, board, examTarget, language)
      _showProfileSetup.value = false
      _bannerMessage.value = if (result.isSuccess) "Profile updated" else result.exceptionOrNull()?.message
    }
  }

  fun toggleDarkMode(enabled: Boolean) {
    viewModelScope.launch {
      val result = repository.toggleDarkMode(enabled)
      if (result.isFailure) {
        _bannerMessage.value = result.exceptionOrNull()?.message ?: "Could not update theme"
      }
    }
  }

  fun toggleWishlist(courseId: String) {
    _wishlistCourseIds.update { set ->
      if (courseId in set) set - courseId else set + courseId
    }
  }

  fun enrollFreeCourse(course: Course, onComplete: () -> Unit) {
    viewModelScope.launch {
      val res = repository.enrollInCourse(course)
      _bannerMessage.value = if (res.isSuccess) {
        "Enrolled in ${course.title}!"
      } else {
        res.exceptionOrNull()?.message ?: "Enrollment failed"
      }
      if (res.isSuccess) onComplete()
    }
  }

  fun completePayment(
    course: Course,
    orderId: String,
    amountPaid: Long,
    discountAmount: Long,
    couponCode: String,
    paymentMethod: String,
    simulateSuccess: Boolean,
    onResult: (Boolean) -> Unit,
  ) {
    viewModelScope.launch {
      val res = repository.recordPaymentAndEnroll(
        course = course,
        orderId = orderId,
        amountPaid = amountPaid,
        discountAmount = discountAmount,
        couponCode = couponCode,
        paymentMethod = paymentMethod,
        success = simulateSuccess,
      )
      if (res.isFailure) {
        _bannerMessage.value = res.exceptionOrNull()?.message ?: "Payment failed"
        onResult(false)
      } else {
        onResult(simulateSuccess)
      }
    }
  }

  fun requestRefund(paymentId: String, reason: String) {
    viewModelScope.launch {
      val res = repository.requestRefund(paymentId, reason)
      _bannerMessage.value = if (res.isSuccess) "Refund request submitted" else res.exceptionOrNull()?.message
    }
  }

  fun advanceEnrollment(enrollment: Enrollment) {
    viewModelScope.launch {
      repository.updateEnrollmentProgress(enrollment, 4L)
      _bannerMessage.value = "Lecture progress saved!"
    }
  }

  // Video Player Controls
  fun selectLecture(lectureId: String) {
    _playerState.update { it.copy(lectureId = lectureId, isPlaying = true, progressFraction = 0.25f) }
  }

  fun togglePlayPause() {
    _playerState.update { it.copy(isPlaying = !it.isPlaying) }
  }

  fun cyclePlaybackSpeed() {
    val speeds = listOf("1.0x", "1.25x", "1.5x", "2.0x")
    _playerState.update {
      val next = speeds[(speeds.indexOf(it.speed) + 1) % speeds.size]
      it.copy(speed = next)
    }
  }

  fun cycleQuality() {
    val qualities = listOf("360p", "480p", "720p", "1080p")
    _playerState.update {
      val next = qualities[(qualities.indexOf(it.quality) + 1) % qualities.size]
      it.copy(quality = next)
    }
  }

  fun toggleFullscreen() {
    _playerState.update { it.copy(fullscreen = !it.fullscreen) }
  }

  fun toggleBookmark(lectureId: String) {
    _playerState.update {
      val next = if (lectureId in it.bookmarkedIds) it.bookmarkedIds - lectureId else it.bookmarkedIds + lectureId
      it.copy(bookmarkedIds = next)
    }
  }

  fun markLectureCompleted(lectureId: String) {
    _playerState.update { it.copy(completedIds = it.completedIds + lectureId) }
    _bannerMessage.value = "Lecture marked as complete"
  }

  // Live Chat
  fun sendLiveChatMessage(text: String) {
    val trimmed = text.trim()
    if (trimmed.isBlank()) return
    val name = (userProfileState.value as? UiState.Success)?.data?.fullName?.ifBlank { "Aarav" } ?: "Aarav"
    _liveChat.update {
      it + LiveChatMessage(
        id = "chat_${System.currentTimeMillis()}",
        senderName = name,
        text = trimmed,
        timeLabel = "Just now",
        fromMentor = false,
      )
    }
  }

  // Notifications & Downloads
  fun markAllNotificationsRead() {
    _notifications.update { list -> list.map { it.copy(unread = false) } }
  }

  fun toggleDownloadPause(taskId: String) {
    _downloads.update { list ->
      list.map { item ->
        if (item.id == taskId) {
          val nextState = when (item.state) {
            "active" -> "paused"
            "paused", "failed" -> "active"
            else -> item.state
          }
          item.copy(state = nextState, speedLabel = if (nextState == "paused") "Paused" else "3.2 MB/s • Resuming")
        } else item
      }
    }
  }

  fun clearCompletedDownloads() {
    _downloads.update { list -> list.filterNot { it.state == "completed" } }
  }

  fun startDownload(title: String, type: String, size: String) {
    _downloads.update { list ->
      list + DownloadTaskItem(
        id = "dl_${System.currentTimeMillis()}",
        title = title,
        fileType = type,
        sizeLabel = size,
        progressPercent = 100,
        speedLabel = "Completed",
        state = "completed",
        timestampLabel = "Downloaded just now",
      )
    }
    _bannerMessage.value = "Saved $title for offline study"
  }

  // Test Engine
  fun startTest(test: TestDefinition) {
    timerJob?.cancel()
    _activeTestSession.value = ActiveTestSession(
      test = test,
      currentQuestionIndex = 0,
      remainingSeconds = test.durationMinutes * 60,
    )
    timerJob = viewModelScope.launch {
      while (true) {
        delay(1000L)
        val current = _activeTestSession.value ?: break
        if (current.isSubmitted) break
        if (current.remainingSeconds <= 1) {
          submitActiveTest()
          break
        }
        _activeTestSession.value = current.copy(remainingSeconds = current.remainingSeconds - 1)
      }
    }
  }

  fun selectAnswer(questionIndex: Int, optionIndex: Int) {
    _activeTestSession.update { session ->
      session?.copy(
        selectedAnswers = session.selectedAnswers + (questionIndex to optionIndex),
        visitedQuestions = session.visitedQuestions + questionIndex,
      )
    }
  }

  fun clearAnswer(questionIndex: Int) {
    _activeTestSession.update { session ->
      session?.copy(selectedAnswers = session.selectedAnswers - questionIndex)
    }
  }

  fun toggleMarkForReview(questionIndex: Int) {
    _activeTestSession.update { session ->
      if (session == null) null
      else {
        val next = if (questionIndex in session.markedForReview) {
          session.markedForReview - questionIndex
        } else {
          session.markedForReview + questionIndex
        }
        session.copy(markedForReview = next)
      }
    }
  }

  fun jumpToQuestion(index: Int) {
    _activeTestSession.update { session ->
      session?.copy(
        currentQuestionIndex = index.coerceIn(0, (session.test.questionCount - 1).coerceAtLeast(0)),
        visitedQuestions = session.visitedQuestions + index,
      )
    }
  }

  fun submitActiveTest() {
    timerJob?.cancel()
    val session = _activeTestSession.value ?: return
    val questions = ChemistryContentCatalog.chemistryQuestions.take(session.test.questionCount)
    var correct = 0L
    var wrong = 0L
    var physOk = 0
    var physTotal = 0
    var orgOk = 0
    var orgTotal = 0
    var inorgOk = 0
    var inorgTotal = 0

    questions.forEachIndexed { idx, q ->
      when (q.subject) {
        "Physical" -> physTotal++
        "Organic" -> orgTotal++
        else -> inorgTotal++
      }
      val chosen = session.selectedAnswers[idx]
      if (chosen != null) {
        if (chosen == q.correctIndex) {
          correct++
          when (q.subject) {
            "Physical" -> physOk++
            "Organic" -> orgOk++
            else -> inorgOk++
          }
        } else {
          wrong++
        }
      }
    }
    val unattempted = (questions.size - correct - wrong).coerceAtLeast(0L)
    val score = (correct * 4L) - wrong
    val attempted = (correct + wrong).coerceAtLeast(1L)
    val accuracy = ((correct * 100L) / attempted).coerceIn(0L, 100L)
    val elapsed = (session.test.durationMinutes * 60 - session.remainingSeconds).coerceAtLeast(15)

    val attempt = TestAttempt(
      userId = currentUserId,
      testId = session.test.id,
      testTitle = session.test.title,
      subject = session.test.category,
      score = score,
      maxMarks = session.test.maxMarks.toLong(),
      correctCount = correct,
      wrongCount = wrong,
      unattemptedCount = unattempted,
      accuracyPercent = accuracy,
      durationSeconds = elapsed.toLong(),
      physicalScore = if (physTotal > 0) ((physOk * 100L) / physTotal) else 80L,
      organicScore = if (orgTotal > 0) ((orgOk * 100L) / orgTotal) else 70L,
      inorganicScore = if (inorgTotal > 0) ((inorgOk * 100L) / inorgTotal) else 75L,
    )

    _activeTestSession.value = session.copy(isSubmitted = true, lastAttempt = attempt)
    viewModelScope.launch {
      repository.saveTestAttempt(attempt)
    }
  }

  // Doubts & Support
  fun submitDoubt(subject: String, chapter: String, difficulty: String, question: String, onSuccess: () -> Unit) {
    viewModelScope.launch {
      val res = repository.submitDoubt(subject, chapter, difficulty, question)
      if (res.isSuccess) {
        _bannerMessage.value = "Doubt submitted! Dr. R. Verma responds in ~2 hours."
        onSuccess()
      } else {
        _bannerMessage.value = res.exceptionOrNull()?.message ?: "Failed to submit doubt"
      }
    }
  }

  fun submitSupportTicket(
    category: String,
    orderId: String,
    subject: String,
    message: String,
    contactMethod: String,
    onSuccess: () -> Unit,
  ) {
    viewModelScope.launch {
      val res = repository.createSupportTicket(category, orderId, subject, message, contactMethod)
      if (res.isSuccess) {
        _bannerMessage.value = "Support ticket raised!"
        onSuccess()
      } else {
        _bannerMessage.value = res.exceptionOrNull()?.message ?: "Could not raise ticket"
      }
    }
  }

  // Admin Actions
  fun createBanner(title: String, subtitle: String, ctaText: String) {
    viewModelScope.launch {
      val res = repository.createAdminBanner(title, subtitle, ctaText)
      _bannerMessage.value = if (res.isSuccess) "Banner published to Home Carousel" else res.exceptionOrNull()?.message
    }
  }

  fun createCoupon(code: String, type: String, value: Long, maxUsage: Long) {
    viewModelScope.launch {
      val res = repository.createAdminCoupon(code, type, value, maxUsage)
      _bannerMessage.value = if (res.isSuccess) "Coupon $code created" else res.exceptionOrNull()?.message
    }
  }

  fun updateAppSettings(settings: AppSettings, detail: String) {
    viewModelScope.launch {
      val res = repository.updateGlobalSettings(settings, detail)
      _bannerMessage.value = if (res.isSuccess) detail else res.exceptionOrNull()?.message
    }
  }

  fun processRefundAdmin(studentUid: String, paymentId: String, approve: Boolean) {
    viewModelScope.launch {
      val res = repository.processRefundAsAdmin(studentUid, paymentId, approve)
      _bannerMessage.value = if (res.isSuccess) {
        if (approve) "Refund approved & processed" else "Refund rejected"
      } else res.exceptionOrNull()?.message
    }
  }

  fun sendPushBroadcast(title: String, targetBatch: String) {
    _notifications.update { list ->
      listOf(
        NotificationItem(
          id = "n_${System.currentTimeMillis()}",
          title = title,
          body = "Broadcast sent to $targetBatch",
          timeLabel = "Just now",
          section = "Today",
          kind = "class",
          unread = true,
        )
      ) + list
    }
    _bannerMessage.value = "Push notification dispatched to $targetBatch"
  }

  override fun onCleared() {
    timerJob?.cancel()
    super.onCleared()
  }
}

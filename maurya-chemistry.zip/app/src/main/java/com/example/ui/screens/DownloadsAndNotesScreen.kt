package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DownloadTaskItem
import com.example.data.model.NoteDocument
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.components.CircularProgressRing
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun DownloadsDashboardScreen(
  downloads: List<DownloadTaskItem>,
  onTogglePause: (String) -> Unit,
  onClearCompleted: () -> Unit,
  onOpenNotePdf: (NoteDocument) -> Unit,
  onDownloadItem: (String, String, String) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var selectedSubject by remember { mutableStateOf("All") }
  var selectedExam by remember { mutableStateOf("All") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "Downloads & Library",
      actions = {
        TextButton(onClick = onClearCompleted) {
          Text("Clear", color = Color.White)
        }
      },
    )

    TabRow(selectedTabIndex = selectedTab) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Manager", maxLines = 1) })
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Notes", maxLines = 1) })
      Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Formulas", maxLines = 1) })
      Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("PYQs", maxLines = 1) })
    }

    when (selectedTab) {
      0 -> {
        LazyColumn(
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          item {
            MauryaCard(modifier = Modifier.fillMaxWidth()) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressRing(
                  progress = 0.30f,
                  centerText = "2.4 GB",
                  subLabel = "of 8 GB",
                  ringColor = RoyalBlue,
                  size = 84.dp,
                )
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text("Offline Storage", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                  Text("Study lectures & PDFs without internet.", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  Spacer(Modifier.height(6.dp))
                  Text("${downloads.count { it.state == "completed" }} items ready offline", style = MaterialTheme.typography.labelMedium, color = SuccessGreen)
                }
              }
            }
          }

          val active = downloads.filter { it.state == "active" || it.state == "paused" }
          if (active.isNotEmpty()) {
            item { SectionHeader("Active Downloads (${active.size})") }
            items(active, key = { it.id }) { task ->
              MauryaCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = if (task.fileType == "video") Icons.Rounded.VideoFile else Icons.Rounded.PictureAsPdf,
                    contentDescription = null,
                    tint = if (task.fileType == "video") RoyalBlue else ErrorRed,
                  )
                  Spacer(Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(task.title, style = MaterialTheme.typography.titleSmall)
                    Text(task.speedLabel, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                      progress = { task.progressPercent / 100f },
                      color = RoyalBlue,
                      modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    )
                  }
                  IconButton(onClick = { onTogglePause(task.id) }) {
                    Icon(
                      imageVector = if (task.state == "active") Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                      contentDescription = "Pause or Resume",
                      tint = WarningAmber,
                    )
                  }
                }
              }
            }
          }

          val completed = downloads.filter { it.state == "completed" }
          if (completed.isNotEmpty()) {
            item { SectionHeader("Completed") }
            items(completed, key = { it.id }) { task ->
              MauryaCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = if (task.fileType == "video") Icons.Rounded.VideoFile else Icons.Rounded.PictureAsPdf,
                    contentDescription = null,
                    tint = if (task.fileType == "video") RoyalBlue else ErrorRed,
                  )
                  Spacer(Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(task.title, style = MaterialTheme.typography.titleSmall)
                    Text("${task.sizeLabel} • ${task.timestampLabel}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  }
                  Icon(Icons.Rounded.CheckCircle, contentDescription = "Ready", tint = SuccessGreen)
                }
              }
            }
          }

          val failed = downloads.filter { it.state == "failed" }
          if (failed.isNotEmpty()) {
            item { SectionHeader("Failed") }
            items(failed, key = { it.id }) { task ->
              MauryaCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(task.title, style = MaterialTheme.typography.titleSmall)
                    Text(task.speedLabel, style = MaterialTheme.typography.bodySmall, color = ErrorRed)
                  }
                  OutlinedButton(onClick = { onTogglePause(task.id) }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Retry")
                  }
                }
              }
            }
          }
        }
      }

      1 -> {
        val subjects = listOf("All", "Physical", "Organic", "Inorganic")
        val notes = ChemistryContentCatalog.notesLibrary.filter { selectedSubject == "All" || it.subject == selectedSubject }
        Column(modifier = Modifier.fillMaxSize()) {
          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(subjects) { s ->
              FilterChip(
                selected = selectedSubject == s,
                onClick = { selectedSubject = s },
                label = { Text(s) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
              )
            }
          }
          LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            items(notes, key = { it.id }) { note ->
              MauryaCard(onClick = { onOpenNotePdf(note) }, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(34.dp))
                  Spacer(Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(note.title, style = MaterialTheme.typography.titleSmall)
                    Text("${note.subject} • ${note.pages} pages • ${note.sizeLabel}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  }
                  IconButton(onClick = { onDownloadItem("${note.title}.pdf", "pdf", note.sizeLabel) }) {
                    Icon(Icons.Rounded.Download, contentDescription = "Download PDF", tint = RoyalBlue)
                  }
                }
              }
            }
          }
        }
      }

      2 -> {
        var expandedNoteId by remember { mutableStateOf(ChemistryContentCatalog.notesLibrary.first().id) }
        LazyColumn(
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          items(ChemistryContentCatalog.notesLibrary, key = { it.id }) { note ->
            val expanded = expandedNoteId == note.id
            MauryaCard(
              onClick = { expandedNoteId = note.id },
              containerColor = if (expanded) MauryaTheme.colors.softBlue else MauryaTheme.colors.cardBackground,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = SoftPurpleTint, modifier = Modifier.size(40.dp)) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Functions, contentDescription = null, tint = PrimaryNavy)
                  }
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(note.chapter, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                  Text("${note.sampleFormulas.size} key formulas", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
                }
                Text(if (expanded) "Hide" else "View", color = RoyalBlue, style = MaterialTheme.typography.labelMedium)
              }
              if (expanded) {
                Spacer(Modifier.height(10.dp))
                note.sampleFormulas.forEach { formula ->
                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MauryaTheme.colors.cardBackground,
                    border = BorderStroke(1.dp, MauryaTheme.colors.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                  ) {
                    Text(
                      text = formula,
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.SemiBold,
                      modifier = Modifier.padding(10.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }

      else -> {
        val exams = listOf("All", "JEE Main", "JEE Advanced", "NEET")
        val papers = ChemistryContentCatalog.pyqPapers.filter { selectedExam == "All" || it.exam == selectedExam }
        Column(modifier = Modifier.fillMaxSize()) {
          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(exams) { e ->
              FilterChip(
                selected = selectedExam == e,
                onClick = { selectedExam = e },
                label = { Text(e) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
              )
            }
          }
          LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            items(papers, key = { it.id }) { paper ->
              MauryaCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(shape = RoundedCornerShape(10.dp), color = PrimaryNavy) {
                    Text(paper.year, color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                  }
                  Spacer(Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(paper.title, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    StatusPill("Solutions Available", MauryaTheme.colors.softGreenTint, SuccessGreen)
                  }
                  IconButton(onClick = { onDownloadItem("${paper.title}.pdf", "pdf", "3.4 MB") }) {
                    Icon(Icons.Rounded.Download, contentDescription = "Download Paper", tint = RoyalBlue)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun PdfViewerScreen(
  note: NoteDocument,
  onBack: () -> Unit,
  onDownload: () -> Unit,
) {
  var page by remember { mutableIntStateOf(1) }
  var zoomPercent by remember { mutableIntStateOf(100) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF1A2233)),
  ) {
    MauryaTopBar(
      title = note.title,
      subtitle = "${note.subject} • ${note.pages} pages",
      onBack = onBack,
      actions = {
        IconButton(onClick = onDownload) {
          Icon(Icons.Rounded.Download, contentDescription = "Download", tint = Color.White)
        }
      },
    )

    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        shadowElevation = 6.dp,
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState()),
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text(
            text = "MAURYA CHEMISTRY CLASSES 2.0",
            style = MaterialTheme.typography.labelSmall,
            color = RoyalBlue,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.height(4.dp))
          Text(
            text = "${note.chapter} — High-Yield Summary (Page $page)",
            style = MaterialTheme.typography.titleLarge,
            color = PrimaryNavy,
          )
          Spacer(Modifier.height(14.dp))
          note.sampleFormulas.forEachIndexed { idx, formula ->
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = SoftBlue,
              modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            ) {
              Text(
                text = "${idx + 1}. $formula",
                style = MaterialTheme.typography.bodyLarge,
                color = PrimaryNavy,
                modifier = Modifier.padding(14.dp),
              )
            }
          }
          Spacer(Modifier.height(14.dp))
          Text(
            text = "Exam Tip: Memorize hybridisation steric numbers and compare lone-pair repulsions (lp-lp > lp-bp > bp-bp) when solving JEE Main & NEET assertion-reason questions.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF475569),
          )
        }
      }
    }

    Surface(
      shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
      color = Color(0xFF0E1729),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedButton(onClick = { if (page > 1) page-- }) {
          Text("Prev", color = Color.White)
        }
        Spacer(Modifier.width(8.dp))
        Text("$page / ${note.pages}", color = Color.White, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { if (page < note.pages) page++ }) {
          Text("Next", color = Color.White)
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { if (zoomPercent > 80) zoomPercent -= 10 }) { Text("-", color = Color.White) }
        Text("${zoomPercent}%", color = Color.White, style = MaterialTheme.typography.labelMedium)
        TextButton(onClick = { if (zoomPercent < 150) zoomPercent += 10 }) { Text("+", color = Color.White) }
      }
    }
  }
}

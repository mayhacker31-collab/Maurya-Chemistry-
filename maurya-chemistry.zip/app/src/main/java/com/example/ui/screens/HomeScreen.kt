package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Course
import com.example.data.model.Enrollment
import com.example.data.model.MentorProfile
import com.example.data.model.NotificationItem
import com.example.data.model.PromoBanner
import com.example.data.model.TestAttempt
import com.example.data.model.UserProfile
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SoftYellow
import com.example.ui.theme.SoftYellowTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun HomeDashboardScreen(
  profile: UserProfile?,
  courses: List<Course>,
  banners: List<PromoBanner>,
  enrollments: List<Enrollment>,
  recentAttempts: List<TestAttempt>,
  unreadNotifications: Int,
  onOpenNotifications: () -> Unit,
  onOpenExplorer: (String) -> Unit,
  onOpenCourseDetail: (Course) -> Unit,
  onOpenBatchDetail: (Enrollment) -> Unit,
  onResumeLecture: () -> Unit,
  onJoinLiveClass: () -> Unit,
  onStartDailyQuiz: () -> Unit,
  onOpenMentor: (MentorProfile) -> Unit,
  onOpenProfile: () -> Unit,
) {
  val studentName = profile?.fullName?.split(" ")?.firstOrNull()?.ifBlank { "Aarav" } ?: "Aarav"
  val subtitle = "${profile?.studentClass ?: "Class 12"} • ${profile?.examTarget ?: "JEE"} 2027"
  val liveClass = ChemistryContentCatalog.liveClasses.first()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    // Top App Bar + Search Bar
    item {
      Surface(
        color = MauryaTheme.colors.cardBackground,
        shadowElevation = 2.dp,
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Namaste, $studentName 👋",
                style = MaterialTheme.typography.headlineSmall,
                color = MauryaTheme.colors.textPrimary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MauryaTheme.colors.textSecondary,
              )
            }
            Box {
              IconButton(
                onClick = onOpenNotifications,
                modifier = Modifier.testTag("home_notifications_button"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Notifications,
                  contentDescription = "Notifications",
                  tint = MauryaTheme.colors.textPrimary,
                )
              }
              if (unreadNotifications > 0) {
                Box(
                  modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 10.dp, end = 10.dp)
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(ErrorRed)
                )
              }
            }
            Spacer(Modifier.width(4.dp))
            Image(
              painter = painterResource(id = R.drawable.img_mentor_avatar),
              contentDescription = "Profile Avatar",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .clickable(onClick = onOpenProfile),
            )
          }

          Spacer(Modifier.height(12.dp))
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.background,
            border = BorderStroke(1.dp, MauryaTheme.colors.border),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onOpenExplorer("All") }
              .testTag("home_search_bar"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = "Search",
                tint = MauryaTheme.colors.textSecondary,
              )
              Spacer(Modifier.width(10.dp))
              Text(
                text = "Search Chemistry courses, chapters, tests...",
                style = MaterialTheme.typography.bodyMedium,
                color = MauryaTheme.colors.textSecondary,
                modifier = Modifier.weight(1f),
              )
              Icon(
                imageVector = Icons.Rounded.Tune,
                contentDescription = "Filters",
                tint = MauryaTheme.colors.royalBlue,
              )
            }
          }
        }
      }
    }

    // Promo Carousel Banner (Screen 11)
    item {
      val pagerState = rememberPagerState(pageCount = { banners.size.coerceAtLeast(1) })
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        HorizontalPager(state = pagerState) { idx ->
          val banner = banners.getOrNull(idx) ?: ChemistryContentCatalog.defaultBanners.first()
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(22.dp))
              .background(
                Brush.linearGradient(listOf(PrimaryNavy, RoyalBlue))
              )
              .padding(18.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Column(modifier = Modifier.weight(1f)) {
                StatusPill(
                  text = "MAURYA 2.0 SPECIAL",
                  containerColor = Color.White.copy(alpha = 0.16f),
                  contentColor = SoftYellow,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                  text = banner.title,
                  style = MaterialTheme.typography.titleLarge,
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                  text = banner.subtitle,
                  style = MaterialTheme.typography.bodySmall,
                  color = Color.White.copy(alpha = 0.85f),
                )
                Spacer(Modifier.height(12.dp))
                Surface(
                  shape = RoundedCornerShape(50),
                  color = Color.White,
                  modifier = Modifier.clickable { onOpenExplorer("All") },
                ) {
                  Text(
                    text = banner.ctaText,
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryNavy,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                  )
                }
              }
              Spacer(Modifier.width(12.dp))
              Image(
                painter = painterResource(id = R.drawable.img_course_banner),
                contentDescription = "Chemistry Banner Art",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                  .size(92.dp)
                  .clip(RoundedCornerShape(16.dp)),
              )
            }
          }
        }
        Spacer(Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
        ) {
          repeat(banners.size) { i ->
            val active = pagerState.currentPage == i
            Box(
              modifier = Modifier
                .padding(horizontal = 3.dp)
                .height(6.dp)
                .width(if (active) 18.dp else 6.dp)
                .clip(CircleShape)
                .background(if (active) RoyalBlue else MauryaTheme.colors.border)
            )
          }
        }
      }
    }

    // Continue Learning
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(title = "Continue Learning", actionLabel = "Playlist", onAction = onResumeLecture)
        MauryaCard(onClick = onResumeLecture, modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(PrimaryNavy),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Rounded.PlayArrow,
                contentDescription = "Resume Lecture",
                tint = Color.White,
                modifier = Modifier.size(32.dp),
              )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Chemical Bonding — L4 Hybridisation",
                style = MaterialTheme.typography.titleSmall,
                color = MauryaTheme.colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "Dr. R. Verma • 24:18",
                style = MaterialTheme.typography.bodySmall,
                color = MauryaTheme.colors.textSecondary,
              )
              Spacer(Modifier.height(8.dp))
              LinearProgressIndicator(
                progress = { 0.68f },
                color = RoyalBlue,
                trackColor = MauryaTheme.colors.softBlue,
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
              )
            }
            Spacer(Modifier.width(12.dp))
            Surface(
              shape = RoundedCornerShape(50),
              color = RoyalBlue,
            ) {
              Text(
                text = "Resume",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              )
            }
          }
        }
      }
    }

    // Live Now Card
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(title = "Live Now 🔴", actionLabel = "Schedule", onAction = onJoinLiveClass)
        MauryaCard(
          onClick = onJoinLiveClass,
          containerColor = if (MauryaTheme.colors.isDark) MauryaTheme.colors.cardBackground else Color.White,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                StatusPill(
                  text = "● LIVE",
                  containerColor = ErrorRedTint,
                  contentColor = ErrorRed,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                  text = liveClass.viewerCount,
                  style = MaterialTheme.typography.labelSmall,
                  color = MauryaTheme.colors.textSecondary,
                )
              }
              Spacer(Modifier.height(8.dp))
              Text(
                text = liveClass.title,
                style = MaterialTheme.typography.titleMedium,
                color = MauryaTheme.colors.textPrimary,
              )
              Text(
                text = "${liveClass.mentorName} • ${liveClass.subject}",
                style = MaterialTheme.typography.bodySmall,
                color = MauryaTheme.colors.textSecondary,
              )
            }
            Button(
              onClick = onJoinLiveClass,
              shape = RoundedCornerShape(50),
              colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
              modifier = Modifier.testTag("home_join_live_button"),
            ) {
              Text("Join", color = Color.White)
            }
          }
        }
      }
    }

    // Exam Categories Grid Quick Strip
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(
          title = "Explore by Goal",
          actionLabel = "See All",
          onAction = { onOpenExplorer("All") },
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          val goals = listOf(
            Triple("JEE", SoftOrangeTint, WarningAmber),
            Triple("NEET", SoftGreenTint, SuccessGreen),
            Triple("CBSE", SoftPurpleTint, RoyalBlue),
            Triple("Foundation", SoftYellowTint, Color(0xFFB37B00)),
          )
          items(goals) { (label, bg, accent) ->
            Surface(
              shape = RoundedCornerShape(18.dp),
              color = if (MauryaTheme.colors.isDark) MauryaTheme.colors.cardBackground else bg,
              border = BorderStroke(1.dp, MauryaTheme.colors.border),
              modifier = Modifier
                .width(124.dp)
                .clickable { onOpenExplorer(label) },
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Icon(
                  imageVector = Icons.Rounded.Science,
                  contentDescription = label,
                  tint = accent,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                  text = label,
                  style = MaterialTheme.typography.titleSmall,
                  color = MauryaTheme.colors.textPrimary,
                )
                Text(
                  text = "Courses & Tests",
                  style = MaterialTheme.typography.labelSmall,
                  color = MauryaTheme.colors.textSecondary,
                )
              }
            }
          }
        }
      }
    }

    // Active Batches (if any)
    if (enrollments.isNotEmpty()) {
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
          SectionHeader(title = "My Active Batches")
          LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(enrollments, key = { it.id }) { batch ->
              MauryaCard(
                onClick = { onOpenBatchDetail(batch) },
                modifier = Modifier.width(240.dp),
              ) {
                Text(
                  text = batch.courseTitle,
                  style = MaterialTheme.typography.titleSmall,
                  color = MauryaTheme.colors.textPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = batch.mentorName,
                  style = MaterialTheme.typography.bodySmall,
                  color = MauryaTheme.colors.textSecondary,
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                  progress = { (batch.progressPercent / 100f).coerceIn(0f, 1f) },
                  color = SuccessGreen,
                  trackColor = MauryaTheme.colors.softGreenTint,
                  modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                  text = "${batch.progressPercent}% completed",
                  style = MaterialTheme.typography.labelSmall,
                  color = SuccessGreen,
                )
              }
            }
          }
        }
      }
    }

    // Popular Courses
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(
          title = "Popular Courses",
          actionLabel = "Explore All",
          onAction = { onOpenExplorer("All") },
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          courses.take(3).forEach { course ->
            CourseListCard(course = course, onClick = { onOpenCourseDetail(course) })
          }
        }
      }
    }

    // Top Mentors
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(title = "Top Chemistry Mentors")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
          items(ChemistryContentCatalog.mentors, key = { it.id }) { mentor ->
            MauryaCard(
              onClick = { onOpenMentor(mentor) },
              modifier = Modifier.width(148.dp),
            ) {
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Image(
                  painter = painterResource(id = R.drawable.img_mentor_avatar),
                  contentDescription = mentor.name,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.size(64.dp).clip(CircleShape),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                  text = mentor.name,
                  style = MaterialTheme.typography.titleSmall,
                  color = MauryaTheme.colors.textPrimary,
                  maxLines = 1,
                )
                Text(
                  text = mentor.subject,
                  style = MaterialTheme.typography.labelSmall,
                  color = MauryaTheme.colors.textSecondary,
                  maxLines = 1,
                )
              }
            }
          }
        }
      }
    }

    // Daily Practice & Recent Test Card
    item {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(RoyalBlue, AccentBlue)))
            .clickable(onClick = onStartDailyQuiz)
            .padding(18.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Rounded.Quiz,
              contentDescription = "Daily Quiz",
              tint = Color.White,
              modifier = Modifier.size(36.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Daily Chemistry Practice",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = "5 Qs • 10 min • Hybridisation & Bonding",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.9f),
              )
            }
            Surface(shape = RoundedCornerShape(50), color = Color.White) {
              Text(
                text = "Start",
                style = MaterialTheme.typography.labelMedium,
                color = PrimaryNavy,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
              )
            }
          }
        }

        val lastTest = recentAttempts.firstOrNull()
        if (lastTest != null) {
          MauryaCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Recent Test Score",
                  style = MaterialTheme.typography.labelMedium,
                  color = MauryaTheme.colors.textSecondary,
                )
                Text(
                  text = lastTest.testTitle,
                  style = MaterialTheme.typography.titleSmall,
                  color = MauryaTheme.colors.textPrimary,
                )
              }
              StatusPill(
                text = "${lastTest.score}/${lastTest.maxMarks} • ${lastTest.accuracyPercent}%",
                containerColor = MauryaTheme.colors.softGreenTint,
                contentColor = SuccessGreen,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun CourseListCard(
  course: Course,
  onClick: () -> Unit,
) {
  MauryaCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Image(
        painter = painterResource(id = R.drawable.img_course_banner),
        contentDescription = course.title,
        contentScale = ContentScale.Crop,
        modifier = Modifier
          .size(84.dp)
          .clip(RoundedCornerShape(14.dp)),
      )
      Spacer(Modifier.width(14.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          StatusPill(
            text = if (course.freeCourse) "FREE" else "${course.discountPercent}% OFF",
            containerColor = if (course.freeCourse) MauryaTheme.colors.softGreenTint else MauryaTheme.colors.softBlue,
            contentColor = if (course.freeCourse) SuccessGreen else MauryaTheme.colors.royalBlue,
          )
          Spacer(Modifier.width(6.dp))
          Icon(
            imageVector = Icons.Rounded.Star,
            contentDescription = null,
            tint = WarningAmber,
            modifier = Modifier.size(14.dp),
          )
          Text(
            text = " ${course.rating}",
            style = MaterialTheme.typography.labelSmall,
            color = MauryaTheme.colors.textPrimary,
          )
        }
        Spacer(Modifier.height(6.dp))
        Text(
          text = course.title,
          style = MaterialTheme.typography.titleSmall,
          color = MauryaTheme.colors.textPrimary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = "${course.mentorName} • ${course.lectureCount} Lectures",
          style = MaterialTheme.typography.bodySmall,
          color = MauryaTheme.colors.textSecondary,
        )
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (course.freeCourse) {
            Text(
              text = "Free Access",
              style = MaterialTheme.typography.titleSmall,
              color = SuccessGreen,
              fontWeight = FontWeight.Bold,
            )
          } else {
            Text(
              text = "₹${course.price}",
              style = MaterialTheme.typography.titleSmall,
              color = MauryaTheme.colors.textPrimary,
              fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(6.dp))
            Text(
              text = "₹${course.mrp}",
              style = MaterialTheme.typography.bodySmall.copy(textDecoration = TextDecoration.LineThrough),
              color = MauryaTheme.colors.textSecondary,
            )
          }
          Spacer(Modifier.weight(1f))
          Text(
            text = "View →",
            style = MaterialTheme.typography.labelMedium,
            color = MauryaTheme.colors.royalBlue,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CourseExplorerScreen(
  courses: List<Course>,
  initialCategory: String,
  onBack: () -> Unit,
  onSelectCourse: (Course) -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(initialCategory) }
  var onlyFree by remember { mutableStateOf(false) }
  var showFilterSheet by remember { mutableStateOf(false) }

  val categories = listOf("All", "JEE", "NEET", "CBSE", "Foundation")
  val filtered = remember(courses, searchQuery, selectedCategory, onlyFree) {
    courses.filter { c ->
      val catMatch = selectedCategory == "All" || c.category.equals(selectedCategory, ignoreCase = true)
      val freeMatch = !onlyFree || c.freeCourse
      val queryMatch = searchQuery.isBlank() ||
        c.title.contains(searchQuery, ignoreCase = true) ||
        c.mentorName.contains(searchQuery, ignoreCase = true) ||
        c.category.contains(searchQuery, ignoreCase = true)
      catMatch && freeMatch && queryMatch
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "Explore Courses",
      onBack = onBack,
      actions = {
        IconButton(onClick = { showFilterSheet = true }) {
          Icon(Icons.Rounded.FilterList, contentDescription = "Filter Courses", tint = Color.White)
        }
      },
    )

    Column(modifier = Modifier.padding(16.dp)) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search organic, bonding, JEE...") },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Rounded.Close, contentDescription = "Clear search")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().testTag("explorer_search_input"),
      )

      Spacer(Modifier.height(10.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(categories) { cat ->
          FilterChip(
            selected = selectedCategory == cat,
            onClick = { selectedCategory = cat },
            label = { Text(cat) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = RoyalBlue,
              selectedLabelColor = Color.White,
            ),
          )
        }
      }
    }

    if (filtered.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Rounded.School,
            contentDescription = null,
            tint = MauryaTheme.colors.textSecondary,
            modifier = Modifier.size(48.dp),
          )
          Spacer(Modifier.height(8.dp))
          Text(
            text = "No courses matched your filter",
            style = MaterialTheme.typography.titleMedium,
            color = MauryaTheme.colors.textPrimary,
          )
          TextButton(onClick = { searchQuery = ""; selectedCategory = "All"; onlyFree = false }) {
            Text("Reset Filters")
          }
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        items(filtered, key = { it.id }) { course ->
          CourseListCard(course = course, onClick = { onSelectCourse(course) })
        }
      }
    }
  }

  if (showFilterSheet) {
    ModalBottomSheet(onDismissRequest = { showFilterSheet = false }) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text("Filter Courses", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Text("Goal", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          categories.forEach { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat) },
            )
          }
        }
        Spacer(Modifier.height(12.dp))
        FilterChip(
          selected = onlyFree,
          onClick = { onlyFree = !onlyFree },
          label = { Text("Free Courses Only") },
        )
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedButton(
            onClick = { selectedCategory = "All"; onlyFree = false; showFilterSheet = false },
            modifier = Modifier.weight(1f),
          ) { Text("Reset") }
          Button(
            onClick = { showFilterSheet = false },
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
            modifier = Modifier.weight(1f),
          ) { Text("Apply Filters", color = Color.White) }
        }
        Spacer(Modifier.height(20.dp))
      }
    }
  }
}

@Composable
fun CourseDetailsScreen(
  course: Course,
  isEnrolled: Boolean,
  isWishlisted: Boolean,
  onToggleWishlist: () -> Unit,
  onBack: () -> Unit,
  onOpenMentor: (MentorProfile) -> Unit,
  onBuyOrEnroll: () -> Unit,
  onOpenEnrolledBatch: () -> Unit,
  onPreviewLecture: (String) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("Overview", "Curriculum", "Mentor", "Reviews")
  val mentor = ChemistryContentCatalog.mentors.firstOrNull { it.name == course.mentorName }
    ?: ChemistryContentCatalog.mentors.first()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = if (course.freeCourse) "Free Course" else "Course Details",
      onBack = onBack,
      actions = {
        IconButton(onClick = onToggleWishlist) {
          Icon(
            imageVector = if (isWishlisted) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
            contentDescription = "Wishlist",
            tint = Color.White,
          )
        }
      },
    )

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState()),
    ) {
      Box {
        Image(
          painter = painterResource(id = R.drawable.img_course_banner),
          contentDescription = course.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxWidth().height(190.dp),
        )
        if (course.freeCourse) {
          StatusPill(
            text = "FREE ACCESS",
            containerColor = SuccessGreen,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
          )
        }
      }

      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = course.title,
          style = MaterialTheme.typography.headlineSmall,
          color = MauryaTheme.colors.textPrimary,
          fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text = course.subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = MauryaTheme.colors.textSecondary,
        )
        Spacer(Modifier.height(12.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clickable { onOpenMentor(mentor) },
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_mentor_avatar),
            contentDescription = mentor.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(36.dp).clip(CircleShape),
          )
          Spacer(Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(mentor.name, style = MaterialTheme.typography.titleSmall)
            Text(mentor.qualification, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
          StatusPill(
            text = "Star Mentor ★ ${mentor.rating}",
            containerColor = MauryaTheme.colors.softYellowTint,
            contentColor = Color(0xFF8C5B00),
          )
        }

        Spacer(Modifier.height(14.dp))
        if (course.freeCourse) {
          StatusPill(
            text = "Free Open Access • ${course.lectureCount} Lectures",
            containerColor = MauryaTheme.colors.softGreenTint,
            contentColor = SuccessGreen,
          )
        } else {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "₹${course.price}",
              style = MaterialTheme.typography.headlineMedium,
              color = MauryaTheme.colors.textPrimary,
              fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(10.dp))
            Text(
              text = "₹${course.mrp}",
              style = MaterialTheme.typography.titleMedium.copy(textDecoration = TextDecoration.LineThrough),
              color = MauryaTheme.colors.textSecondary,
            )
            Spacer(Modifier.width(10.dp))
            StatusPill(
              text = "${course.discountPercent}% OFF",
              containerColor = MauryaTheme.colors.softGreenTint,
              contentColor = SuccessGreen,
            )
          }
        }

        Spacer(Modifier.height(14.dp))
        TabRow(selectedTabIndex = selectedTab) {
          tabs.forEachIndexed { idx, label ->
            Tab(
              selected = selectedTab == idx,
              onClick = { selectedTab = idx },
              text = { Text(label, maxLines = 1) },
            )
          }
        }

        Spacer(Modifier.height(14.dp))
        when (selectedTab) {
          0 -> {
            Text(
              text = course.description,
              style = MaterialTheme.typography.bodyLarge,
              color = MauryaTheme.colors.textPrimary,
            )
            Spacer(Modifier.height(14.dp))
            MauryaCard(modifier = Modifier.fillMaxWidth()) {
              Text("This course includes", style = MaterialTheme.typography.titleSmall)
              Spacer(Modifier.height(8.dp))
              val includes = listOf(
                "${course.lectureCount} Live & Recorded Chemistry Lectures",
                "Downloadable Formula Sheets & PDF Notes",
                "Weekly JEE/NEET Pattern Mock Tests & Analytics",
                "24x7 Chemistry Doubt Forum with Mentors",
              )
              includes.forEach { line ->
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.padding(vertical = 4.dp),
                ) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(8.dp))
                  Text(line, style = MaterialTheme.typography.bodyMedium)
                }
              }
            }
          }
          1 -> {
            ChemistryContentCatalog.lectures.forEach { lec ->
              MauryaCard(
                onClick = { if (!lec.locked || isEnrolled) onPreviewLecture(lec.id) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = if (lec.locked && !isEnrolled) Icons.Rounded.Lock else Icons.Rounded.PlayCircle,
                    contentDescription = null,
                    tint = if (lec.locked && !isEnrolled) MauryaTheme.colors.textSecondary else RoyalBlue,
                  )
                  Spacer(Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("${lec.numberLabel}: ${lec.title}", style = MaterialTheme.typography.titleSmall)
                    Text("${lec.subject} • ${lec.duration}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  }
                  if (!lec.locked) {
                    StatusPill("Free Preview", MauryaTheme.colors.softGreenTint, SuccessGreen)
                  }
                }
              }
            }
          }
          2 -> {
            MauryaCard(onClick = { onOpenMentor(mentor) }, modifier = Modifier.fillMaxWidth()) {
              Text(mentor.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text("${mentor.qualification} • ${mentor.experience}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
              Spacer(Modifier.height(8.dp))
              Text(mentor.bio, style = MaterialTheme.typography.bodyMedium)
            }
          }
          else -> {
            listOf(
              "Aarav Sharma" to "Best explanation of Hybridisation and VSEPR diagrams I have ever watched!",
              "Priya Verma" to "The DPPs and mock test analytics improved my Chemistry score from 95 to 156.",
            ).forEach { (student, review) ->
              MauryaCard(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Text(student, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(review, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
              }
            }
          }
        }
      }
    }

    Surface(
      color = MauryaTheme.colors.cardBackground,
      shadowElevation = 8.dp,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = { if (isEnrolled) onOpenEnrolledBatch() else onBuyOrEnroll() },
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = if (isEnrolled) SuccessGreen else RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(54.dp).testTag("course_primary_cta"),
        ) {
          Icon(
            imageVector = if (isEnrolled || course.freeCourse) Icons.Rounded.LockOpen else Icons.Rounded.AutoStories,
            contentDescription = null,
            tint = Color.White,
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = when {
              isEnrolled -> "Continue Learning"
              course.freeCourse -> "Enroll Free"
              else -> "Buy Course Now • ₹${course.price}"
            },
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
          )
        }
      }
    }
  }
}

@Composable
fun MentorProfileScreen(
  mentor: MentorProfile,
  courses: List<Course>,
  onBack: () -> Unit,
  onSelectCourse: (Course) -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Teacher Profile", onBack = onBack)
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_mentor_avatar),
        contentDescription = mentor.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(96.dp).clip(CircleShape),
      )
      Spacer(Modifier.height(12.dp))
      Text(mentor.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
      Text(mentor.qualification, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
      Spacer(Modifier.height(8.dp))
      StatusPill("${mentor.experience} experience", MauryaTheme.colors.softBlue, RoyalBlue)
      Spacer(Modifier.height(16.dp))

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(mentor.lecturesCount, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Lectures", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(mentor.studentsCount, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Students", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("★ ${mentor.rating}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Rating", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      }

      Spacer(Modifier.height(14.dp))
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("About Mentor", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        Text(mentor.bio, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
      }

      Spacer(Modifier.height(16.dp))
      SectionHeader(title = "Courses by ${mentor.name}")
      Spacer(Modifier.height(8.dp))
      courses.filter { it.mentorName == mentor.name }.forEach { course ->
        CourseListCard(course = course, onClick = { onSelectCourse(course) })
        Spacer(Modifier.height(10.dp))
      }
    }
  }
}

@Composable
fun NotificationsScreen(
  notifications: List<NotificationItem>,
  onMarkAllRead: () -> Unit,
  onBack: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "Notifications",
      onBack = onBack,
      actions = {
        TextButton(onClick = onMarkAllRead) {
          Text("Mark all read", color = Color.White)
        }
      },
    )
    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(notifications, key = { it.id }) { item ->
        val bg = if (item.unread) MauryaTheme.colors.softBlue else MauryaTheme.colors.cardBackground
        val iconColor = when (item.kind) {
          "class" -> RoyalBlue
          "test" -> SuccessGreen
          else -> WarningAmber
        }
        MauryaCard(containerColor = bg, modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = iconColor.copy(alpha = 0.15f), modifier = Modifier.size(42.dp)) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = when (item.kind) {
                    "class" -> Icons.Rounded.PlayCircle
                    "test" -> Icons.Rounded.Timer
                    else -> Icons.Rounded.Notifications
                  },
                  contentDescription = null,
                  tint = iconColor,
                )
              }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(item.title, style = MaterialTheme.typography.titleSmall)
              Text(item.body, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
              Text(item.timeLabel, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
            }
            if (item.unread) {
              Box(Modifier.size(8.dp).clip(CircleShape).background(RoyalBlue))
            }
          }
        }
      }
    }
  }
}

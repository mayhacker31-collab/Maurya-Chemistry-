package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.ConfirmationNumber
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminAuditLog
import com.example.data.model.AppSettings
import com.example.data.model.Coupon
import com.example.data.model.PaymentRecord
import com.example.data.model.PromoBanner
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.GoldMedal
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminPortalScreen(
  userEmail: String,
  isAuthorizedAdmin: Boolean,
  payments: List<PaymentRecord>,
  banners: List<PromoBanner>,
  coupons: List<Coupon>,
  appSettings: AppSettings,
  adminLogs: List<AdminAuditLog>,
  onBack: () -> Unit,
  onCreateBanner: (title: String, subtitle: String, ctaText: String) -> Unit,
  onCreateCoupon: (code: String, type: String, value: Long, maxUsage: Long) -> Unit,
  onSendBroadcast: (title: String, targetBatch: String) -> Unit,
  onProcessRefund: (studentUid: String, paymentId: String, approve: Boolean) -> Unit,
  onUpdateAppSettings: (AppSettings, String) -> Unit,
) {
  var selectedModule by remember { mutableIntStateOf(0) }
  val modules = listOf(
    "Analytics",
    "Payments",
    "Banners",
    "Coupons",
    "Push Alerts",
    "Refunds",
    "Settings",
    "Roles",
    "Audit Logs",
    "Backup",
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "Admin Management Panel",
      subtitle = if (isAuthorizedAdmin) "Super Admin • $userEmail" else "Read-only Preview • $userEmail",
      onBack = onBack,
    )

    if (!isAuthorizedAdmin) {
      Surface(color = SoftOrangeTint, modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Note: Write actions require Super Admin credentials (configured in Firestore Rules).",
          style = MaterialTheme.typography.labelSmall,
          color = Color(0xFF7A4B00),
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
      }
    }

    ScrollableTabRow(
      selectedTabIndex = selectedModule,
      edgePadding = 12.dp,
    ) {
      modules.forEachIndexed { idx, label ->
        Tab(
          selected = selectedModule == idx,
          onClick = { selectedModule = idx },
          text = { Text(label, maxLines = 1) },
        )
      }
    }

    when (selectedModule) {
      0 -> AdminAnalyticsModule(payments = payments)
      1 -> AdminPaymentsModule(payments = payments)
      2 -> AdminBannersModule(banners = banners, onCreateBanner = onCreateBanner)
      3 -> AdminCouponsModule(coupons = coupons, onCreateCoupon = onCreateCoupon)
      4 -> AdminNotificationsModule(onSendBroadcast = onSendBroadcast)
      5 -> AdminRefundsModule(payments = payments, onProcessRefund = onProcessRefund)
      6 -> AdminSettingsModule(appSettings = appSettings, onSaveSettings = onUpdateAppSettings)
      7 -> AdminRolesModule()
      8 -> AdminAuditLogsModule(logs = adminLogs)
      else -> AdminBackupModule(appSettings = appSettings, onBackupNow = {
        onUpdateAppSettings(
          appSettings.copy(lastBackupAt = "Synced just now (Firebase Cloud Storage)"),
          "Cloud Database Backup completed",
        )
      })
    }
  }
}

@Composable
private fun AdminAnalyticsModule(payments: List<PaymentRecord>) {
  val liveRevenue = payments.filter { it.status == "successful" }.sumOf { it.amount }
  val displayRevenue = 1845200L + liveRevenue

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(22.dp))
          .background(Brush.linearGradient(listOf(PrimaryNavy, RoyalBlue)))
          .padding(18.dp),
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Dashboard, contentDescription = null, tint = GoldMedal)
            Spacer(Modifier.width(8.dp))
            Text("Platform Overview", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
          }
          Spacer(Modifier.height(12.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AdminHeroMetric("Total Revenue", "₹${displayRevenue / 1000}K", "+18% MoM")
            AdminHeroMetric("Active Students", "1,420", "+124 this wk")
            AdminHeroMetric("Live Traffic", "2,480", "2 streams live")
          }
        }
      }
    }

    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Monthly Revenue Growth (₹ Lakhs)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val monthly = listOf("Jun" to 11.2f, "Jul" to 13.5f, "Aug" to 14.8f, "Sep" to 16.4f, "Oct" to 17.9f, "Nov" to 18.5f)
        Canvas(
          modifier = Modifier.fillMaxWidth().height(150.dp).padding(vertical = 4.dp),
        ) {
          val maxVal = 20f
          val barWidth = (size.width / monthly.size) * 0.52f
          val spacing = size.width / monthly.size
          monthly.forEachIndexed { idx, (_, value) ->
            val barH = (value / maxVal) * size.height
            val left = idx * spacing + (spacing - barWidth) / 2f
            drawRoundRect(
              color = if (idx == monthly.lastIndex) RoyalBlue else AccentBlue.copy(alpha = 0.72f),
              topLeft = Offset(left, size.height - barH),
              size = Size(barWidth, barH),
              cornerRadius = CornerRadius(14f, 14f),
            )
          }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
          monthly.forEach { (m, v) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("${v}L", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = RoyalBlue)
              Text(m, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
            }
          }
        }
      }
    }

    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Course Popularity Breakdown", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        listOf(
          Triple("Batch 2027 — JEE Chemistry", 0.78f, "78% • 640 seats"),
          Triple("Organic Chemistry Mastery (NEET)", 0.64f, "64% • 410 seats"),
          Triple("Foundation Class 11 Chemistry", 0.52f, "52% • 370 seats"),
        ).forEach { (name, pct, lbl) ->
          Text(name, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
          Spacer(Modifier.height(4.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
              progress = { pct },
              color = RoyalBlue,
              trackColor = MauryaTheme.colors.softBlue,
              modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape),
            )
            Spacer(Modifier.width(10.dp))
            Text(lbl, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
          Spacer(Modifier.height(10.dp))
        }
      }
    }
  }
}

@Composable
private fun AdminHeroMetric(label: String, value: String, delta: String) {
  Column {
    Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
    Text(value, style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
    Text(delta, style = MaterialTheme.typography.labelSmall, color = Color(0xFF7CF2B9))
  }
}

@Composable
private fun AdminPaymentsModule(payments: List<PaymentRecord>) {
  var orderQuery by remember { mutableStateOf("") }
  var statusFilter by remember { mutableStateOf("All") }

  val combined = remember(payments) {
    val sampleRows = listOf(
      PaymentRecord(id = "adm_1", orderId = "TXN20261123MH7821", courseTitle = "Batch 2027 — JEE Chemistry", amount = 2999L, paymentMethod = "UPI • PhonePe", status = "successful"),
      PaymentRecord(id = "adm_2", orderId = "TXN20261122NE9012", courseTitle = "Organic Chemistry Mastery", amount = 2499L, paymentMethod = "Razorpay • Card", status = "successful"),
      PaymentRecord(id = "adm_3", orderId = "TXN20261121FD3341", courseTitle = "Foundation Class 11", amount = 2500L, paymentMethod = "UPI • GPay", status = "failed"),
      PaymentRecord(id = "adm_4", orderId = "TXN20261120RF5510", courseTitle = "Batch 2027 — JEE Chemistry", amount = 2999L, paymentMethod = "Net Banking", status = "refunded"),
    )
    (payments + sampleRows).distinctBy { it.orderId }
  }

  val filtered = combined.filter { p ->
    val qMatch = orderQuery.isBlank() || p.orderId.contains(orderQuery, ignoreCase = true) || p.courseTitle.contains(orderQuery, ignoreCase = true)
    val sMatch = when (statusFilter) {
      "Success" -> p.status == "successful"
      "Failed" -> p.status == "failed"
      "Refunded" -> p.status == "refunded" || p.status == "refund_in_progress"
      else -> true
    }
    qMatch && sMatch
  }

  Column(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      OutlinedTextField(
        value = orderQuery,
        onValueChange = { orderQuery = it },
        label = { Text("Search by Order ID or Course") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("admin_payment_search"),
      )
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("All", "Success", "Failed", "Refunded").forEach { f ->
          FilterChip(
            selected = statusFilter == f,
            onClick = { statusFilter = f },
            label = { Text(f) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }
    }
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      items(filtered, key = { it.orderId }) { p ->
        val (bg, fg) = when (p.status) {
          "successful" -> SoftGreenTint to SuccessGreen
          "failed" -> ErrorRedTint to ErrorRed
          else -> SoftOrangeTint to WarningAmber
        }
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Payments, contentDescription = null, tint = fg)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(p.orderId, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text("${p.courseTitle} • ${p.paymentMethod}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("₹${p.amount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              StatusPill(p.status.uppercase(), bg, fg)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AdminBannersModule(
  banners: List<PromoBanner>,
  onCreateBanner: (String, String, String) -> Unit,
) {
  var title by remember { mutableStateOf("") }
  var subtitle by remember { mutableStateOf("") }
  var cta by remember { mutableStateOf("Explore Batch") }

  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Publish Home Carousel Banner", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Banner Headline") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Subtitle") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = cta, onValueChange = { cta = it }, label = { Text("CTA Label") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(
          onClick = {
            if (title.isNotBlank()) {
              onCreateBanner(title, subtitle.ifBlank { "Special Chemistry Batch Offer" }, cta.ifBlank { "Enroll Now" })
              title = ""
              subtitle = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White)
          Spacer(Modifier.width(6.dp))
          Text("Publish Banner", color = Color.White)
        }
      }
    }

    item { SectionHeader("Active Home Banners (${banners.size})") }
    items(banners, key = { it.id }) { b ->
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(modifier = Modifier.weight(1f)) {
            Text(b.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(b.subtitle, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          StatusPill(b.ctaText, SoftBlue, RoyalBlue)
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdminCouponsModule(
  coupons: List<Coupon>,
  onCreateCoupon: (String, String, Long, Long) -> Unit,
) {
  var code by remember { mutableStateOf("") }
  var type by remember { mutableStateOf("flat") }
  var value by remember { mutableStateOf("500") }
  var maxUsage by remember { mutableStateOf("200") }

  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Create Discount Coupon", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
          value = code,
          onValueChange = { code = it.uppercase() },
          label = { Text("Coupon Code (e.g. JEE2027)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("flat" to "Flat ₹", "percentage" to "Percentage %").forEach { (k, lbl) ->
            FilterChip(
              selected = type == k,
              onClick = { type = k },
              label = { Text(lbl) },
              colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
            )
          }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = value, onValueChange = { value = it.filter(Char::isDigit) }, label = { Text("Discount") }, modifier = Modifier.weight(1f))
          OutlinedTextField(value = maxUsage, onValueChange = { maxUsage = it.filter(Char::isDigit) }, label = { Text("Max Usage") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Button(
          onClick = {
            if (code.isNotBlank()) {
              onCreateCoupon(code, type, value.toLongOrNull() ?: 500L, maxUsage.toLongOrNull() ?: 100L)
              code = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(Icons.Rounded.ConfirmationNumber, contentDescription = null, tint = Color.White)
          Spacer(Modifier.width(6.dp))
          Text("Save Coupon", color = Color.White)
        }
      }
    }

    item { SectionHeader("Active Coupons (${coupons.size})") }
    items(coupons, key = { it.id }) { c ->
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(modifier = Modifier.weight(1f)) {
            Text(c.code, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = RoyalBlue)
            Text("Limit: ${c.usedCount}/${c.maxUsage} • Expires ${c.expiryText}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          StatusPill(
            text = if (c.discountType == "percentage") "${c.discountValue}% OFF" else "₹${c.discountValue} OFF",
            containerColor = SoftGreenTint,
            contentColor = SuccessGreen,
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdminNotificationsModule(onSendBroadcast: (String, String) -> Unit) {
  var title by remember { mutableStateOf("") }
  var targetBatch by remember { mutableStateOf("All Students") }

  Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    MauryaCard(modifier = Modifier.fillMaxWidth()) {
      Text("Send Push Notification Broadcast", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(8.dp))
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text("Notification Headline (e.g. Live Class starting in 10 mins)") },
        modifier = Modifier.fillMaxWidth(),
      )
      Spacer(Modifier.height(10.dp))
      Text("Target Audience", style = MaterialTheme.typography.labelLarge)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("All Students", "Batch 2027 — JEE", "NEET 2026", "Foundation 11").forEach { t ->
          FilterChip(
            selected = targetBatch == t,
            onClick = { targetBatch = t },
            label = { Text(t) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }
      Spacer(Modifier.height(12.dp))
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onSendBroadcast(title, targetBatch)
            title = ""
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Icon(Icons.Rounded.Campaign, contentDescription = null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text("Send Notification Now", color = Color.White)
      }
    }
  }
}

@Composable
private fun AdminRefundsModule(
  payments: List<PaymentRecord>,
  onProcessRefund: (String, String, Boolean) -> Unit,
) {
  val pendingRefunds = payments.filter { it.status == "refund_in_progress" }

  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { SectionHeader("Pending Refund Queue (${pendingRefunds.size})") }
    if (pendingRefunds.isEmpty()) {
      item {
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            "No pending refund requests right now. Students can submit a refund request from Order & Refund Status.",
            style = MaterialTheme.typography.bodyMedium,
            color = MauryaTheme.colors.textSecondary,
          )
        }
      }
    } else {
      items(pendingRefunds, key = { it.id }) { p ->
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Text(p.orderId, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Text("${p.courseTitle} • ₹${p.amount}", style = MaterialTheme.typography.bodySmall)
          Text("Reason: ${p.refundReason.ifBlank { "Student requested batch switch" }}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          Spacer(Modifier.height(10.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = { onProcessRefund(p.userId, p.id, false) },
              border = BorderStroke(1.dp, ErrorRed),
              modifier = Modifier.weight(1f),
            ) {
              Icon(Icons.Rounded.Close, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Reject", color = ErrorRed)
            }
            Button(
              onClick = { onProcessRefund(p.userId, p.id, true) },
              colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
              modifier = Modifier.weight(1f),
            ) {
              Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Approve", color = Color.White)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AdminSettingsModule(
  appSettings: AppSettings,
  onSaveSettings: (AppSettings, String) -> Unit,
) {
  var maintenance by remember(appSettings) { mutableStateOf(appSettings.maintenanceMode) }
  var eta by remember(appSettings) { mutableStateOf(appSettings.maintenanceEta) }
  var latestVer by remember(appSettings) { mutableStateOf(appSettings.latestVersion) }
  var minVer by remember(appSettings) { mutableStateOf(appSettings.minSupportedVersion) }
  var terms by remember(appSettings) { mutableStateOf(appSettings.termsText) }

  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Settings, contentDescription = null, tint = RoyalBlue)
          Spacer(Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("Maintenance Mode", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("Blocks non-admin users during upgrades", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          Switch(checked = maintenance, onCheckedChange = { maintenance = it })
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = eta, onValueChange = { eta = it }, label = { Text("Maintenance ETA") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = latestVer, onValueChange = { latestVer = it }, label = { Text("Latest Version") }, modifier = Modifier.weight(1f))
          OutlinedTextField(value = minVer, onValueChange = { minVer = it }, label = { Text("Min Supported") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = terms, onValueChange = { terms = it }, label = { Text("Terms & Privacy Policy Text") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(
          onClick = {
            onSaveSettings(
              appSettings.copy(
                maintenanceMode = maintenance,
                maintenanceEta = eta,
                latestVersion = latestVer,
                minSupportedVersion = minVer,
                termsText = terms,
              ),
              "Global app settings updated",
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text("Save App Settings", color = Color.White)
        }
      }
    }
  }
}

@Composable
private fun AdminRolesModule() {
  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { SectionHeader("Admin Roles & Permissions Matrix") }
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Security, contentDescription = null, tint = RoyalBlue)
          Spacer(Modifier.width(8.dp))
          Text("Super Admin", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Spacer(Modifier.weight(1f))
          StatusPill("Full Access", SoftGreenTint, SuccessGreen)
        }
        Spacer(Modifier.height(6.dp))
        Text("Can view Revenue Analytics, approve Refunds, edit Banners/Coupons, toggle Maintenance Mode, trigger Cloud Backups, and manage Manager permissions.", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
      }
    }
    item {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.People, contentDescription = null, tint = WarningAmber)
          Spacer(Modifier.width(8.dp))
          Text("Content Manager", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Spacer(Modifier.weight(1f))
          StatusPill("Scoped Access", SoftOrangeTint, WarningAmber)
        }
        Spacer(Modifier.height(6.dp))
        Text("Can upload Chemistry video lectures, PDFs, mock tests, and publish Banners. Cannot view Revenue totals or process Refunds.", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
      }
    }
  }
}

@Composable
private fun AdminAuditLogsModule(logs: List<AdminAuditLog>) {
  val source = if (logs.isNotEmpty()) logs else listOf(
    AdminAuditLog(id = "l1", adminEmail = "gentoincfacts@gmail.com", action = "INITIALIZE_PORTAL", targetEntity = "appSettings/global", details = "Maurya Chemistry 2.0 Admin Portal active"),
  )
  LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    item { SectionHeader("Admin Audit Trail (${source.size})") }
    items(source, key = { it.id }) { log ->
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.History, contentDescription = null, tint = RoyalBlue)
          Spacer(Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(log.action, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("${log.adminEmail} • ${log.targetEntity}", style = MaterialTheme.typography.labelSmall, color = RoyalBlue)
            Text(log.details, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      }
    }
  }
}

@Composable
private fun AdminBackupModule(
  appSettings: AppSettings,
  onBackupNow: () -> Unit,
) {
  var autoBackup by remember { mutableStateOf(true) }
  Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    MauryaCard(modifier = Modifier.fillMaxWidth()) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = CircleShape, color = SoftGreenTint, modifier = Modifier.size(48.dp)) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = SuccessGreen)
          }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text("Firestore Cloud Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text("Last backup: ${appSettings.lastBackupAt}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
        }
      }
      Spacer(Modifier.height(12.dp))
      HorizontalDivider()
      Spacer(Modifier.height(12.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Auto-Backup Daily (04:00 AM IST)", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = autoBackup, onCheckedChange = { autoBackup = it })
      }
      Spacer(Modifier.height(14.dp))
      Button(
        onClick = onBackupNow,
        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("backup_now_button"),
      ) {
        Icon(Icons.Rounded.Backup, contentDescription = null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text("Backup Now", color = Color.White, style = MaterialTheme.typography.titleMedium)
      }
    }
  }
}

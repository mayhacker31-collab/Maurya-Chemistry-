package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.QuestionAnswer
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Enrollment
import com.example.data.model.LectureItem
import com.example.data.model.LiveChatMessage
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.PrimaryNavyDeep
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SoftYellowTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.PlayerUiState

@Composable
fun MyBatchesScreen(
  enrollments: List<Enrollment>,
  onOpenBatch: (Enrollment) -> Unit,
  onOpenLiveClasses: () -> Unit,
  onExploreCourses: () -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val displayBatches = remember(enrollments, selectedTab) {
    val source = if (enrollments.isNotEmpty()) enrollments else listOf(
      Enrollment(
        id = "batch_2027_jee",
        courseId = "batch_2027_jee",
        courseTitle = "Batch 2027 — JEE Chemistry",
        mentorName = "Dr. R. Verma",
        progressPercent = 68L,
        completedLectures = 82L,
        totalLectures = 120L,
        status = "active",
      ),
      Enrollment(
        id = "foundation_class_11",
        courseId = "foundation_class_11",
        courseTitle = "Foundation Class 11 Chemistry",
        mentorName = "Prof. S. Mehta",
        progressPercent = 34L,
        completedLectures = 27L,
        totalLectures = 80L,
        status = "active",
      ),
    )
    if (selectedTab == 0) source.filter { it.status == "active" } else source.filter { it.status == "completed" }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "My Batches",
      actions = {
        TextButton(onClick = onOpenLiveClasses) {
          Text("Live 🔴", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
    )

    TabRow(selectedTabIndex = selectedTab) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Active") })
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Completed") })
    }

    if (displayBatches.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Rounded.Science, contentDescription = null, tint = MauryaTheme.colors.textSecondary, modifier = Modifier.size(56.dp))
          Spacer(Modifier.height(10.dp))
          Text(
            text = if (selectedTab == 1) "No completed batches yet" else "No active batches",
            style = MaterialTheme.typography.titleMedium,
          )
          Spacer(Modifier.height(8.dp))
          Button(
            onClick = onExploreCourses,
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          ) {
            Text("Explore Courses", color = Color.White)
          }
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        items(displayBatches, key = { it.id }) { batch ->
          MauryaCard(onClick = { onOpenBatch(batch) }, modifier = Modifier.fillMaxWidth()) {
            Image(
              painter = painterResource(id = R.drawable.img_course_banner),
              contentDescription = batch.courseTitle,
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(14.dp)),
            )
            Spacer(Modifier.height(12.dp))
            Text(
              text = batch.courseTitle,
              style = MaterialTheme.typography.titleMedium,
              color = MauryaTheme.colors.textPrimary,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "${batch.mentorName} • ${batch.completedLectures}/${batch.totalLectures} Lectures",
              style = MaterialTheme.typography.bodySmall,
              color = MauryaTheme.colors.textSecondary,
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              LinearProgressIndicator(
                progress = { (batch.progressPercent / 100f).coerceIn(0f, 1f) },
                color = RoyalBlue,
                trackColor = MauryaTheme.colors.softBlue,
                modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape),
              )
              Spacer(Modifier.width(12.dp))
              Text(
                text = "${batch.progressPercent}%",
                style = MaterialTheme.typography.labelMedium,
                color = RoyalBlue,
                fontWeight = FontWeight.Bold,
              )
            }
            Spacer(Modifier.height(12.dp))
            Button(
              onClick = { onOpenBatch(batch) },
              shape = RoundedCornerShape(50),
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text("Continue Learning", color = Color.White)
            }
          }
        }
        item {
          Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            TextButton(onClick = onExploreCourses) {
              Text("Explore more courses →", color = RoyalBlue)
            }
          }
        }
      }
    }
  }
}

@Composable
fun BatchDetailScreen(
  enrollment: Enrollment,
  onBack: () -> Unit,
  onOpenLecture: (String) -> Unit,
  onOpenLiveClasses: () -> Unit,
  onAdvanceProgress: () -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("Overview", "Lectures", "Schedule", "Announcements")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Batch Details", onBack = onBack)

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState()),
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_course_banner),
        contentDescription = enrollment.courseTitle,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxWidth().height(160.dp),
      )
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = enrollment.courseTitle,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = "Mentor: ${enrollment.mentorName} • Hindi + English",
          style = MaterialTheme.typography.bodyMedium,
          color = MauryaTheme.colors.textSecondary,
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          StatusPill("${enrollment.totalLectures} Lectures", MauryaTheme.colors.softBlue, RoyalBlue)
          StatusPill("${enrollment.progressPercent}% Done", MauryaTheme.colors.softGreenTint, SuccessGreen)
        }

        Spacer(Modifier.height(14.dp))
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MauryaTheme.colors.softYellowTint,
          border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PushPin, contentDescription = null, tint = WarningAmber)
            Spacer(Modifier.width(10.dp))
            Text(
              text = "Pinned: Mock Test 12 on Sunday 6:00 PM — Chemical Bonding & Thermodynamics!",
              style = MaterialTheme.typography.bodySmall,
              color = MauryaTheme.colors.textPrimary,
            )
          }
        }

        Spacer(Modifier.height(12.dp))
        TabRow(selectedTabIndex = selectedTab) {
          tabs.forEachIndexed { idx, label ->
            Tab(selected = selectedTab == idx, onClick = { selectedTab = idx }, text = { Text(label, maxLines = 1) })
          }
        }
        Spacer(Modifier.height(14.dp))

        when (selectedTab) {
          0 -> {
            Text("Subjects", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              listOf(
                Triple("Physical", "8 Ch", SoftBlue),
                Triple("Organic", "9 Ch", SoftGreenTint),
                Triple("Inorganic", "6 Ch", SoftPurpleTint),
              ).forEach { (subj, cnt, bg) ->
                Surface(
                  shape = RoundedCornerShape(16.dp),
                  color = if (MauryaTheme.colors.isDark) MauryaTheme.colors.cardBackground else bg,
                  modifier = Modifier.weight(1f),
                ) {
                  Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(subj, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(cnt, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
                  }
                }
              }
            }
          }
          1 -> {
            ChemistryContentCatalog.lectures.forEach { lec ->
              MauryaCard(
                onClick = { if (!lec.locked) onOpenLecture(lec.id) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = when {
                      lec.completed -> Icons.Rounded.CheckCircle
                      lec.locked -> Icons.Rounded.Lock
                      else -> Icons.Rounded.PlayCircle
                    },
                    contentDescription = null,
                    tint = when {
                      lec.completed -> SuccessGreen
                      lec.locked -> MauryaTheme.colors.textSecondary
                      else -> RoyalBlue
                    },
                  )
                  Spacer(Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("${lec.numberLabel}: ${lec.title}", style = MaterialTheme.typography.titleSmall)
                    Text("${lec.chapterTitle} • ${lec.duration}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  }
                }
              }
            }
          }
          2 -> {
            Button(
              onClick = onOpenLiveClasses,
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text("Open Live Class Schedule", color = Color.White)
            }
          }
          else -> {
            MauryaCard(modifier = Modifier.fillMaxWidth()) {
              Text("Sunday Full Syllabus Chemistry Test", style = MaterialTheme.typography.titleSmall)
              Text("Syllabus: Atomic Structure, Chemical Bonding, GOC. Duration: 60 mins.", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
            }
          }
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = onAdvanceProgress, modifier = Modifier.weight(1f)) {
          Text("Log Progress")
        }
        Button(
          onClick = { onOpenLecture("lec_4") },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.weight(1.4f),
        ) {
          Text("Watch L4 Now", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun VideoLecturePlayerScreen(
  playerState: PlayerUiState,
  onBack: () -> Unit,
  onSelectLecture: (String) -> Unit,
  onTogglePlayPause: () -> Unit,
  onCycleSpeed: () -> Unit,
  onCycleQuality: () -> Unit,
  onToggleFullscreen: () -> Unit,
  onToggleBookmark: (String) -> Unit,
  onMarkComplete: (String) -> Unit,
  onDownloadNotes: (String) -> Unit,
  onAskDoubt: () -> Unit,
) {
  val lecture = ChemistryContentCatalog.lectures.firstOrNull { it.id == playerState.lectureId }
    ?: ChemistryContentCatalog.lectures.first()
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("Overview", "Lectures", "Notes & DPP")
  val isBookmarked = lecture.id in playerState.bookmarkedIds
  val isCompleted = lecture.id in playerState.completedIds

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(if (playerState.fullscreen) Color.Black else MaterialTheme.colorScheme.background),
  ) {
    // Video Player Viewport
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .then(if (playerState.fullscreen) Modifier.weight(1f) else Modifier.height(250.dp))
        .background(Color(0xFF0A1424))
        .windowInsetsPadding(WindowInsets.statusBars),
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_course_banner),
        contentDescription = "Chemistry Lecture Video",
        contentScale = ContentScale.Crop,
        alpha = 0.42f,
        modifier = Modifier.fillMaxSize(),
      )

      // Top overlay
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = { if (playerState.fullscreen) onToggleFullscreen() else onBack() }) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(
          text = "${lecture.numberLabel} • ${lecture.title}",
          style = MaterialTheme.typography.titleSmall,
          color = Color.White,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        IconButton(onClick = { onToggleBookmark(lecture.id) }) {
          Icon(
            imageVector = if (isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
            contentDescription = "Bookmark",
            tint = if (isBookmarked) AccentBlue else Color.White,
          )
        }
      }

      // Center play/pause
      Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.55f),
        modifier = Modifier
          .align(Alignment.Center)
          .size(64.dp)
          .clickable(onClick = onTogglePlayPause)
          .testTag("video_play_pause_button"),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = if (playerState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            contentDescription = "Play or Pause",
            tint = Color.White,
            modifier = Modifier.size(36.dp),
          )
        }
      }

      // Bottom seek & controls
      Column(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .background(Color.Black.copy(alpha = 0.55f))
          .padding(horizontal = 12.dp, vertical = 8.dp),
      ) {
        LinearProgressIndicator(
          progress = { playerState.progressFraction },
          color = RoyalBlue,
          trackColor = Color.White.copy(alpha = 0.3f),
          modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
        )
        Spacer(Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "12:34 / ${lecture.duration}",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
          )
          Spacer(Modifier.weight(1f))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.16f),
            modifier = Modifier.clickable(onClick = onCycleSpeed),
          ) {
            Text(playerState.speed, color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
          }
          Spacer(Modifier.width(6.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.16f),
            modifier = Modifier.clickable(onClick = onCycleQuality),
          ) {
            Text(playerState.quality, color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
          }
          IconButton(onClick = onToggleFullscreen, modifier = Modifier.size(32.dp)) {
            Icon(
              imageVector = if (playerState.fullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
              contentDescription = "Fullscreen",
              tint = Color.White,
            )
          }
        }
      }
    }

    if (!playerState.fullscreen) {
      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
      ) {
        Text(
          text = lecture.title,
          style = MaterialTheme.typography.titleLarge,
          color = MauryaTheme.colors.textPrimary,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = "${lecture.mentorName} • ${lecture.chapterTitle}",
          style = MaterialTheme.typography.bodySmall,
          color = MauryaTheme.colors.textSecondary,
        )
        Spacer(Modifier.height(12.dp))
        TabRow(selectedTabIndex = selectedTab) {
          tabs.forEachIndexed { idx, label ->
            Tab(selected = selectedTab == idx, onClick = { selectedTab = idx }, text = { Text(label) })
          }
        }
        Spacer(Modifier.height(12.dp))

        when (selectedTab) {
          0 -> {
            MauryaCard(modifier = Modifier.fillMaxWidth()) {
              Text("About this Lecture", style = MaterialTheme.typography.titleSmall)
              Spacer(Modifier.height(6.dp))
              Text(lecture.summary, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
              Spacer(Modifier.height(10.dp))
              Text("What you'll learn", style = MaterialTheme.typography.titleSmall)
              lecture.takeaways.forEach { t ->
                Row(modifier = Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                  Spacer(Modifier.width(8.dp))
                  Text(t, style = MaterialTheme.typography.bodySmall)
                }
              }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
              onClick = { onMarkComplete(lecture.id) },
              enabled = !isCompleted,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(if (isCompleted) "Completed ✓" else "Mark as Complete")
            }
          }
          1 -> {
            ChemistryContentCatalog.lectures.forEach { item ->
              val active = item.id == lecture.id
              MauryaCard(
                onClick = { if (!item.locked) onSelectLecture(item.id) },
                containerColor = if (active) MauryaTheme.colors.softBlue else MauryaTheme.colors.cardBackground,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = if (item.locked) Icons.Rounded.Lock else Icons.Rounded.PlayCircle,
                    contentDescription = null,
                    tint = if (item.locked) MauryaTheme.colors.textSecondary else RoyalBlue,
                  )
                  Spacer(Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("${item.numberLabel}: ${item.title}", style = MaterialTheme.typography.titleSmall)
                    Text(item.duration, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                  }
                  if (item.id in playerState.completedIds) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = "Completed", tint = SuccessGreen)
                  }
                }
              }
            }
          }
          else -> {
            MauryaCard(modifier = Modifier.fillMaxWidth()) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(lecture.pdfTitle, style = MaterialTheme.typography.titleSmall)
                  Text("18 pages • 1.8 MB", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                }
                Button(
                  onClick = { onDownloadNotes(lecture.pdfTitle) },
                  colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                ) {
                  Text("Save", color = Color.White)
                }
              }
            }
          }
        }
      }

      Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = { onDownloadNotes(lecture.pdfTitle) },
            modifier = Modifier.weight(1f),
          ) {
            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Notes PDF")
          }
          Button(
            onClick = onAskDoubt,
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
            modifier = Modifier.weight(1f),
          ) {
            Icon(Icons.Rounded.QuestionAnswer, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Ask Doubt", color = Color.White)
          }
        }
      }
    }
  }
}

@Composable
fun LiveClassesDashboardScreen(
  onBack: () -> Unit,
  onJoinLiveInteractive: () -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var remindedIds by remember { mutableStateOf(setOf<String>()) }
  val sessions = ChemistryContentCatalog.liveClasses

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Live Classes", onBack = onBack)
    TabRow(selectedTabIndex = selectedTab) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Live & Today") })
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Schedule") })
    }

    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      items(sessions, key = { it.id }) { session ->
        val isLive = session.status == "live"
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            StatusPill(
              text = if (isLive) "● LIVE NOW" else session.timeLabel,
              containerColor = if (isLive) ErrorRedTint else MauryaTheme.colors.softBlue,
              contentColor = if (isLive) ErrorRed else RoyalBlue,
            )
            Spacer(Modifier.width(8.dp))
            Text(session.viewerCount, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
          Spacer(Modifier.height(8.dp))
          Text(session.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text("${session.mentorName} • ${session.batchName}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          Spacer(Modifier.height(6.dp))
          Text(session.description, style = MaterialTheme.typography.bodySmall)
          Spacer(Modifier.height(12.dp))
          if (isLive) {
            Button(
              onClick = onJoinLiveInteractive,
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text("Join Live Class", color = Color.White)
            }
          } else {
            val isReminded = session.id in remindedIds
            OutlinedButton(
              onClick = { remindedIds = if (isReminded) remindedIds - session.id else remindedIds + session.id },
              modifier = Modifier.fillMaxWidth(),
            ) {
              Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(6.dp))
              Text(if (isReminded) "Reminder Set ✓" else "Set Reminder")
            }
          }
        }
      }
    }
  }
}

@Composable
fun LiveInteractiveClassScreen(
  messages: List<LiveChatMessage>,
  onSendMessage: (String) -> Unit,
  onBack: () -> Unit,
) {
  var chatInput by remember { mutableStateOf("") }
  val pinned = messages.firstOrNull { it.pinned }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(
      title = "Live Class",
      subtitle = "Hybridisation Deep Dive • 2.4k watching",
      onBack = onBack,
      actions = {
        TextButton(onClick = onBack) {
          Text("Leave", color = ErrorRed, fontWeight = FontWeight.Bold)
        }
      },
    )

    // Live Stream Preview Box
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(210.dp)
        .padding(12.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(PrimaryNavyDeep),
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_course_banner),
        contentDescription = "Live Chemistry Class",
        contentScale = ContentScale.Crop,
        alpha = 0.55f,
        modifier = Modifier.fillMaxSize(),
      )
      StatusPill(
        text = "● LIVE",
        containerColor = ErrorRed,
        contentColor = Color.White,
        modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
      )
      Surface(
        shape = RoundedCornerShape(50),
        color = Color.Black.copy(alpha = 0.6f),
        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
      ) {
        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Visibility, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
          Spacer(Modifier.width(4.dp))
          Text("2.4k", color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
      }
      Text(
        text = "Dr. R. Verma explaining sp² vs sp³ geometry",
        color = Color.White,
        style = MaterialTheme.typography.labelMedium,
        modifier = Modifier
          .align(Alignment.BottomStart)
          .background(Color.Black.copy(alpha = 0.55f))
          .fillMaxWidth()
          .padding(10.dp),
      )
    }

    if (pinned != null) {
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = MauryaTheme.colors.softYellowTint,
        border = BorderStroke(1.dp, WarningAmber),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
      ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.PushPin, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(8.dp))
          Text(pinned.text, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textPrimary)
        }
      }
    }

    LazyColumn(
      modifier = Modifier.weight(1f),
      contentPadding = PaddingValues(12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      items(messages.filterNot { it.pinned }, key = { it.id }) { msg ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = if (msg.fromMentor) Arrangement.Start else Arrangement.End,
        ) {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (msg.fromMentor) MauryaTheme.colors.cardBackground else MauryaTheme.colors.softBlue,
            border = BorderStroke(1.dp, MauryaTheme.colors.border),
            modifier = Modifier.fillMaxWidth(0.84f),
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "${msg.senderName} • ${msg.timeLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = if (msg.fromMentor) RoyalBlue else MauryaTheme.colors.textSecondary,
                fontWeight = FontWeight.Bold,
              )
              Spacer(Modifier.height(4.dp))
              Text(msg.text, style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedTextField(
          value = chatInput,
          onValueChange = { chatInput = it },
          placeholder = { Text("Ask a doubt...") },
          singleLine = true,
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier.weight(1f).testTag("live_chat_input"),
        )
        Spacer(Modifier.width(8.dp))
        Surface(
          shape = CircleShape,
          color = RoyalBlue,
          modifier = Modifier
            .size(48.dp)
            .clickable {
              onSendMessage(chatInput)
              chatInput = ""
            },
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send", tint = Color.White)
          }
        }
      }
    }
  }
}

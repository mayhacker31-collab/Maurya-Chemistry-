package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Course
import com.example.data.model.Doubt
import com.example.data.model.Enrollment
import com.example.data.model.MentorProfile
import com.example.data.model.NoteDocument
import com.example.data.model.PaymentRecord
import com.example.data.model.TestAttempt
import com.example.data.model.TestDefinition
import com.example.data.repository.MauryaRepository
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.auth.AuthFlowRoot
import com.example.ui.auth.StudentProfileSetupSheet
import com.example.ui.auth.authStateFlow
import com.example.ui.auth.signOutUser
import com.example.ui.components.BottomNavTab
import com.example.ui.components.MauryaBottomNavBar
import com.example.ui.screens.AchievementsScreen
import com.example.ui.screens.AdminPortalScreen
import com.example.ui.screens.AskDoubtScreen
import com.example.ui.screens.BatchDetailScreen
import com.example.ui.screens.CertificatesScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.ContactSupportScreen
import com.example.ui.screens.CourseDetailsScreen
import com.example.ui.screens.CourseExplorerScreen
import com.example.ui.screens.DetailedSolutionsScreen
import com.example.ui.screens.DoubtDashboardScreen
import com.example.ui.screens.DoubtDetailScreen
import com.example.ui.screens.DownloadsDashboardScreen
import com.example.ui.screens.EditProfileScreen
import com.example.ui.screens.HelpAndSupportScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LiveClassesDashboardScreen
import com.example.ui.screens.LiveInteractiveClassScreen
import com.example.ui.screens.LiveTestInterfaceScreen
import com.example.ui.screens.MaintenanceModeScreen
import com.example.ui.screens.MentorProfileScreen
import com.example.ui.screens.MyBatchesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OrderAndRefundDetailScreen
import com.example.ui.screens.PaymentHistoryScreen
import com.example.ui.screens.PaymentMethodAndResultFlow
import com.example.ui.screens.PdfViewerScreen
import com.example.ui.screens.PerformanceAnalyticsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsAndSecurityScreen
import com.example.ui.screens.TestDashboardScreen
import com.example.ui.screens.TestDetailsAndInstructionsScreen
import com.example.ui.screens.TestResultScreen
import com.example.ui.screens.VideoLecturePlayerScreen
import com.example.ui.theme.MauryaChemistryTheme
import com.example.ui.viewmodel.MauryaViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

sealed interface MauryaRoute {
  data class CourseExplorer(val initialCategory: String = "All") : MauryaRoute
  data class CourseDetails(val course: Course) : MauryaRoute
  data class MentorDetail(val mentor: MentorProfile) : MauryaRoute
  data object Notifications : MauryaRoute
  data class BatchDetail(val enrollment: Enrollment) : MauryaRoute
  data object VideoPlayer : MauryaRoute
  data object LiveClasses : MauryaRoute
  data object LiveInteractive : MauryaRoute
  data class PdfViewer(val note: NoteDocument) : MauryaRoute
  data class TestDetails(val test: TestDefinition) : MauryaRoute
  data object LiveTest : MauryaRoute
  data class TestResult(val attempt: TestAttempt) : MauryaRoute
  data object DetailedSolutions : MauryaRoute
  data object Analytics : MauryaRoute
  data object Leaderboard : MauryaRoute
  data object DoubtsDashboard : MauryaRoute
  data object AskDoubt : MauryaRoute
  data class DoubtDetail(val doubt: Doubt) : MauryaRoute
  data class Checkout(val course: Course) : MauryaRoute
  data class PaymentMethod(
    val course: Course,
    val amountPaid: Long,
    val discountAmount: Long,
    val couponCode: String,
  ) : MauryaRoute
  data object PaymentHistory : MauryaRoute
  data class OrderRefundDetail(val payment: PaymentRecord) : MauryaRoute
  data object EditProfile : MauryaRoute
  data object Achievements : MauryaRoute
  data object Certificates : MauryaRoute
  data object Settings : MauryaRoute
  data object HelpSupport : MauryaRoute
  data object ContactSupport : MauryaRoute
  data object AdminPortal : MauryaRoute
  data object MaintenancePreview : MauryaRoute
}

@Composable
fun MauryaAppRoot() {
  val authState by Firebase.auth.authStateFlow()
    .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

  val user = authState
  if (user == null) {
    MauryaChemistryTheme(darkTheme = false) {
      AuthFlowRoot(onAuthSuccess = {})
    }
    return
  }

  val context = LocalContext.current
  val credentialManager = remember(context) { CredentialManager.create(context) }
  val scope = rememberCoroutineScope()

  key(user.uid) {
    val vm: MauryaViewModel = viewModel(
      key = user.uid,
      factory = remember(user.uid) {
        object : ViewModelProvider.Factory {
          @Suppress("UNCHECKED_CAST")
          override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MauryaViewModel(
              repository = MauryaRepository(context),
              currentUserId = user.uid,
              userEmail = user.email ?: "",
              userDisplayName = user.displayName ?: "",
            ) as T
          }
        }
      },
    )

    val profileState by vm.userProfileState.collectAsStateWithLifecycle()
    val profile = (profileState as? UiState.Success)?.data
    val courses by vm.coursesState.collectAsStateWithLifecycle()
    val banners by vm.bannersState.collectAsStateWithLifecycle()
    val coupons by vm.couponsState.collectAsStateWithLifecycle()
    val appSettings by vm.appSettingsState.collectAsStateWithLifecycle()
    val enrollments by vm.enrollmentsState.collectAsStateWithLifecycle()
    val payments by vm.paymentsState.collectAsStateWithLifecycle()
    val attempts by vm.testAttemptsState.collectAsStateWithLifecycle()
    val doubts by vm.doubtsState.collectAsStateWithLifecycle()
    val tickets by vm.ticketsState.collectAsStateWithLifecycle()
    val adminLogs by vm.adminLogsState.collectAsStateWithLifecycle()
    val notifications by vm.notifications.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val liveChat by vm.liveChat.collectAsStateWithLifecycle()
    val playerState by vm.playerState.collectAsStateWithLifecycle()
    val wishlistIds by vm.wishlistCourseIds.collectAsStateWithLifecycle()
    val activeTestSession by vm.activeTestSession.collectAsStateWithLifecycle()
    val bannerMessage by vm.bannerMessage.collectAsStateWithLifecycle()
    val showProfileSetup by vm.showProfileSetup.collectAsStateWithLifecycle()

    val isAdminUser = remember(user.email, profile?.role) {
      user.email.equals("gentoincfacts@gmail.com", ignoreCase = true) ||
        profile?.role == "super_admin" ||
        profile?.role == "manager"
    }

    var activeTab by remember { mutableStateOf(BottomNavTab.HOME) }
    var subStack by remember { mutableStateOf<List<MauryaRoute>>(emptyList()) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(bannerMessage) {
      val msg = bannerMessage
      if (!msg.isNullOrBlank()) {
        snackbarHostState.showSnackbar(msg)
        vm.dismissBannerMessage()
      }
    }

    fun pushRoute(route: MauryaRoute) {
      subStack = subStack + route
    }

    fun popRoute() {
      if (subStack.isNotEmpty()) {
        subStack = subStack.dropLast(1)
      }
    }

    BackHandler(enabled = subStack.isNotEmpty()) {
      popRoute()
    }

    val darkTheme = profile?.darkMode == true
    MauryaChemistryTheme(darkTheme = darkTheme) {
      if (showProfileSetup) {
        StudentProfileSetupSheet(
          initialName = profile?.fullName ?: user.displayName ?: "",
          initialEmail = user.email ?: "",
          onSaveProfile = { name, phone, cls, brd, target, lang ->
            vm.saveStudentProfile(name, phone, cls, brd, target, lang)
          },
        )
        return@MauryaChemistryTheme
      }

      if (appSettings.maintenanceMode && !isAdminUser) {
        MaintenanceModeScreen(
          etaText = appSettings.maintenanceEta,
          isAdminUser = false,
          onRetryOrClose = {},
          onOpenAdminPortal = {},
        )
        return@MauryaChemistryTheme
      }

      val topRoute = subStack.lastOrNull()

      Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
          if (topRoute == null) {
            MauryaBottomNavBar(
              activeTab = activeTab,
              onSelectTab = { activeTab = it },
            )
          }
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        ) {
          when (topRoute) {
            null -> {
              when (activeTab) {
                BottomNavTab.HOME -> HomeDashboardScreen(
                  profile = profile,
                  courses = courses,
                  banners = banners,
                  enrollments = enrollments,
                  recentAttempts = attempts,
                  unreadNotifications = notifications.count { it.unread },
                  onOpenNotifications = { pushRoute(MauryaRoute.Notifications) },
                  onOpenExplorer = { cat -> pushRoute(MauryaRoute.CourseExplorer(cat)) },
                  onOpenCourseDetail = { course -> pushRoute(MauryaRoute.CourseDetails(course)) },
                  onOpenBatchDetail = { enr -> pushRoute(MauryaRoute.BatchDetail(enr)) },
                  onResumeLecture = { pushRoute(MauryaRoute.VideoPlayer) },
                  onJoinLiveClass = { pushRoute(MauryaRoute.LiveInteractive) },
                  onStartDailyQuiz = {
                    pushRoute(MauryaRoute.TestDetails(ChemistryContentCatalog.testDefinitions.first()))
                  },
                  onOpenMentor = { mentor -> pushRoute(MauryaRoute.MentorDetail(mentor)) },
                  onOpenProfile = { activeTab = BottomNavTab.PROFILE },
                )

                BottomNavTab.BATCHES -> MyBatchesScreen(
                  enrollments = enrollments,
                  onOpenBatch = { enr -> pushRoute(MauryaRoute.BatchDetail(enr)) },
                  onOpenLiveClasses = { pushRoute(MauryaRoute.LiveClasses) },
                  onExploreCourses = { pushRoute(MauryaRoute.CourseExplorer("All")) },
                )

                BottomNavTab.TESTS -> TestDashboardScreen(
                  streakDays = profile?.streakDays ?: 7L,
                  attempts = attempts,
                  onSelectTest = { test -> pushRoute(MauryaRoute.TestDetails(test)) },
                  onOpenAnalytics = { pushRoute(MauryaRoute.Analytics) },
                  onOpenLeaderboard = { pushRoute(MauryaRoute.Leaderboard) },
                )

                BottomNavTab.DOWNLOADS -> DownloadsDashboardScreen(
                  downloads = downloads,
                  onTogglePause = vm::toggleDownloadPause,
                  onClearCompleted = vm::clearCompletedDownloads,
                  onOpenNotePdf = { note -> pushRoute(MauryaRoute.PdfViewer(note)) },
                  onDownloadItem = vm::startDownload,
                )

                BottomNavTab.PROFILE -> ProfileScreen(
                  profile = profile,
                  userEmail = user.email ?: "",
                  enrolledCount = enrollments.size,
                  testsTakenCount = attempts.size,
                  isAdminUser = isAdminUser,
                  onEditProfile = { pushRoute(MauryaRoute.EditProfile) },
                  onOpenMyBatches = { activeTab = BottomNavTab.BATCHES },
                  onOpenPayments = { pushRoute(MauryaRoute.PaymentHistory) },
                  onOpenDoubts = { pushRoute(MauryaRoute.DoubtsDashboard) },
                  onOpenAchievements = { pushRoute(MauryaRoute.Achievements) },
                  onOpenCertificates = { pushRoute(MauryaRoute.Certificates) },
                  onOpenSettings = { pushRoute(MauryaRoute.Settings) },
                  onOpenHelp = { pushRoute(MauryaRoute.HelpSupport) },
                  onOpenAdminPortal = { pushRoute(MauryaRoute.AdminPortal) },
                  onSignOut = { signOutUser(credentialManager, scope) },
                )
              }
            }

            is MauryaRoute.CourseExplorer -> CourseExplorerScreen(
              courses = courses,
              initialCategory = topRoute.initialCategory,
              onBack = ::popRoute,
              onSelectCourse = { course -> pushRoute(MauryaRoute.CourseDetails(course)) },
            )

            is MauryaRoute.CourseDetails -> {
              val isEnrolled = enrollments.any { it.courseId == topRoute.course.id }
              val existingEnrollment = enrollments.firstOrNull { it.courseId == topRoute.course.id }
                ?: Enrollment(
                  id = topRoute.course.id,
                  userId = user.uid,
                  courseId = topRoute.course.id,
                  courseTitle = topRoute.course.title,
                  mentorName = topRoute.course.mentorName,
                  progressPercent = 12L,
                  completedLectures = 14L,
                  totalLectures = topRoute.course.lectureCount,
                )
              CourseDetailsScreen(
                course = topRoute.course,
                isEnrolled = isEnrolled,
                isWishlisted = topRoute.course.id in wishlistIds,
                onToggleWishlist = { vm.toggleWishlist(topRoute.course.id) },
                onBack = ::popRoute,
                onOpenMentor = { mentor -> pushRoute(MauryaRoute.MentorDetail(mentor)) },
                onBuyOrEnroll = {
                  if (topRoute.course.freeCourse) {
                    vm.enrollFreeCourse(topRoute.course) {
                      subStack = emptyList()
                      activeTab = BottomNavTab.BATCHES
                    }
                  } else {
                    pushRoute(MauryaRoute.Checkout(topRoute.course))
                  }
                },
                onOpenEnrolledBatch = { pushRoute(MauryaRoute.BatchDetail(existingEnrollment)) },
                onPreviewLecture = { lecId ->
                  vm.selectLecture(lecId)
                  pushRoute(MauryaRoute.VideoPlayer)
                },
              )
            }

            is MauryaRoute.MentorDetail -> MentorProfileScreen(
              mentor = topRoute.mentor,
              courses = courses,
              onBack = ::popRoute,
              onSelectCourse = { c -> pushRoute(MauryaRoute.CourseDetails(c)) },
            )

            MauryaRoute.Notifications -> NotificationsScreen(
              notifications = notifications,
              onMarkAllRead = vm::markAllNotificationsRead,
              onBack = ::popRoute,
            )

            is MauryaRoute.BatchDetail -> BatchDetailScreen(
              enrollment = topRoute.enrollment,
              onBack = ::popRoute,
              onOpenLecture = { lecId ->
                vm.selectLecture(lecId)
                pushRoute(MauryaRoute.VideoPlayer)
              },
              onOpenLiveClasses = { pushRoute(MauryaRoute.LiveClasses) },
              onAdvanceProgress = { vm.advanceEnrollment(topRoute.enrollment) },
            )

            MauryaRoute.VideoPlayer -> VideoLecturePlayerScreen(
              playerState = playerState,
              onBack = ::popRoute,
              onSelectLecture = vm::selectLecture,
              onTogglePlayPause = vm::togglePlayPause,
              onCycleSpeed = vm::cyclePlaybackSpeed,
              onCycleQuality = vm::cycleQuality,
              onToggleFullscreen = vm::toggleFullscreen,
              onToggleBookmark = vm::toggleBookmark,
              onMarkComplete = vm::markLectureCompleted,
              onDownloadNotes = { title -> vm.startDownload(title, "pdf", "1.8 MB") },
              onAskDoubt = { pushRoute(MauryaRoute.AskDoubt) },
            )

            MauryaRoute.LiveClasses -> LiveClassesDashboardScreen(
              onBack = ::popRoute,
              onJoinLiveInteractive = { pushRoute(MauryaRoute.LiveInteractive) },
            )

            MauryaRoute.LiveInteractive -> LiveInteractiveClassScreen(
              messages = liveChat,
              onSendMessage = vm::sendLiveChatMessage,
              onBack = ::popRoute,
            )

            is MauryaRoute.PdfViewer -> PdfViewerScreen(
              note = topRoute.note,
              onBack = ::popRoute,
              onDownload = {
                vm.startDownload("${topRoute.note.title}.pdf", "pdf", topRoute.note.sizeLabel)
              },
            )

            is MauryaRoute.TestDetails -> TestDetailsAndInstructionsScreen(
              test = topRoute.test,
              onBack = ::popRoute,
              onBeginTest = {
                vm.startTest(topRoute.test)
                pushRoute(MauryaRoute.LiveTest)
              },
            )

            MauryaRoute.LiveTest -> {
              val session = activeTestSession
              if (session != null) {
                LiveTestInterfaceScreen(
                  session = session,
                  onSelectOption = vm::selectAnswer,
                  onClearOption = vm::clearAnswer,
                  onToggleMark = vm::toggleMarkForReview,
                  onJumpQuestion = vm::jumpToQuestion,
                  onSubmitTest = {
                    vm.submitActiveTest()
                    val resultAttempt = vm.activeTestSession.value?.lastAttempt
                    popRoute()
                    if (resultAttempt != null) {
                      pushRoute(MauryaRoute.TestResult(resultAttempt))
                    }
                  },
                  onExitTest = ::popRoute,
                )
              } else {
                popRoute()
              }
            }

            is MauryaRoute.TestResult -> TestResultScreen(
              attempt = topRoute.attempt,
              onBack = ::popRoute,
              onViewSolutions = { pushRoute(MauryaRoute.DetailedSolutions) },
              onOpenAnalytics = { pushRoute(MauryaRoute.Analytics) },
            )

            MauryaRoute.DetailedSolutions -> {
              val session = activeTestSession
              if (session != null) {
                DetailedSolutionsScreen(session = session, onBack = ::popRoute)
              } else {
                popRoute()
              }
            }

            MauryaRoute.Analytics -> PerformanceAnalyticsScreen(
              attempts = attempts,
              onBack = ::popRoute,
            )

            MauryaRoute.Leaderboard -> LeaderboardScreen(onBack = ::popRoute)

            MauryaRoute.DoubtsDashboard -> DoubtDashboardScreen(
              doubts = doubts,
              onBack = ::popRoute,
              onAskDoubt = { pushRoute(MauryaRoute.AskDoubt) },
              onOpenDoubt = { d -> pushRoute(MauryaRoute.DoubtDetail(d)) },
            )

            MauryaRoute.AskDoubt -> AskDoubtScreen(
              onBack = ::popRoute,
              onSubmitDoubt = { subj, chap, diff, q ->
                vm.submitDoubt(subj, chap, diff, q) { popRoute() }
              },
            )

            is MauryaRoute.DoubtDetail -> DoubtDetailScreen(
              doubt = topRoute.doubt,
              onBack = ::popRoute,
            )

            is MauryaRoute.Checkout -> CheckoutScreen(
              course = topRoute.course,
              coupons = coupons,
              onBack = ::popRoute,
              onProceedToPayment = { amt, disc, code ->
                pushRoute(MauryaRoute.PaymentMethod(topRoute.course, amt, disc, code))
              },
            )

            is MauryaRoute.PaymentMethod -> PaymentMethodAndResultFlow(
              course = topRoute.course,
              amountPaid = topRoute.amountPaid,
              discountAmount = topRoute.discountAmount,
              couponCode = topRoute.couponCode,
              onCompletePayment = { orderId, method, simSuccess, onDone ->
                vm.completePayment(
                  course = topRoute.course,
                  orderId = orderId,
                  amountPaid = topRoute.amountPaid,
                  discountAmount = topRoute.discountAmount,
                  couponCode = topRoute.couponCode,
                  paymentMethod = method,
                  simulateSuccess = simSuccess,
                  onResult = onDone,
                )
              },
              onGoToBatches = {
                subStack = emptyList()
                activeTab = BottomNavTab.BATCHES
              },
              onBack = ::popRoute,
            )

            MauryaRoute.PaymentHistory -> PaymentHistoryScreen(
              payments = payments,
              onBack = ::popRoute,
              onSelectPayment = { p -> pushRoute(MauryaRoute.OrderRefundDetail(p)) },
            )

            is MauryaRoute.OrderRefundDetail -> OrderAndRefundDetailScreen(
              payment = topRoute.payment,
              onBack = ::popRoute,
              onRequestRefund = { reason ->
                vm.requestRefund(topRoute.payment.id, reason)
                popRoute()
              },
            )

            MauryaRoute.EditProfile -> EditProfileScreen(
              profile = profile,
              onBack = ::popRoute,
              onSave = { name, phone, cls, brd, target, lang ->
                vm.saveStudentProfile(name, phone, cls, brd, target, lang)
                popRoute()
              },
            )

            MauryaRoute.Achievements -> AchievementsScreen(onBack = ::popRoute)

            MauryaRoute.Certificates -> CertificatesScreen(
              studentName = profile?.fullName ?: "Aarav Sharma",
              onBack = ::popRoute,
              onDownloadCertificate = { certTitle ->
                vm.startDownload("$certTitle.pdf", "pdf", "1.2 MB")
              },
            )

            MauryaRoute.Settings -> SettingsAndSecurityScreen(
              darkMode = darkTheme,
              appSettings = appSettings,
              onToggleDarkMode = vm::toggleDarkMode,
              onPreviewMaintenance = { pushRoute(MauryaRoute.MaintenancePreview) },
              onBack = ::popRoute,
            )

            MauryaRoute.HelpSupport -> HelpAndSupportScreen(
              tickets = tickets,
              onBack = ::popRoute,
              onRaiseTicket = { pushRoute(MauryaRoute.ContactSupport) },
            )

            MauryaRoute.ContactSupport -> ContactSupportScreen(
              onBack = ::popRoute,
              onSubmitTicket = { cat, orderId, subj, msg, contact ->
                vm.submitSupportTicket(cat, orderId, subj, msg, contact) { popRoute() }
              },
            )

            MauryaRoute.AdminPortal -> AdminPortalScreen(
              userEmail = user.email ?: "",
              isAuthorizedAdmin = isAdminUser,
              payments = payments,
              banners = banners,
              coupons = coupons,
              appSettings = appSettings,
              adminLogs = adminLogs,
              onBack = ::popRoute,
              onCreateBanner = vm::createBanner,
              onCreateCoupon = vm::createCoupon,
              onSendBroadcast = vm::sendPushBroadcast,
              onProcessRefund = vm::processRefundAdmin,
              onUpdateAppSettings = vm::updateAppSettings,
            )

            MauryaRoute.MaintenancePreview -> MaintenanceModeScreen(
              etaText = appSettings.maintenanceEta,
              isAdminUser = isAdminUser,
              onRetryOrClose = ::popRoute,
              onOpenAdminPortal = {
                popRoute()
                pushRoute(MauryaRoute.AdminPortal)
              },
            )
          }
        }
      }
    }
  }
}

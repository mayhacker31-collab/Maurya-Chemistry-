package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class MauryaExtendedColors(
  val navy: Color,
  val royalBlue: Color,
  val accentBlue: Color,
  val cardBackground: Color,
  val elevatedCard: Color,
  val border: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val success: Color,
  val warning: Color,
  val error: Color,
  val softBlue: Color,
  val softGreenTint: Color,
  val softOrangeTint: Color,
  val softPurpleTint: Color,
  val softYellowTint: Color,
  val isDark: Boolean,
)

private val LightExtendedColors = MauryaExtendedColors(
  navy = PrimaryNavy,
  royalBlue = RoyalBlue,
  accentBlue = AccentBlue,
  cardBackground = CardWhite,
  elevatedCard = Color(0xFFF8FAFF),
  border = BorderLight,
  textPrimary = TextPrimaryLight,
  textSecondary = TextSecondaryLight,
  success = SuccessGreen,
  warning = WarningAmber,
  error = ErrorRed,
  softBlue = SoftBlue,
  softGreenTint = SoftGreenTint,
  softOrangeTint = SoftOrangeTint,
  softPurpleTint = SoftPurpleTint,
  softYellowTint = SoftYellowTint,
  isDark = false,
)

private val DarkExtendedColors = MauryaExtendedColors(
  navy = PrimaryNavy,
  royalBlue = AccentBlue,
  accentBlue = AccentBlue,
  cardBackground = SurfaceDark,
  elevatedCard = ElevatedSurfaceDark,
  border = BorderDark,
  textPrimary = TextPrimaryDark,
  textSecondary = TextSecondaryDark,
  success = SuccessGreen,
  warning = WarningAmber,
  error = ErrorRed,
  softBlue = Color(0xFF1A2D4D),
  softGreenTint = Color(0xFF102C24),
  softOrangeTint = Color(0xFF332215),
  softPurpleTint = Color(0xFF231D38),
  softYellowTint = Color(0xFF2E2712),
  isDark = true,
)

val LocalMauryaColors = staticCompositionLocalOf { LightExtendedColors }

private val LightColorScheme = lightColorScheme(
  primary = RoyalBlue,
  onPrimary = Color.White,
  primaryContainer = SoftBlue,
  onPrimaryContainer = PrimaryNavy,
  secondary = PrimaryNavy,
  onSecondary = Color.White,
  secondaryContainer = SoftPurpleTint,
  onSecondaryContainer = TextPrimaryLight,
  tertiary = AccentBlue,
  onTertiary = Color.White,
  background = BackgroundLight,
  onBackground = TextPrimaryLight,
  surface = CardWhite,
  onSurface = TextPrimaryLight,
  surfaceVariant = Color(0xFFEDF2FA),
  onSurfaceVariant = TextSecondaryLight,
  outline = BorderLight,
  error = ErrorRed,
  onError = Color.White,
)

private val DarkColorScheme = darkColorScheme(
  primary = AccentBlue,
  onPrimary = PrimaryNavyDeep,
  primaryContainer = Color(0xFF1A3466),
  onPrimaryContainer = TextPrimaryDark,
  secondary = RoyalBlue,
  onSecondary = Color.White,
  secondaryContainer = ElevatedSurfaceDark,
  onSecondaryContainer = TextPrimaryDark,
  tertiary = SoftGreen,
  onTertiary = PrimaryNavyDeep,
  background = BackgroundDark,
  onBackground = TextPrimaryDark,
  surface = SurfaceDark,
  onSurface = TextPrimaryDark,
  surfaceVariant = ElevatedSurfaceDark,
  onSurfaceVariant = TextSecondaryDark,
  outline = BorderDark,
  error = ErrorRed,
  onError = Color.White,
)

object MauryaTheme {
  val colors: MauryaExtendedColors
    @Composable get() = LocalMauryaColors.current
}

@Composable
fun MauryaChemistryTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val extendedColors = if (darkTheme) DarkExtendedColors else LightExtendedColors

  CompositionLocalProvider(LocalMauryaColors provides extendedColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = MauryaTypography,
      shapes = MauryaShapes,
      content = content,
    )
  }
}

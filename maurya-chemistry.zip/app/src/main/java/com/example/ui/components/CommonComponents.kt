package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.DownloadForOffline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue

enum class BottomNavTab(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  HOME("Home", Icons.Rounded.Home, Icons.Outlined.Home),
  BATCHES("My Batches", Icons.Rounded.MenuBook, Icons.Outlined.MenuBook),
  TESTS("Tests", Icons.Rounded.Assignment, Icons.Outlined.Assignment),
  DOWNLOADS("Downloads", Icons.Rounded.DownloadForOffline, Icons.Outlined.DownloadForOffline),
  PROFILE("Profile", Icons.Rounded.Person, Icons.Outlined.Person),
}

@Composable
fun MauryaTopBar(
  title: String,
  subtitle: String? = null,
  onBack: (() -> Unit)? = null,
  navyStyle: Boolean = true,
  actions: @Composable RowScope.() -> Unit = {},
) {
  val bg = if (navyStyle) PrimaryNavy else MauryaTheme.colors.cardBackground
  val fg = if (navyStyle) Color.White else MauryaTheme.colors.textPrimary
  val subFg = if (navyStyle) Color.White.copy(alpha = 0.78f) else MauryaTheme.colors.textSecondary

  Surface(
    color = bg,
    shadowElevation = if (navyStyle) 2.dp else 1.dp,
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.statusBars)
        .padding(horizontal = 8.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      if (onBack != null) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("top_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "Back",
            tint = fg,
          )
        }
      } else {
        Spacer(Modifier.width(8.dp))
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = fg,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        if (!subtitle.isNullOrBlank()) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = subFg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
      Row(verticalAlignment = Alignment.CenterVertically, content = actions)
    }
  }
}

@Composable
fun MauryaBottomNavBar(
  activeTab: BottomNavTab,
  onSelectTab: (BottomNavTab) -> Unit,
) {
  Surface(
    color = MauryaTheme.colors.cardBackground,
    shadowElevation = 10.dp,
    border = BorderStroke(1.dp, MauryaTheme.colors.border),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(horizontal = 4.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      BottomNavTab.entries.forEach { tab ->
        val selected = tab == activeTab
        val tint = if (selected) MauryaTheme.colors.royalBlue else MauryaTheme.colors.textSecondary
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelectTab(tab) }
            .padding(vertical = 6.dp)
            .testTag("nav_${tab.name.lowercase()}"),
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(50))
              .background(if (selected) MauryaTheme.colors.softBlue else Color.Transparent)
              .padding(horizontal = 12.dp, vertical = 4.dp),
          ) {
            Icon(
              imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
              contentDescription = tab.label,
              tint = tint,
              modifier = Modifier.size(22.dp),
            )
          }
          Spacer(Modifier.height(2.dp))
          Text(
            text = tab.label,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
          )
        }
      }
    }
  }
}

@Composable
fun MauryaCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 20.dp,
  onClick: (() -> Unit)? = null,
  containerColor: Color = MauryaTheme.colors.cardBackground,
  content: @Composable ColumnScope.() -> Unit,
) {
  val cardModifier = if (onClick != null) modifier.clickable(onClick = onClick) else modifier
  Card(
    shape = RoundedCornerShape(cornerRadius),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = BorderStroke(1.dp, MauryaTheme.colors.border),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = cardModifier,
  ) {
    Column(modifier = Modifier.padding(16.dp), content = content)
  }
}

@Composable
fun StatusPill(
  text: String,
  containerColor: Color,
  contentColor: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(50),
    color = containerColor,
    modifier = modifier,
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = contentColor,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
    )
  }
}

@Composable
fun SectionHeader(
  title: String,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium,
      color = MauryaTheme.colors.textPrimary,
      fontWeight = FontWeight.Bold,
    )
    if (actionLabel != null && onAction != null) {
      TextButton(onClick = onAction) {
        Text(
          text = actionLabel,
          style = MaterialTheme.typography.labelMedium,
          color = MauryaTheme.colors.royalBlue,
          fontWeight = FontWeight.SemiBold,
        )
      }
    }
  }
}

@Composable
fun CircularProgressRing(
  progress: Float,
  centerText: String,
  subLabel: String = "",
  ringColor: Color = MauryaTheme.colors.success,
  trackColor: Color = MauryaTheme.colors.border,
  size: Dp = 88.dp,
  strokeWidth: Dp = 8.dp,
) {
  Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
    Canvas(modifier = Modifier.size(size)) {
      val strokePx = strokeWidth.toPx()
      val inset = strokePx / 2f
      val arcSize = Size(this.size.width - strokePx, this.size.height - strokePx)
      drawArc(
        color = trackColor,
        startAngle = 0f,
        sweepAngle = 360f,
        useCenter = false,
        topLeft = Offset(inset, inset),
        size = arcSize,
        style = Stroke(width = strokePx, cap = StrokeCap.Round),
      )
      drawArc(
        color = ringColor,
        startAngle = -90f,
        sweepAngle = 360f * progress.coerceIn(0f, 1f),
        useCenter = false,
        topLeft = Offset(inset, inset),
        size = arcSize,
        style = Stroke(width = strokePx, cap = StrokeCap.Round),
      )
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = centerText,
        style = MaterialTheme.typography.titleMedium,
        color = MauryaTheme.colors.textPrimary,
        fontWeight = FontWeight.Bold,
      )
      if (subLabel.isNotBlank()) {
        Text(
          text = subLabel,
          style = MaterialTheme.typography.labelSmall,
          color = MauryaTheme.colors.textSecondary,
        )
      }
    }
  }
}

@Composable
fun ScoreTrendLineChart(
  values: List<Float>,
  labels: List<String>,
  lineColor: Color = RoyalBlue,
  modifier: Modifier = Modifier.fillMaxWidth().height(160.dp),
) {
  Column(modifier = modifier) {
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
      if (values.size < 2) return@Canvas
      val maxVal = 100f
      val stepX = size.width / (values.size - 1).coerceAtLeast(1)
      val points = values.mapIndexed { idx, v ->
        Offset(
          x = idx * stepX,
          y = size.height - ((v.coerceIn(0f, maxVal) / maxVal) * size.height),
        )
      }

      // Grid lines
      listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
        val y = size.height * frac
        drawLine(
          color = Color(0xFFDCE4F2),
          start = Offset(0f, y),
          end = Offset(size.width, y),
          strokeWidth = 2f,
        )
      }

      val fillPath = Path().apply {
        moveTo(points.first().x, size.height)
        points.forEach { lineTo(it.x, it.y) }
        lineTo(points.last().x, size.height)
        close()
      }
      drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(
          colors = listOf(lineColor.copy(alpha = 0.28f), Color.Transparent),
        ),
      )

      val strokePath = Path().apply {
        moveTo(points.first().x, points.first().y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
      }
      drawPath(
        path = strokePath,
        color = lineColor,
        style = Stroke(width = 6f, cap = StrokeCap.Round),
      )

      points.forEach { pt ->
        drawCircle(color = Color.White, radius = 9f, center = pt)
        drawCircle(color = AccentBlue, radius = 5.5f, center = pt)
      }
    }
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      labels.forEach { lbl ->
        Text(
          text = lbl,
          style = MaterialTheme.typography.labelSmall,
          color = MauryaTheme.colors.textSecondary,
        )
      }
    }
  }
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TestAttempt
import com.example.data.model.TestDefinition
import com.example.data.seed.ChemistryContentCatalog
import com.example.ui.components.CircularProgressRing
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.ScoreTrendLineChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BronzeMedal
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.GoldMedal
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SilverMedal
import com.example.ui.theme.SoftBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ActiveTestSession

@Composable
fun TestDashboardScreen(
  streakDays: Long,
  attempts: List<TestAttempt>,
  onSelectTest: (TestDefinition) -> Unit,
  onOpenAnalytics: () -> Unit,
  onOpenLeaderboard: () -> Unit,
) {
  val tests = ChemistryContentCatalog.testDefinitions

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      MauryaTopBar(
        title = "Tests & Practice",
        actions = {
          IconButton(onClick = onOpenAnalytics) {
            Icon(Icons.Rounded.Analytics, contentDescription = "Analytics", tint = Color.White)
          }
          IconButton(onClick = onOpenLeaderboard) {
            Icon(Icons.Rounded.EmojiEvents, contentDescription = "Leaderboard", tint = Color.White)
          }
        },
      )
    }

    item {
      Box(
        modifier = Modifier
          .padding(horizontal = 16.dp)
          .fillMaxWidth()
          .clip(RoundedCornerShape(22.dp))
          .background(Brush.linearGradient(listOf(PrimaryNavy, RoyalBlue)))
          .padding(18.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Rounded.LocalFireDepartment,
            contentDescription = null,
            tint = Color(0xFFFFD84D),
            modifier = Modifier.size(40.dp),
          )
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("Daily Practice Streak", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
            Text("$streakDays days • Keep going!", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
          }
          Surface(
            shape = RoundedCornerShape(50),
            color = Color.White,
            modifier = Modifier.clickable { onSelectTest(tests.first()) },
          ) {
            Text(
              "Start",
              color = PrimaryNavy,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
          }
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("Quick Access", actionLabel = "Analytics", onAction = onOpenAnalytics)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          QuickAccessTile("Daily Practice", "5 Qs • 10 min", SoftBlue, Modifier.weight(1f)) { onSelectTest(tests[0]) }
          QuickAccessTile("Chapter Test", "8 Qs • 30 min", SoftGreenTint, Modifier.weight(1f)) { onSelectTest(tests[1]) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          QuickAccessTile("Mock Test 12", "10 Qs • 60 min", SoftOrangeTint, Modifier.weight(1f)) { onSelectTest(tests[2]) }
          QuickAccessTile("Leaderboard", "Top 100 Ranks", SoftPurpleTint, Modifier.weight(1f), onOpenLeaderboard)
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("Available Chemistry Tests")
      }
    }

    items(tests, key = { it.id }) { test ->
      MauryaCard(
        onClick = { onSelectTest(test) },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(modifier = Modifier.weight(1f)) {
            StatusPill(test.category, MauryaTheme.colors.softBlue, RoyalBlue)
            Spacer(Modifier.height(6.dp))
            Text(test.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("${test.questionCount} Qs • ${test.durationMinutes} mins • ${test.maxMarks} Marks", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
          }
          Button(
            onClick = { onSelectTest(test) },
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          ) {
            Text("Start", color = Color.White)
          }
        }
      }
    }

    if (attempts.isNotEmpty()) {
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
          SectionHeader("Test History")
        }
      }
      items(attempts, key = { it.id.ifBlank { "${it.testId}_${it.score}" } }) { att ->
        MauryaCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
              Text(att.testTitle, style = MaterialTheme.typography.titleSmall)
              Text("Accuracy ${att.accuracyPercent}% • +${att.correctCount} / -${att.wrongCount}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
            }
            StatusPill("${att.score}/${att.maxMarks}", MauryaTheme.colors.softGreenTint, SuccessGreen)
          }
        }
      }
    }
  }
}

@Composable
private fun QuickAccessTile(
  title: String,
  subtitle: String,
  bg: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = if (MauryaTheme.colors.isDark) MauryaTheme.colors.cardBackground else bg,
    border = BorderStroke(1.dp, MauryaTheme.colors.border),
    modifier = modifier.clickable(onClick = onClick),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Icon(Icons.Rounded.Assignment, contentDescription = title, tint = PrimaryNavy)
      Spacer(Modifier.height(8.dp))
      Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
      Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TestDetailsAndInstructionsScreen(
  test: TestDefinition,
  onBack: () -> Unit,
  onBeginTest: () -> Unit,
) {
  var acceptedRules by remember { mutableStateOf(true) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Test Details & Rules", onBack = onBack)

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text(test.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(test.pattern, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatMiniBox("Duration", "${test.durationMinutes} min", Modifier.weight(1f))
          StatMiniBox("Questions", "${test.questionCount}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatMiniBox("Max Marks", "${test.maxMarks}", Modifier.weight(1f))
          StatMiniBox("Negative", "-1 wrong", Modifier.weight(1f))
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Syllabus Covered", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          test.syllabus.forEach { ch ->
            StatusPill(ch, MauryaTheme.colors.softBlue, RoyalBlue)
          }
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Instructions", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        val rules = listOf(
          "Total duration is ${test.durationMinutes} minutes with auto-submit when timer ends.",
          "Each correct answer awards +4 marks; each wrong answer deducts -1 mark.",
          "You can Mark for Review and jump via the Question Palette anytime.",
          "Detailed step-by-step solutions unlock immediately after submission.",
        )
        rules.forEachIndexed { i, r ->
          Text("${i + 1}. $r", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary, modifier = Modifier.padding(vertical = 3.dp))
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable { acceptedRules = !acceptedRules },
      ) {
        Checkbox(checked = acceptedRules, onCheckedChange = { acceptedRules = it })
        Text("I have read and understood all instructions", style = MaterialTheme.typography.bodyMedium)
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = onBeginTest,
          enabled = acceptedRules,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(54.dp).testTag("begin_test_button"),
        ) {
          Text("Begin Test", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
      }
    }
  }
}

@Composable
private fun StatMiniBox(label: String, value: String, modifier: Modifier = Modifier) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.background,
    modifier = modifier,
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LiveTestInterfaceScreen(
  session: ActiveTestSession,
  onSelectOption: (Int, Int) -> Unit,
  onClearOption: (Int) -> Unit,
  onToggleMark: (Int) -> Unit,
  onJumpQuestion: (Int) -> Unit,
  onSubmitTest: () -> Unit,
  onExitTest: () -> Unit,
) {
  val questions = ChemistryContentCatalog.chemistryQuestions.take(session.test.questionCount)
  val qIndex = session.currentQuestionIndex.coerceIn(0, (questions.size - 1).coerceAtLeast(0))
  val question = questions[qIndex]
  val selectedOpt = session.selectedAnswers[qIndex]
  val isMarked = qIndex in session.markedForReview

  var showPaletteSheet by remember { mutableStateOf(false) }
  var showSubmitConfirm by remember { mutableStateOf(false) }

  val mins = session.remainingSeconds / 60
  val secs = session.remainingSeconds % 60
  val timerFormatted = String.format("%02d:%02d", mins, secs)

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Exam Header
      Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 3.dp) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Q${qIndex + 1} / ${questions.size}",
            style = MaterialTheme.typography.titleMedium,
            color = MauryaTheme.colors.textPrimary,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.weight(1f))
          Surface(shape = RoundedCornerShape(50), color = PrimaryNavy) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Rounded.Timer, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(6.dp))
              Text(timerFormatted, color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
          }
          Spacer(Modifier.weight(1f))
          TextButton(onClick = { showSubmitConfirm = true }) {
            Text("Submit", color = ErrorRed, fontWeight = FontWeight.Bold)
          }
        }
      }

      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          StatusPill("Chemistry • ${question.subject}", MauryaTheme.colors.softBlue, RoyalBlue)
          if (isMarked) {
            Spacer(Modifier.width(8.dp))
            StatusPill("Marked", MauryaTheme.colors.softYellowTint, WarningAmber)
          }
        }
        Spacer(Modifier.height(12.dp))

        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "Q${qIndex + 1}. ${question.question}",
            style = MaterialTheme.typography.titleMedium,
            color = MauryaTheme.colors.textPrimary,
            fontWeight = FontWeight.SemiBold,
          )
          Spacer(Modifier.height(16.dp))

          question.options.forEachIndexed { optIdx, optText ->
            val isSelected = selectedOpt == optIdx
            val labelPrefix = ('A' + optIdx).toString()
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (isSelected) MauryaTheme.colors.softBlue else MaterialTheme.colorScheme.background,
              border = BorderStroke(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) RoyalBlue else MauryaTheme.colors.border,
              ),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .clickable { onSelectOption(qIndex, optIdx) }
                .testTag("test_option_$optIdx"),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = if (isSelected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
                  contentDescription = null,
                  tint = if (isSelected) RoyalBlue else MauryaTheme.colors.textSecondary,
                )
                Spacer(Modifier.width(12.dp))
                Text("$labelPrefix) $optText", style = MaterialTheme.typography.bodyLarge)
              }
            }
          }
        }
      }

      // Bottom action bar
      Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 10.dp) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            OutlinedButton(
              onClick = { onToggleMark(qIndex) },
              border = BorderStroke(1.dp, WarningAmber),
            ) {
              Icon(Icons.Rounded.Flag, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(6.dp))
              Text(if (isMarked) "Unmark" else "Mark for Review", color = WarningAmber)
            }
            TextButton(onClick = { onClearOption(qIndex) }) {
              Text("Clear Response", color = MauryaTheme.colors.textSecondary)
            }
          }
          Spacer(Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = { if (qIndex > 0) onJumpQuestion(qIndex - 1) },
              enabled = qIndex > 0,
              modifier = Modifier.weight(1f),
            ) {
              Text("Previous")
            }
            Button(
              onClick = {
                if (qIndex < questions.lastIndex) onJumpQuestion(qIndex + 1)
                else showSubmitConfirm = true
              },
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              modifier = Modifier.weight(1.4f).testTag("save_and_next_button"),
            ) {
              Text(
                if (qIndex < questions.lastIndex) "Save & Next" else "Review & Submit",
                color = Color.White,
              )
            }
          }
        }
      }
    }

    FloatingActionButton(
      onClick = { showPaletteSheet = true },
      containerColor = RoyalBlue,
      contentColor = Color.White,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 16.dp, bottom = 128.dp)
        .testTag("question_palette_fab"),
    ) {
      Icon(Icons.Rounded.GridView, contentDescription = "Question Palette")
    }
  }

  if (showPaletteSheet) {
    ModalBottomSheet(onDismissRequest = { showPaletteSheet = false }) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Question Palette", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
          IconButton(onClick = { showPaletteSheet = false }) {
            Icon(Icons.Rounded.Close, contentDescription = "Close")
          }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          StatusPill("Answered (${session.selectedAnswers.size})", SoftGreenTint, SuccessGreen)
          StatusPill("Marked (${session.markedForReview.size})", MauryaTheme.colors.softYellowTint, WarningAmber)
        }
        Spacer(Modifier.height(14.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          questions.forEachIndexed { idx, _ ->
            val answered = idx in session.selectedAnswers
            val marked = idx in session.markedForReview
            val visited = idx in session.visitedQuestions
            val bg = when {
              marked -> WarningAmber
              answered -> SuccessGreen
              visited -> Color(0xFF94A3B8)
              else -> MauryaTheme.colors.cardBackground
            }
            val fg = if (marked || answered || visited) Color.White else MauryaTheme.colors.textPrimary
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = bg,
              border = if (idx == qIndex) BorderStroke(2.dp, RoyalBlue) else BorderStroke(1.dp, MauryaTheme.colors.border),
              modifier = Modifier
                .size(48.dp)
                .clickable {
                  onJumpQuestion(idx)
                  showPaletteSheet = false
                },
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text("${idx + 1}", color = fg, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
        Spacer(Modifier.height(18.dp))
        Button(
          onClick = {
            showPaletteSheet = false
            showSubmitConfirm = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(50.dp),
        ) {
          Text("Submit Test", color = Color.White)
        }
        Spacer(Modifier.height(16.dp))
      }
    }
  }

  if (showSubmitConfirm) {
    val answeredCount = session.selectedAnswers.size
    val unattempted = (questions.size - answeredCount).coerceAtLeast(0)
    AlertDialog(
      onDismissRequest = { showSubmitConfirm = false },
      icon = { Icon(Icons.Rounded.Warning, contentDescription = null, tint = WarningAmber) },
      title = { Text("Submit Test?") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("You won't be able to change answers after submitting.")
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill("$answeredCount Answered", SoftGreenTint, SuccessGreen)
            StatusPill("$unattempted Left", ErrorRedTint, ErrorRed)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showSubmitConfirm = false
            onSubmitTest()
          },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
        ) { Text("Submit Test", color = Color.White) }
      },
      dismissButton = {
        Row {
          TextButton(onClick = { showSubmitConfirm = false; onExitTest() }) { Text("Exit") }
          TextButton(onClick = { showSubmitConfirm = false }) { Text("Cancel") }
        }
      },
    )
  }
}

@Composable
fun TestResultScreen(
  attempt: TestAttempt,
  onBack: () -> Unit,
  onViewSolutions: () -> Unit,
  onOpenAnalytics: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Test Result", onBack = onBack)

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(Brush.linearGradient(listOf(PrimaryNavy, RoyalBlue)))
          .padding(20.dp),
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
          Text("Your Score", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
          Spacer(Modifier.height(4.dp))
          Text(
            text = "${attempt.score} / ${attempt.maxMarks}",
            style = MaterialTheme.typography.displaySmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
          )
          Spacer(Modifier.height(8.dp))
          StatusPill("Rank #24 of 312", Color.White.copy(alpha = 0.18f), Color(0xFFFFD84D))
          Spacer(Modifier.height(16.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatusPill("Correct ${attempt.correctCount}", SoftGreenTint, SuccessGreen)
            StatusPill("Wrong ${attempt.wrongCount}", ErrorRedTint, ErrorRed)
            StatusPill("Skipped ${attempt.unattemptedCount}", Color.White.copy(alpha = 0.2f), Color.White)
          }
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          CircularProgressRing(
            progress = attempt.accuracyPercent / 100f,
            centerText = "${attempt.accuracyPercent}%",
            subLabel = "Accuracy",
            ringColor = SuccessGreen,
          )
          Spacer(Modifier.width(18.dp))
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SubjectAnalysisBar("Physical Chemistry", attempt.physicalScore.toInt(), SuccessGreen)
            SubjectAnalysisBar("Organic Chemistry", attempt.organicScore.toInt(), WarningAmber)
            SubjectAnalysisBar("Inorganic Chemistry", attempt.inorganicScore.toInt(), RoyalBlue)
          }
        }
      }

      OutlinedButton(
        onClick = onViewSolutions,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(50.dp),
      ) {
        Text("View Detailed Solutions")
      }
      Button(
        onClick = onOpenAnalytics,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
        modifier = Modifier.fillMaxWidth().height(50.dp),
      ) {
        Text("Analyze Weak Topics", color = Color.White)
      }
    }
  }
}

@Composable
private fun SubjectAnalysisBar(label: String, percent: Int, color: Color) {
  Column {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, style = MaterialTheme.typography.labelMedium)
      Text("$percent%", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = color)
    }
    Spacer(Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { (percent / 100f).coerceIn(0f, 1f) },
      color = color,
      trackColor = MauryaTheme.colors.border,
      modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
    )
  }
}

@Composable
fun DetailedSolutionsScreen(
  session: ActiveTestSession,
  onBack: () -> Unit,
) {
  val questions = ChemistryContentCatalog.chemistryQuestions.take(session.test.questionCount)
  var idx by remember { mutableIntStateOf(0) }
  val q = questions[idx]
  val chosen = session.selectedAnswers[idx]
  val isCorrect = chosen == q.correctIndex

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Solutions", subtitle = "Q${idx + 1} / ${questions.size}", onBack = onBack)

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      StatusPill(
        text = when {
          chosen == null -> "Skipped"
          isCorrect -> "✓ Correct (+4)"
          else -> "✕ Wrong (-1)"
        },
        containerColor = when {
          chosen == null -> MauryaTheme.colors.softBlue
          isCorrect -> SoftGreenTint
          else -> ErrorRedTint
        },
        contentColor = when {
          chosen == null -> RoyalBlue
          isCorrect -> SuccessGreen
          else -> ErrorRed
        },
      )

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Q${idx + 1}. ${q.question}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        q.options.forEachIndexed { optIdx, text ->
          val correctOpt = optIdx == q.correctIndex
          val wrongPick = chosen == optIdx && !correctOpt
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = when {
              correctOpt -> SoftGreenTint
              wrongPick -> ErrorRedTint
              else -> MaterialTheme.colorScheme.background
            },
            border = BorderStroke(
              1.dp,
              when {
                correctOpt -> SuccessGreen
                wrongPick -> ErrorRed
                else -> MauryaTheme.colors.border
              },
            ),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
          ) {
            Text(
              text = "${'A' + optIdx}) $text",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = if (correctOpt || wrongPick) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier.padding(12.dp),
            )
          }
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Step-by-step Explanation", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        q.explanation.forEach { step ->
          Text(step, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 3.dp))
        }
        Spacer(Modifier.height(8.dp))
        StatusPill(q.conceptTag, MauryaTheme.colors.softBlue, RoyalBlue)
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(
          onClick = { if (idx > 0) idx-- },
          enabled = idx > 0,
          modifier = Modifier.weight(1f),
        ) { Text("Previous Q") }
        Button(
          onClick = { if (idx < questions.lastIndex) idx++ },
          enabled = idx < questions.lastIndex,
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.weight(1f),
        ) { Text("Next Q", color = Color.White) }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PerformanceAnalyticsScreen(
  attempts: List<TestAttempt>,
  onBack: () -> Unit,
) {
  val avg = if (attempts.isEmpty()) 74 else attempts.map { it.accuracyPercent.toInt() }.average().toInt()
  val best = if (attempts.isEmpty()) 88 else attempts.maxOf { it.accuracyPercent.toInt() }
  val trendValues = if (attempts.size >= 3) {
    attempts.take(6).reversed().map { it.accuracyPercent.toFloat() }
  } else listOf(56f, 64f, 69f, 74f, 78f, 84f)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Performance Analytics", onBack = onBack)

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          StatMiniBox("Avg Score", "$avg%", Modifier.weight(1f))
          Spacer(Modifier.width(8.dp))
          StatMiniBox("Tests", "${attempts.size.coerceAtLeast(12)}", Modifier.weight(1f))
          Spacer(Modifier.width(8.dp))
          StatMiniBox("Best", "$best%", Modifier.weight(1f))
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Score Trend", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        ScoreTrendLineChart(
          values = trendValues,
          labels = trendValues.indices.map { "T${it + 1}" },
        )
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Subject-wise Performance", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        SubjectAnalysisBar("Physical Chemistry", 82, SuccessGreen)
        Spacer(Modifier.height(8.dp))
        SubjectAnalysisBar("Organic Chemistry", 68, WarningAmber)
        Spacer(Modifier.height(8.dp))
        SubjectAnalysisBar("Inorganic Chemistry", 74, RoyalBlue)
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Topic Strengths", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("Atomic Structure", "Mole Concept", "Chemical Bonding").forEach {
            StatusPill("✓ $it", SoftGreenTint, SuccessGreen)
          }
        }
        Spacer(Modifier.height(12.dp))
        Text("Weak Topics", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("Electrochemistry", "Chemical Kinetics").forEach {
            StatusPill("! $it", SoftOrangeTint, WarningAmber)
          }
        }
      }

      MauryaCard(containerColor = MauryaTheme.colors.softBlue, modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Lightbulb, contentDescription = null, tint = RoyalBlue)
          Spacer(Modifier.width(10.dp))
          Text(
            "Tip: Focus on Electrochemistry — attempt 10 Nernst equation questions daily.",
            style = MaterialTheme.typography.bodyMedium,
          )
        }
      }
    }
  }
}

@Composable
fun LeaderboardScreen(onBack: () -> Unit) {
  val entries = ChemistryContentCatalog.leaderboard

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Leaderboard", onBack = onBack)

    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.Bottom,
        ) {
          PodiumCard(entries[1], SilverMedal, Modifier.weight(1f))
          PodiumCard(entries[0], GoldMedal, Modifier.weight(1.1f), isTop = true)
          PodiumCard(entries[2], BronzeMedal, Modifier.weight(1f))
        }
      }

      items(entries, key = { it.rank }) { item ->
        MauryaCard(
          containerColor = if (item.currentUser) MauryaTheme.colors.softBlue else MauryaTheme.colors.cardBackground,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "#${item.rank}",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = RoyalBlue,
              modifier = Modifier.width(42.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(item.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text(item.subjectTag, style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
            }
            Text("${item.score} pts", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun PodiumCard(
  entry: com.example.data.model.LeaderboardEntry,
  medalColor: Color,
  modifier: Modifier = Modifier,
  isTop: Boolean = false,
) {
  MauryaCard(
    containerColor = if (isTop) MauryaTheme.colors.softYellowTint else MauryaTheme.colors.cardBackground,
    modifier = modifier,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
      Surface(shape = CircleShape, color = medalColor, modifier = Modifier.size(if (isTop) 48.dp else 38.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Text("#${entry.rank}", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
      Spacer(Modifier.height(6.dp))
      Text(entry.name.split(" ").first(), style = MaterialTheme.typography.titleSmall, maxLines = 1)
      Text("${entry.score}", style = MaterialTheme.typography.labelMedium, color = RoyalBlue, fontWeight = FontWeight.Bold)
    }
  }
}

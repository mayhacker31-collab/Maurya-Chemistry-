package com.example.ui.auth

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoGraph
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.PrimaryNavyDeep
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftPurpleTint
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AuthFlowRoot(onAuthSuccess: () -> Unit) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  var stage by remember { mutableStateOf("splash") } // splash -> onboarding -> login

  LaunchedEffect(Unit) {
    attemptAutoSignIn(
      context = context,
      credentialManager = credentialManager,
      onAuthSuccess = onAuthSuccess,
      onUnauthenticated = {},
      scope = scope,
    )
    delay(1500)
    if (stage == "splash") {
      stage = "onboarding"
    }
  }

  when (stage) {
    "splash" -> SplashScreen()
    "onboarding" -> OnboardingScreen(
      onSkipOrFinish = { stage = "login" },
    )
    else -> LoginScreen(
      credentialManager = credentialManager,
      onAuthSuccess = onAuthSuccess,
    )
  }
}

@Composable
fun SplashScreen() {
  val pulse = rememberInfiniteTransition(label = "splashDots")
  val dotAlpha by pulse.animateFloat(
    initialValue = 0.35f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
    label = "dotAlpha",
  )

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(RoyalBlue.copy(alpha = 0.9f), PrimaryNavy, PrimaryNavyDeep),
        )
      )
      .windowInsetsPadding(WindowInsets.safeDrawing),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.padding(24.dp),
    ) {
      Surface(
        shape = CircleShape,
        color = Color.White,
        shadowElevation = 12.dp,
        modifier = Modifier.size(104.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Rounded.Science,
            contentDescription = "Maurya Chemistry Logo",
            tint = PrimaryNavy,
            modifier = Modifier.size(56.dp),
          )
        }
      }
      Spacer(Modifier.height(24.dp))
      Text(
        text = "MAURYA CHEMISTRY\nCLASSES",
        style = MaterialTheme.typography.displaySmall,
        color = Color.White,
        textAlign = TextAlign.Center,
        fontWeight = FontWeight.Bold,
      )
      Spacer(Modifier.height(8.dp))
      Surface(
        shape = RoundedCornerShape(50),
        color = AccentBlue,
      ) {
        Text(
          text = "2.0",
          style = MaterialTheme.typography.labelLarge,
          color = Color.White,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
      }
      Spacer(Modifier.height(12.dp))
      Text(
        text = "Chemistry ki Nai Udaan",
        style = MaterialTheme.typography.bodyLarge,
        color = Color.White.copy(alpha = 0.72f),
      )
    }

    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 48.dp),
    ) {
      Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.45f)))
      Box(
        Modifier
          .size(10.dp)
          .alpha(dotAlpha)
          .clip(CircleShape)
          .background(AccentBlue)
      )
      Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.45f)))
    }
  }
}

@Composable
fun OnboardingScreen(onSkipOrFinish: () -> Unit) {
  val pagerState = rememberPagerState(pageCount = { 3 })
  val scope = rememberCoroutineScope()

  val pages = remember {
    listOf(
      Triple(
        "Learn from India's Best Chemistry Mentors",
        "Live classes, recorded lectures, notes and tests — all in one app",
        0,
      ),
      Triple(
        "Live + Recorded Learning, Anytime",
        "Attend interactive live classes or watch HD recordings at your own pace",
        1,
      ),
      Triple(
        "Smart Prep with Tests & Analytics",
        "Track your JEE/NEET rank progress and improve with step-by-step solutions",
        2,
      ),
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(BackgroundLight)
      .windowInsetsPadding(WindowInsets.safeDrawing)
      .padding(horizontal = 24.dp, vertical = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End,
    ) {
      TextButton(
        onClick = onSkipOrFinish,
        modifier = Modifier.testTag("onboarding_skip_button"),
      ) {
        Text("Skip", color = RoyalBlue, fontWeight = FontWeight.SemiBold)
      }
    }

    HorizontalPager(
      state = pagerState,
      modifier = Modifier.weight(1f),
    ) { page ->
      val item = pages[page]
      Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        when (item.third) {
          0 -> {
            Image(
              painter = painterResource(id = R.drawable.img_onboarding_chemistry),
              contentDescription = "Chemistry Mentor Illustration",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(24.dp)),
            )
          }
          1 -> {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(SoftGreenTint),
              contentAlignment = Alignment.Center,
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                  shape = RoundedCornerShape(16.dp),
                  color = Color(0xFFE34D59),
                ) {
                  Text(
                    text = "● LIVE",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                  )
                }
                Spacer(Modifier.height(16.dp))
                Surface(
                  shape = CircleShape,
                  color = RoyalBlue,
                  modifier = Modifier.size(84.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Rounded.PlayCircle,
                      contentDescription = "Live Video Player",
                      tint = Color.White,
                      modifier = Modifier.size(48.dp),
                    )
                  }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                  text = "HD Lectures + Formula Notes PDFs",
                  style = MaterialTheme.typography.titleSmall,
                  color = PrimaryNavy,
                )
              }
            }
          }
          else -> {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(SoftPurpleTint),
              contentAlignment = Alignment.Center,
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                  shape = CircleShape,
                  color = PrimaryNavy,
                  modifier = Modifier.size(88.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Rounded.AutoGraph,
                      contentDescription = "Smart Analytics",
                      tint = Color(0xFFFFD84D),
                      modifier = Modifier.size(48.dp),
                    )
                  }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                  text = "78% Accuracy • All-India Rank Insights",
                  style = MaterialTheme.typography.titleSmall,
                  color = PrimaryNavy,
                )
              }
            }
          }
        }

        Spacer(Modifier.height(32.dp))
        Text(
          text = item.first,
          style = MaterialTheme.typography.headlineMedium,
          color = PrimaryNavy,
          textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(
          text = item.second,
          style = MaterialTheme.typography.bodyLarge,
          color = MauryaTheme.colors.textSecondary,
          textAlign = TextAlign.Center,
        )
      }
    }

    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(vertical = 16.dp),
    ) {
      repeat(3) { index ->
        val active = pagerState.currentPage == index
        Box(
          modifier = Modifier
            .height(8.dp)
            .width(if (active) 24.dp else 8.dp)
            .clip(CircleShape)
            .background(if (active) RoyalBlue else Color(0xFFD0D9EA))
        )
      }
    }

    Button(
      onClick = {
        if (pagerState.currentPage < 2) {
          scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
        } else {
          onSkipOrFinish()
        }
      },
      shape = RoundedCornerShape(16.dp),
      colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
      modifier = Modifier
        .fillMaxWidth()
        .height(54.dp)
        .testTag("onboarding_next_button"),
    ) {
      Text(
        text = if (pagerState.currentPage == 2) "Get Started" else "Next",
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
      )
    }
    Spacer(Modifier.height(8.dp))
  }
}

@Composable
fun LoginScreen(
  credentialManager: CredentialManager,
  onAuthSuccess: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(PrimaryNavy, PrimaryNavyDeep),
        )
      )
      .windowInsetsPadding(WindowInsets.safeDrawing)
      .verticalScroll(rememberScrollState())
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Surface(
      shape = CircleShape,
      color = Color.White,
      modifier = Modifier.size(84.dp),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Rounded.Science,
          contentDescription = "Maurya Chemistry Emblem",
          tint = PrimaryNavy,
          modifier = Modifier.size(44.dp),
        )
      }
    }
    Spacer(Modifier.height(16.dp))
    Text(
      text = "MAURYA CHEMISTRY CLASSES 2.0",
      style = MaterialTheme.typography.titleMedium,
      color = Color.White,
      fontWeight = FontWeight.Bold,
      textAlign = TextAlign.Center,
    )
    Spacer(Modifier.height(24.dp))

    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp),
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Text(
          text = "Welcome Back",
          style = MaterialTheme.typography.headlineMedium,
          color = PrimaryNavy,
        )
        Spacer(Modifier.height(8.dp))
        Text(
          text = "Sign in securely with Google to sync your batches, live classes, mock tests, and notes across devices.",
          style = MaterialTheme.typography.bodyMedium,
          color = Color(0xFF6B7790),
          textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))

        Button(
          onClick = {
            errorMessage = null
            isLoading = true
            onGoogleSignInClicked(
              context = context,
              credentialManager = credentialManager,
              onAuthSuccess = {
                isLoading = false
                onAuthSuccess()
              },
              onAuthError = { msg ->
                isLoading = false
                errorMessage = msg
              },
              scope = scope,
              onAuthCancelled = {
                isLoading = false
              },
            )
          },
          enabled = !isLoading,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("google_sign_in_button"),
        ) {
          if (isLoading) {
            CircularProgressIndicator(
              modifier = Modifier.size(22.dp),
              color = Color.White,
              strokeWidth = 2.dp,
            )
          } else {
            Icon(
              imageVector = Icons.Rounded.VerifiedUser,
              contentDescription = null,
              tint = Color.White,
            )
            Spacer(Modifier.width(10.dp))
            Text(
              text = "Sign in with Google",
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
          }
        }

        if (errorMessage != null) {
          Spacer(Modifier.height(12.dp))
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFFDECEF),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = errorMessage ?: "",
              color = Color(0xFFE34D59),
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.padding(12.dp),
            )
          }
        }

        Spacer(Modifier.height(16.dp))
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          Icon(
            imageVector = Icons.Rounded.CheckCircle,
            contentDescription = null,
            tint = SuccessGreen,
            modifier = Modifier.size(16.dp),
          )
          Spacer(Modifier.width(6.dp))
          Text(
            text = "Protected by Google Identity & Firebase",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF6B7790),
          )
        }
      }
    }

    Spacer(Modifier.height(20.dp))
    Text(
      text = "By continuing, you agree to Maurya Chemistry Terms & Privacy Policy",
      style = MaterialTheme.typography.bodySmall,
      color = Color.White.copy(alpha = 0.7f),
      textAlign = TextAlign.Center,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudentProfileSetupSheet(
  initialName: String,
  initialEmail: String,
  onSaveProfile: (
    fullName: String,
    phone: String,
    studentClass: String,
    board: String,
    examTarget: String,
    language: String,
  ) -> Unit,
) {
  var fullName by remember { mutableStateOf(initialName.ifBlank { "Aarav Sharma" }) }
  var phone by remember { mutableStateOf("+91 98765 43210") }
  var selectedClass by remember { mutableStateOf("Class 12") }
  var selectedBoard by remember { mutableStateOf("CBSE") }
  var selectedExam by remember { mutableStateOf("JEE") }
  var selectedLanguage by remember { mutableStateOf("English") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MauryaTheme.colors.cardBackground)
      .windowInsetsPadding(WindowInsets.safeDrawing)
      .verticalScroll(rememberScrollState())
      .padding(24.dp),
  ) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      repeat(4) { idx ->
        Box(
          modifier = Modifier
            .weight(1f)
            .height(6.dp)
            .clip(CircleShape)
            .background(if (idx == 3) RoyalBlue else RoyalBlue.copy(alpha = 0.25f))
        )
      }
    }
    Spacer(Modifier.height(20.dp))
    Text(
      text = "Setup your profile",
      style = MaterialTheme.typography.headlineMedium,
      color = MauryaTheme.colors.textPrimary,
    )
    Spacer(Modifier.height(4.dp))
    Text(
      text = "Personalize your chemistry courses, mock tests, and notes ($initialEmail)",
      style = MaterialTheme.typography.bodyMedium,
      color = MauryaTheme.colors.textSecondary,
    )
    Spacer(Modifier.height(20.dp))

    OutlinedTextField(
      value = fullName,
      onValueChange = { fullName = it },
      label = { Text("Full Name") },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier.fillMaxWidth().testTag("setup_name_input"),
    )
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(
      value = phone,
      onValueChange = { phone = it },
      label = { Text("Mobile Number") },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier.fillMaxWidth(),
    )

    Spacer(Modifier.height(16.dp))
    Text("Class", style = MaterialTheme.typography.titleSmall, color = MauryaTheme.colors.textPrimary)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("Class 11", "Class 12", "Dropper").forEach { item ->
        FilterChip(
          selected = selectedClass == item,
          onClick = { selectedClass = item },
          label = { Text(item) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalBlue,
            selectedLabelColor = Color.White,
          ),
        )
      }
    }

    Spacer(Modifier.height(12.dp))
    Text("Board", style = MaterialTheme.typography.titleSmall, color = MauryaTheme.colors.textPrimary)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("CBSE", "ICSE", "State").forEach { item ->
        FilterChip(
          selected = selectedBoard == item,
          onClick = { selectedBoard = item },
          label = { Text(item) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalBlue,
            selectedLabelColor = Color.White,
          ),
        )
      }
    }

    Spacer(Modifier.height(12.dp))
    Text("Exam Target", style = MaterialTheme.typography.titleSmall, color = MauryaTheme.colors.textPrimary)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("JEE", "NEET", "CBSE", "Foundation").forEach { item ->
        FilterChip(
          selected = selectedExam == item,
          onClick = { selectedExam = item },
          label = { Text(item) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalBlue,
            selectedLabelColor = Color.White,
          ),
        )
      }
    }

    Spacer(Modifier.height(12.dp))
    Text("Preferred Language", style = MaterialTheme.typography.titleSmall, color = MauryaTheme.colors.textPrimary)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("English", "Hindi").forEach { item ->
        FilterChip(
          selected = selectedLanguage == item,
          onClick = { selectedLanguage = item },
          label = { Text(item) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalBlue,
            selectedLabelColor = Color.White,
          ),
        )
      }
    }

    Spacer(Modifier.height(28.dp))
    Button(
      onClick = {
        onSaveProfile(fullName, phone, selectedClass, selectedBoard, selectedExam, selectedLanguage)
      },
      shape = RoundedCornerShape(16.dp),
      colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
      modifier = Modifier
        .fillMaxWidth()
        .height(54.dp)
        .testTag("complete_setup_button"),
    ) {
      Text("Complete Setup", style = MaterialTheme.typography.titleMedium, color = Color.White)
    }
    Spacer(Modifier.windowInsetsPadding(WindowInsets.navigationBars))
  }
}

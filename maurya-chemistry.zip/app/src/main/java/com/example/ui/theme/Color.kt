package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Light Palette
val PrimaryNavy = Color(0xFF0F2A5C)
val PrimaryNavyDeep = Color(0xFF091B3E)
val RoyalBlue = Color(0xFF1E4AA8)
val AccentBlue = Color(0xFF4FA8F0)
val BackgroundLight = Color(0xFFF3F6FC)
val CardWhite = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0E1A33)
val TextSecondaryLight = Color(0xFF6B7790)
val BorderLight = Color(0xFFE5EAF4)

// Pastel Accents
val SoftBlue = Color(0xFFE8F1FF)
val SoftOrange = Color(0xFFF9B98C)
val SoftOrangeTint = Color(0xFFFFF3EB)
val SoftGreen = Color(0xFF7FD9B0)
val SoftGreenTint = Color(0xFFEAF9F1)
val SoftPurple = Color(0xFFCDB8F5)
val SoftPurpleTint = Color(0xFFF3EEFD)
val SoftYellow = Color(0xFFFFD84D)
val SoftYellowTint = Color(0xFFFFF9E2)

// Semantic Status Colors
val SuccessGreen = Color(0xFF16A36A)
val WarningAmber = Color(0xFFF0A329)
val ErrorRed = Color(0xFFE34D59)
val ErrorRedTint = Color(0xFFFDECEF)
val UpiPurple = Color(0xFF6C4EFF)

// Medal Colors
val GoldMedal = Color(0xFFD4A017)
val SilverMedal = Color(0xFFA8B5C9)
val BronzeMedal = Color(0xFFB87333)

// Dark Mode Palette
val BackgroundDark = Color(0xFF0B1220)
val SurfaceDark = Color(0xFF121D30)
val ElevatedSurfaceDark = Color(0xFF18263C)
val TextPrimaryDark = Color(0xFFF3F6FC)
val TextSecondaryDark = Color(0xFFA8B5C9)
val BorderDark = Color(0xFF243349)

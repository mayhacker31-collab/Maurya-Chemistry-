package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.Coupon
import com.example.data.model.Course
import com.example.data.model.Doubt
import com.example.data.model.PaymentRecord
import com.example.ui.components.MauryaCard
import com.example.ui.components.MauryaTopBar
import com.example.ui.components.StatusPill
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedTint
import com.example.ui.theme.MauryaTheme
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SoftGreenTint
import com.example.ui.theme.SoftOrangeTint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay

@Composable
fun DoubtDashboardScreen(
  doubts: List<Doubt>,
  onBack: () -> Unit,
  onAskDoubt: () -> Unit,
  onOpenDoubt: (Doubt) -> Unit,
) {
  var tabIdx by remember { mutableIntStateOf(0) }
  val source = if (doubts.isNotEmpty()) doubts else listOf(
    Doubt(
      id = "d_sample_1",
      subject = "Physical Chemistry",
      chapter = "Chemical Bonding",
      difficulty = "Medium",
      questionText = "Why does BF₃ have sp² hybridisation instead of sp³?",
      status = "answered",
      replyText = "Boron has 3 valence electrons forming 3 bond pairs and 0 lone pairs. Steric number = 3 → sp² trigonal planar (120°).",
      mentorName = "Dr. R. Verma",
      replyCount = 2L,
    ),
    Doubt(
      id = "d_sample_2",
      subject = "Organic Chemistry",
      chapter = "Stereochemistry",
      difficulty = "Hard",
      questionText = "How to identify meso compounds vs racemic mixtures quickly?",
      status = "pending",
      mentorName = "Prof. S. Mehta",
      replyCount = 0L,
    ),
  )

  val filtered = when (tabIdx) {
    0 -> source
    1 -> source.filter { it.status == "pending" }
    else -> source.filter { it.status == "answered" }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      MauryaTopBar(title = "My Doubts", onBack = onBack)

      MauryaCard(
        containerColor = MauryaTheme.colors.softBlue,
        modifier = Modifier.fillMaxWidth().padding(16.dp),
      ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${source.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Asked", style = MaterialTheme.typography.labelSmall)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${source.count { it.status == "answered" }}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SuccessGreen)
            Text("Answered", style = MaterialTheme.typography.labelSmall)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${source.count { it.status == "pending" }}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = WarningAmber)
            Text("Pending", style = MaterialTheme.typography.labelSmall)
          }
        }
      }

      TabRow(selectedTabIndex = tabIdx) {
        Tab(selected = tabIdx == 0, onClick = { tabIdx = 0 }, text = { Text("All") })
        Tab(selected = tabIdx == 1, onClick = { tabIdx = 1 }, text = { Text("Pending") })
        Tab(selected = tabIdx == 2, onClick = { tabIdx = 2 }, text = { Text("Answered") })
      }

      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        items(filtered, key = { it.id }) { doubt ->
          val answered = doubt.status == "answered"
          MauryaCard(onClick = { onOpenDoubt(doubt) }, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              StatusPill(doubt.subject, MauryaTheme.colors.softBlue, RoyalBlue)
              StatusPill(
                text = if (answered) "Answered" else "Pending",
                containerColor = if (answered) SoftGreenTint else SoftOrangeTint,
                contentColor = if (answered) SuccessGreen else WarningAmber,
              )
            }
            Spacer(Modifier.height(8.dp))
            Text(doubt.questionText, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("${doubt.chapter} • ${doubt.difficulty}", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          }
        }
      }
    }

    FloatingActionButton(
      onClick = onAskDoubt,
      containerColor = RoyalBlue,
      contentColor = Color.White,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(20.dp)
        .testTag("ask_doubt_fab"),
    ) {
      Icon(Icons.Rounded.Add, contentDescription = "Ask a Doubt")
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AskDoubtScreen(
  onBack: () -> Unit,
  onSubmitDoubt: (subject: String, chapter: String, difficulty: String, question: String) -> Unit,
) {
  var question by remember { mutableStateOf("") }
  var subject by remember { mutableStateOf("Physical Chemistry") }
  var chapter by remember { mutableStateOf("Chemical Bonding") }
  var difficulty by remember { mutableStateOf("Medium") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Ask a Doubt", onBack = onBack)

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      OutlinedTextField(
        value = question,
        onValueChange = { if (it.length <= 500) question = it },
        label = { Text("Describe your chemistry doubt clearly...") },
        supportingText = { Text("${question.length}/500") },
        minLines = 4,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().testTag("ask_doubt_input"),
      )

      Text("Subject", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Physical Chemistry", "Organic Chemistry", "Inorganic Chemistry").forEach { s ->
          FilterChip(
            selected = subject == s,
            onClick = { subject = s },
            label = { Text(s) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      OutlinedTextField(
        value = chapter,
        onValueChange = { chapter = it },
        label = { Text("Chapter") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )

      Text("Difficulty", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Easy", "Medium", "Hard").forEach { d ->
          FilterChip(
            selected = difficulty == d,
            onClick = { difficulty = d },
            label = { Text(d) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(14.dp),
        color = MauryaTheme.colors.softYellowTint,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          "Average mentor response time: 2-4 hours",
          style = MaterialTheme.typography.bodySmall,
          modifier = Modifier.padding(12.dp),
        )
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = { onSubmitDoubt(subject, chapter, difficulty, question) },
          enabled = question.trim().length >= 3,
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(54.dp).testTag("submit_doubt_button"),
        ) {
          Text("Submit Doubt", color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
      }
    }
  }
}

@Composable
fun DoubtDetailScreen(doubt: Doubt, onBack: () -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Doubt Detail", onBack = onBack)
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          StatusPill(doubt.subject, MauryaTheme.colors.softBlue, RoyalBlue)
          StatusPill(doubt.chapter, MauryaTheme.colors.softPurpleTint, PrimaryNavy)
        }
        Spacer(Modifier.height(10.dp))
        Text(doubt.questionText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }

      MauryaCard(
        containerColor = if (doubt.status == "answered") MauryaTheme.colors.softGreenTint else MauryaTheme.colors.softOrangeTint,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = if (doubt.status == "answered") "Solution by ${doubt.mentorName}" else "Awaiting Mentor Reply",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text = doubt.replyText.ifBlank { "Your doubt is in queue with Dr. R. Verma's academic team." },
          style = MaterialTheme.typography.bodyMedium,
        )
      }
    }
  }
}

@Composable
fun CheckoutScreen(
  course: Course,
  coupons: List<Coupon>,
  onBack: () -> Unit,
  onProceedToPayment: (amountPaid: Long, discountAmount: Long, couponCode: String) -> Unit,
) {
  var couponInput by remember { mutableStateOf("MAURYA500") }
  var appliedCoupon by remember { mutableStateOf<Coupon?>(coupons.firstOrNull { it.code == "MAURYA500" }) }
  var couponFeedback by remember { mutableStateOf<String?>(null) }

  val basePrice = course.price
  val couponDiscount = when (val c = appliedCoupon) {
    null -> 0L
    else -> if (c.discountType == "percentage") (basePrice * c.discountValue) / 100L else c.discountValue
  }.coerceAtMost(basePrice)
  val totalAmount = (basePrice - couponDiscount).coerceAtLeast(0L)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Checkout", onBack = onBack)

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Your Course", style = MaterialTheme.typography.labelMedium, color = MauryaTheme.colors.textSecondary)
        Spacer(Modifier.height(4.dp))
        Text(course.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("${course.mentorName} • ${course.validityText}", style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Apply Coupon", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          OutlinedTextField(
            value = couponInput,
            onValueChange = { couponInput = it.uppercase() },
            placeholder = { Text("Enter coupon code") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f),
          )
          Spacer(Modifier.width(8.dp))
          OutlinedButton(
            onClick = {
              val match = coupons.firstOrNull { it.code.equals(couponInput.trim(), ignoreCase = true) && it.status == "active" }
                ?: if (couponInput.trim().equals("MAURYA500", ignoreCase = true)) {
                  Coupon(id = "MAURYA500", code = "MAURYA500", discountType = "flat", discountValue = 500L)
                } else null
              appliedCoupon = match
              couponFeedback = if (match != null) "Coupon ${match.code} applied!" else "Invalid or expired coupon"
            },
          ) { Text("Apply") }
        }
        if (couponFeedback != null) {
          Spacer(Modifier.height(6.dp))
          Text(
            couponFeedback ?: "",
            style = MaterialTheme.typography.labelSmall,
            color = if (appliedCoupon != null) SuccessGreen else ErrorRed,
          )
        }
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        Text("Price Details", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        PriceRow("Original MRP", "₹${course.mrp}", strikethrough = true)
        PriceRow("Course Discount", "-₹${(course.mrp - basePrice).coerceAtLeast(0L)}", valueColor = SuccessGreen)
        if (couponDiscount > 0L) {
          PriceRow("Coupon (${appliedCoupon?.code})", "-₹$couponDiscount", valueColor = SuccessGreen)
        }
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Total Amount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text("₹$totalAmount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PrimaryNavy)
        }
      }
    }

    Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Payable", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
          Text("₹$totalAmount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Button(
          onClick = {
            onProceedToPayment(
              totalAmount,
              (course.mrp - totalAmount).coerceAtLeast(0L),
              appliedCoupon?.code ?: "",
            )
          },
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.height(52.dp).testTag("continue_to_payment_button"),
        ) {
          Text("Continue to Payment", color = Color.White)
        }
      }
    }
  }
}

@Composable
private fun PriceRow(
  label: String,
  value: String,
  valueColor: Color = MauryaTheme.colors.textPrimary,
  strikethrough: Boolean = false,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(label, style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
    Text(
      text = value,
      style = if (strikethrough) MaterialTheme.typography.bodyMedium.copy(textDecoration = TextDecoration.LineThrough)
      else MaterialTheme.typography.bodyMedium,
      color = valueColor,
      fontWeight = FontWeight.SemiBold,
    )
  }
}

@Composable
fun PaymentMethodAndResultFlow(
  course: Course,
  amountPaid: Long,
  discountAmount: Long,
  couponCode: String,
  onCompletePayment: (orderId: String, method: String, success: Boolean, onDone: (Boolean) -> Unit) -> Unit,
  onGoToBatches: () -> Unit,
  onBack: () -> Unit,
) {
  var stage by remember { mutableStateOf("method") } // method | processing | success | failed
  var selectedMethod by remember { mutableStateOf("UPI • PhonePe") }
  val orderId = remember { "TXN20261123MC${(1000..9999).random()}" }

  when (stage) {
    "method" -> {
      val methods = listOf(
        "UPI • PhonePe" to "Pay via GPay, PhonePe, Paytm, BHIM (Recommended)",
        "Credit / Debit Card" to "Visa, Mastercard, RuPay",
        "Net Banking" to "All major Indian banks",
        "PhonePe Wallet" to "Instant wallet checkout",
        "Pay Later" to "Simpl, LazyPay",
      )
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(MaterialTheme.colorScheme.background),
      ) {
        MauryaTopBar(title = "Payment Method", onBack = onBack)
        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("256-bit SSL secured checkout", style = MaterialTheme.typography.labelMedium, color = MauryaTheme.colors.textSecondary)
          }
          methods.forEach { (name, sub) ->
            val selected = selectedMethod == name
            MauryaCard(
              onClick = { selectedMethod = name },
              containerColor = if (selected) MauryaTheme.colors.softBlue else MauryaTheme.colors.cardBackground,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (selected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
                  contentDescription = null,
                  tint = if (selected) RoyalBlue else MauryaTheme.colors.textSecondary,
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                  Text(sub, style = MaterialTheme.typography.bodySmall, color = MauryaTheme.colors.textSecondary)
                }
              }
            }
          }
        }
        Surface(color = MauryaTheme.colors.cardBackground, shadowElevation = 8.dp) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                stage = "processing"
                onCompletePayment(orderId, selectedMethod, true) { ok ->
                  stage = if (ok) "success" else "failed"
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.fillMaxWidth().height(54.dp).testTag("pay_now_button"),
            ) {
              Text("Pay Now ₹$amountPaid", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
          }
        }
      }
    }

    "processing" -> {
      LaunchedEffect(Unit) {
        delay(1200)
      }
      Column(
        modifier = Modifier.fillMaxSize().background(MauryaTheme.colors.cardBackground).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        CircularProgressIndicator(color = RoyalBlue, modifier = Modifier.size(64.dp), strokeWidth = 5.dp)
        Spacer(Modifier.height(20.dp))
        Text("Processing Payment...", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Please don't close this screen • ₹$amountPaid", style = MaterialTheme.typography.bodyMedium, color = MauryaTheme.colors.textSecondary)
      }
    }

    "success" -> {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(SoftGreenTint)
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Surface(shape = CircleShape, color = SuccessGreen, modifier = Modifier.size(88.dp)) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
          }
        }
        Spacer(Modifier.height(18.dp))
        Text("Payment Successful!", style = MaterialTheme.typography.headlineMedium, color = PrimaryNavy, fontWeight = FontWeight.Bold)
        Text("Your batch is now unlocked", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569))
        Spacer(Modifier.height(18.dp))
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          PriceRow("Order ID", orderId)
          PriceRow("Amount Paid", "₹$amountPaid", valueColor = SuccessGreen)
          PriceRow("Course", course.title)
          PriceRow("Method", selectedMethod)
        }
        Spacer(Modifier.height(20.dp))
        Button(
          onClick = onGoToBatches,
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
          Text("Go to My Batches", color = Color.White)
        }
      }
    }

    else -> {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(ErrorRedTint)
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Surface(shape = CircleShape, color = ErrorRed, modifier = Modifier.size(84.dp)) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
          }
        }
        Spacer(Modifier.height(16.dp))
        Text("Payment Failed", style = MaterialTheme.typography.headlineMedium, color = PrimaryNavy, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Don't worry — any deducted amount auto-refunds in 3-5 days.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569))
        Spacer(Modifier.height(20.dp))
        Button(
          onClick = { stage = "method" },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
          Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.White)
          Spacer(Modifier.width(8.dp))
          Text("Retry Payment", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun PaymentHistoryScreen(
  payments: List<PaymentRecord>,
  onBack: () -> Unit,
  onSelectPayment: (PaymentRecord) -> Unit,
) {
  var filter by remember { mutableStateOf("All") }
  val source = if (payments.isNotEmpty()) payments else listOf(
    PaymentRecord(
      id = "demo_pay_1",
      orderId = "TXN20261123MH7821",
      courseId = "batch_2027_jee",
      courseTitle = "Batch 2027 — JEE Chemistry",
      amount = 2999L,
      originalAmount = 6999L,
      discountAmount = 4000L,
      couponCode = "MAURYA500",
      paymentMethod = "UPI • PhonePe",
      status = "successful",
    ),
  )

  val filtered = source.filter {
    when (filter) {
      "Successful" -> it.status == "successful"
      "Failed" -> it.status == "failed"
      "Refunded" -> it.status == "refunded" || it.status == "refund_in_progress"
      else -> true
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Payment History", onBack = onBack)

    Row(
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      listOf("All", "Successful", "Failed", "Refunded").forEach { f ->
        FilterChip(
          selected = filter == f,
          onClick = { filter = f },
          label = { Text(f) },
          colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = Color.White),
        )
      }
    }

    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(filtered, key = { it.id }) { p ->
        val (chipBg, chipFg, label) = when (p.status) {
          "successful" -> Triple(SoftGreenTint, SuccessGreen, "Successful")
          "failed" -> Triple(ErrorRedTint, ErrorRed, "Failed")
          "refund_in_progress" -> Triple(SoftOrangeTint, WarningAmber, "Refund Pending")
          else -> Triple(SoftOrangeTint, WarningAmber, "Refunded")
        }
        MauryaCard(onClick = { onSelectPayment(p) }, modifier = Modifier.fillMaxWidth()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ReceiptLong, contentDescription = null, tint = chipFg)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(p.courseTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Text("${p.orderId} • ${p.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = MauryaTheme.colors.textSecondary)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("₹${p.amount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              Spacer(Modifier.height(4.dp))
              StatusPill(label, chipBg, chipFg)
            }
          }
        }
      }
    }
  }
}

@Composable
fun OrderAndRefundDetailScreen(
  payment: PaymentRecord,
  onBack: () -> Unit,
  onRequestRefund: (String) -> Unit,
) {
  var refundReason by remember { mutableStateOf("Switched to another target batch") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    MauryaTopBar(title = "Order & Refund Status", onBack = onBack)
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      MauryaCard(
        containerColor = if (payment.status == "successful") SoftGreenTint else SoftOrangeTint,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = when (payment.status) {
            "successful" -> "Order Successful"
            "refund_in_progress" -> "Refund in Progress"
            "refunded" -> "Refunded to Source"
            else -> "Payment Failed"
          },
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = PrimaryNavy,
        )
        Text("Order ID: ${payment.orderId}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
      }

      MauryaCard(modifier = Modifier.fillMaxWidth()) {
        PriceRow("Course", payment.courseTitle)
        PriceRow("Amount Paid", "₹${payment.amount}")
        PriceRow("Method", payment.paymentMethod)
        if (payment.couponCode.isNotBlank()) PriceRow("Coupon", payment.couponCode, valueColor = SuccessGreen)
        if (payment.refundReason.isNotBlank()) PriceRow("Refund Reason", payment.refundReason)
      }

      if (payment.status == "successful" && payment.id != "demo_pay_1") {
        MauryaCard(modifier = Modifier.fillMaxWidth()) {
          Text("Request Refund", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Spacer(Modifier.height(8.dp))
          OutlinedTextField(
            value = refundReason,
            onValueChange = { refundReason = it },
            label = { Text("Reason") },
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(Modifier.height(10.dp))
          OutlinedButton(
            onClick = { onRequestRefund(refundReason) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text("Submit Refund Request")
          }
        }
      }
    }
  }
}

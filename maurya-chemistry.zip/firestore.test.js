const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_student_1";
const BOB_UID = "bob_student_2";
const ADMIN_UID = "admin_maurya_1";
const ADMIN_EMAIL = "gentoincfacts@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("courses").where("status", "==", "active").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("adminLogs").get());
});

test("Student can create & update own profile but cannot escalate role or read another student", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = new Date(Date.now() - 2000);

  // Valid create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      fullName: "Aarav Sharma",
      email: "alice@example.com",
      phone: "+91 9876543210",
      studentClass: "Class 12",
      board: "CBSE",
      examTarget: "JEE",
      preferredLanguage: "English",
      role: "student",
      darkMode: false,
      streakDays: 7,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid partial update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      darkMode: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Shadow / Role escalation attempt must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "admin",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Cross-user PII read must fail
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
});

test("Email spoofing attack without email_verified fails admin access", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  const now = new Date(Date.now() - 1000);
  await assertFails(
    spoofDb.collection("courses").doc("course_jee_1").set({
      title: "Spoofed Course",
      category: "JEE",
      mentorName: "Fake",
      price: 100,
      mrp: 200,
      discountPercent: 50,
      freeCourse: false,
      rating: 4.5,
      lectureCount: 10,
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Verified admin can manage courses, banners, coupons, settings, and immutable audit logs", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    adminDb.collection("courses").doc("jee_2027").set({
      title: "Batch 2027 - JEE Chemistry",
      subtitle: "Physical, Organic & Inorganic Mastery",
      category: "JEE",
      mentorName: "Dr. R. Verma",
      mentorQualification: "M.Sc. Chemistry",
      price: 3499,
      mrp: 6999,
      discountPercent: 50,
      freeCourse: false,
      rating: 4.9,
      lectureCount: 120,
      validityText: "Valid till Mar 2027",
      language: "Hindi + English",
      description: "Complete JEE Main & Advanced Chemistry batch.",
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Student filtered query matches rule
  await assertSucceeds(
    aliceDb.collection("courses").where("status", "==", "active").get()
  );
  // Student unfiltered query must fail
  await assertFails(aliceDb.collection("courses").get());

  // Student cannot write course
  await assertFails(
    aliceDb.collection("courses").doc("hacked").set({
      title: "Hacked",
      category: "JEE",
      mentorName: "Hacker",
      price: 0,
      mrp: 100,
      discountPercent: 100,
      freeCourse: true,
      rating: 5.0,
      lectureCount: 1,
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Admin audit log creation succeeds, update fails (immutable)
  await assertSucceeds(
    adminDb.collection("adminLogs").doc("log_1").set({
      adminUid: ADMIN_UID,
      adminEmail: ADMIN_EMAIL,
      action: "CREATE_COURSE",
      targetEntity: "courses/jee_2027",
      details: "Published Batch 2027 JEE Chemistry at INR 3499",
      createdAt: now,
    })
  );
  await assertFails(
    adminDb.collection("adminLogs").doc("log_1").update({ details: "Tampered" })
  );
});

test("Student enrollments, payments, refunds, test attempts, doubts, and tickets follow ownership and state locks", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 2000);

  // Payment create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("payments").doc("pay_1").set({
      userId: ALICE_UID,
      orderId: "TXN20261123MH7821",
      courseId: "jee_2027",
      courseTitle: "Batch 2027 - JEE Chemistry",
      amount: 2999,
      originalAmount: 6999,
      discountAmount: 4000,
      couponCode: "MAURYA500",
      paymentMethod: "UPI • PhonePe",
      status: "successful",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Student requests refund
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("payments").doc("pay_1").update({
      status: "refund_in_progress",
      refundReason: "Switched to NEET batch",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Student cannot self-approve refund
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("payments").doc("pay_1").update({
      status: "refunded",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Admin can approve refund
  await assertSucceeds(
    adminDb.collection("users").doc(ALICE_UID).collection("payments").doc("pay_1").update({
      status: "refunded",
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Bob cannot list Alice's payments
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("payments").get()
  );

  // Test attempt create (immutable)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("testAttempts").doc("att_1").set({
      userId: ALICE_UID,
      testId: "mock_12",
      testTitle: "Mock Test 12 - Chemistry",
      subject: "Full Syllabus",
      score: 142,
      maxMarks: 180,
      correctCount: 38,
      wrongCount: 6,
      unattemptedCount: 46,
      accuracyPercent: 78,
      durationSeconds: 3200,
      physicalScore: 82,
      organicScore: 68,
      inorganicScore: 74,
      createdAt: now,
    })
  );

  // Doubt create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("doubts").doc("doubt_1").set({
      userId: ALICE_UID,
      subject: "Physical Chemistry",
      chapter: "Chemical Bonding",
      difficulty: "Medium",
      questionText: "Why does BF3 have sp2 hybridisation?",
      status: "pending",
      replyCount: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Ticket create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("tickets").doc("tkt_1").set({
      userId: ALICE_UID,
      ticketCode: "TKT-1024",
      category: "Payments",
      orderId: "TXN20261123MH7821",
      subject: "Amount deducted but course locked",
      message: "Please verify my UPI transaction status.",
      contactMethod: "Email",
      status: "open",
      createdAt: now,
      updatedAt: now,
    })
  );
});
